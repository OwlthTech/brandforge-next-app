
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Brand, ContentPlan, MonthPlan, Post, ViewMode, ChatSession, ChatMessage, ResearchNote } from '../types';
import { BrandService, PlanService, ChatService } from '../services/db';

interface AppState {
  view: string;
  brands: Brand[];
  selectedBrand: Brand | null;
  plans: ContentPlan[];
  selectedPlan: ContentPlan | null;
  selectedMonth: MonthPlan | null;
  selectedPost: Post | null;
  monthlyViewMode: ViewMode;
  isGeneratingPlan: boolean;
  chatSession: ChatSession | null;
}

interface AppActions {
  setView: (view: string) => void;
  loadBrands: () => Promise<void>;
  selectBrand: (brand: Brand | null) => void;
  loadPlans: (brandId: string) => Promise<void>;
  addPlan: (plan: ContentPlan) => void;
  selectPlan: (plan: ContentPlan | null) => void;
  updatePlan: (plan: ContentPlan) => Promise<void>;
  selectMonth: (month: MonthPlan | null) => void;
  selectPost: (post: Post | null) => void;
  updatePost: (post: Post) => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  setMonthlyViewMode: (mode: ViewMode) => void;
  setIsGeneratingPlan: (isGenerating: boolean) => void;
  schedulePostFromLab: (post: Post, planId: string, monthIndex: number) => Promise<void>;
  loadChatSession: (brand: Brand) => Promise<void>;
  addChatMessage: (brandId: string, message: ChatMessage) => Promise<void>;
  addNote: (brandId: string, note: ResearchNote) => Promise<void>;
  deleteNote: (brandId: string, noteId: string) => Promise<void>;
}

const AppContext = createContext<{ state: AppState; actions: AppActions } | undefined>(undefined);

export const AppStoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // State
  const [view, setView] = useState<string>('dashboard');
  const [brands, setBrands] = useState<Brand[]>([]);
  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [plans, setPlans] = useState<ContentPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<ContentPlan | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<MonthPlan | null>(null);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [monthlyViewMode, setMonthlyViewMode] = useState<ViewMode>('grid');
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [chatSession, setChatSession] = useState<ChatSession | null>(null);

  // Initial Load
  useEffect(() => {
    loadBrands();
  }, []);

  // When brand changes, load its plans and chat
  useEffect(() => {
    if (selectedBrand) {
      loadPlans(selectedBrand.id);
      loadChatSession(selectedBrand);
    } else {
      setPlans([]);
      setChatSession(null);
    }
  }, [selectedBrand]);

  // Actions implementation
  const loadBrands = async () => {
    const list = await BrandService.getAll();
    setBrands(list);
  };

  const selectBrand = (brand: Brand | null) => {
    setSelectedBrand(brand);
  };

  const loadPlans = async (brandId: string) => {
    const brandPlans = await PlanService.getByBrand(brandId);
    setPlans(brandPlans.sort((a, b) => b.createdAt - a.createdAt));
  };

  const addPlan = (plan: ContentPlan) => {
    setPlans(prev => [plan, ...prev]);
  };

  const updatePlan = async (updatedPlan: ContentPlan) => {
    await PlanService.save(updatedPlan);
    setPlans(prev => prev.map(p => p.id === updatedPlan.id ? updatedPlan : p));
    if (selectedPlan?.id === updatedPlan.id) {
      setSelectedPlan(updatedPlan);
    }
  };

  const updatePost = async (updatedPost: Post) => {
    if (!selectedPlan || !selectedMonth) return;

    const updatedMonthPosts = selectedMonth.posts.map(p => p.id === updatedPost.id ? updatedPost : p);
    const updatedMonth = { ...selectedMonth, posts: updatedMonthPosts };
    
    const updatedMonths = selectedPlan.months.map(m => m.monthIndex === updatedMonth.monthIndex ? updatedMonth : m);
    const updatedPlan = { ...selectedPlan, months: updatedMonths };

    await updatePlan(updatedPlan);
    setSelectedMonth(updatedMonth);
    setSelectedPost(updatedPost);
  };

  const deletePost = async (postId: string) => {
    if (!selectedPlan || !selectedMonth) return;

    const updatedMonthPosts = selectedMonth.posts.filter(p => p.id !== postId);
    const updatedMonth = { ...selectedMonth, posts: updatedMonthPosts };
    
    const updatedMonths = selectedPlan.months.map(m => m.monthIndex === updatedMonth.monthIndex ? updatedMonth : m);
    const updatedPlan = { ...selectedPlan, months: updatedMonths };

    await updatePlan(updatedPlan);
    setSelectedMonth(updatedMonth);
    setSelectedPost(null);
  };

  const schedulePostFromLab = async (post: Post, planId: string, monthIndex: number) => {
    let targetPlan = plans.find(p => p.id === planId);
    
    // If not in current state (e.g. filtered list), try fetch
    if (!targetPlan) {
        targetPlan = await PlanService.getById(planId);
    }
    
    if (!targetPlan) {
        console.error("Target plan not found");
        return;
    }

    const targetMonth = targetPlan.months.find(m => m.monthIndex === monthIndex);
    if (!targetMonth) {
        console.error("Target month not found");
        return;
    }

    const newPosts = [...targetMonth.posts, post];
    const newMonth = { ...targetMonth, posts: newPosts };
    const updatedMonths = targetPlan.months.map(m => m.monthIndex === newMonth.monthIndex ? newMonth : m);
    const updatedPlan = { ...targetPlan, months: updatedMonths };

    await updatePlan(updatedPlan);

    // Navigate to the post
    setSelectedPlan(updatedPlan);
    setSelectedMonth(newMonth);
    setSelectedPost(post);
    setView('post_detail');
  };

  // Chat Actions
  const loadChatSession = async (brand: Brand) => {
    try {
      let session = await ChatService.getByBrand(brand.id);
      if (!session) {
        // Create initial session if none exists
        session = {
          brandId: brand.id,
          messages: [{ 
            role: 'model', 
            text: `Hi! I'm ready to research opportunities for ${brand.name}. What's on your mind?`,
            timestamp: Date.now()
          }],
          notes: [],
          updatedAt: Date.now()
        };
        await ChatService.save(session);
      }
      // Ensure notes array exists for migrated data
      if (!session.notes) session.notes = [];
      setChatSession(session);
    } catch (e) {
      console.error("Failed to load chat session", e);
    }
  };

  const addChatMessage = async (brandId: string, message: ChatMessage) => {
    if (!chatSession || chatSession.brandId !== brandId) return;
    
    const updatedMessages = [...chatSession.messages, message];
    const updatedSession = { ...chatSession, messages: updatedMessages, updatedAt: Date.now() };
    
    setChatSession(updatedSession); // Optimistic update
    await ChatService.save(updatedSession);
  };

  const addNote = async (brandId: string, note: ResearchNote) => {
      if (!chatSession || chatSession.brandId !== brandId) return;
      
      const updatedNotes = [...(chatSession.notes || []), note];
      const updatedSession = { ...chatSession, notes: updatedNotes, updatedAt: Date.now() };

      setChatSession(updatedSession);
      await ChatService.save(updatedSession);
  };

  const deleteNote = async (brandId: string, noteId: string) => {
      if (!chatSession || chatSession.brandId !== brandId) return;

      const updatedNotes = chatSession.notes.filter(n => n.id !== noteId);
      const updatedSession = { ...chatSession, notes: updatedNotes, updatedAt: Date.now() };

      setChatSession(updatedSession);
      await ChatService.save(updatedSession);
  };

  const state: AppState = {
    view,
    brands,
    selectedBrand,
    plans,
    selectedPlan,
    selectedMonth,
    selectedPost,
    monthlyViewMode,
    isGeneratingPlan,
    chatSession
  };

  const actions: AppActions = {
    setView,
    loadBrands,
    selectBrand,
    loadPlans,
    addPlan,
    selectPlan: setSelectedPlan,
    updatePlan,
    selectMonth: setSelectedMonth,
    selectPost: setSelectedPost,
    updatePost,
    deletePost,
    setMonthlyViewMode,
    setIsGeneratingPlan,
    schedulePostFromLab,
    loadChatSession,
    addChatMessage,
    addNote,
    deleteNote
  };

  return (
    <AppContext.Provider value={{ state, actions }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppStore = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppStore must be used within an AppStoreProvider');
  }
  return context;
};
