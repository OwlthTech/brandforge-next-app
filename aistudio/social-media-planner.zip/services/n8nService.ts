import { Post, Brand } from "../types";

// In a real app, this would be your actual N8N webhook URL
const WEBHOOK_URL = "https://your-n8n-instance.com/webhook/social-post";

export const sendPostToN8n = async (brand: Brand, post: Post) => {
  // Simulating network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  console.log(`[N8N Webhook] Sending post ${post.id} for brand ${brand.name} to ${post.platform}`);
  console.log(`Payload:`, {
    brandId: brand.id,
    platform: post.platform,
    content: post.content,
    image: post.imageUrl ? "Image Attached" : "No Image",
    scheduledDate: post.dateStr
  });
  
  // Real implementation:
  // await fetch(WEBHOOK_URL, {
  //   method: 'POST',
  //   body: JSON.stringify({ ...post, brandName: brand.name }),
  //   headers: { 'Content-Type': 'application/json' }
  // });

  return true;
};