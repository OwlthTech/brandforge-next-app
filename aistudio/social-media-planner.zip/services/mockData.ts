
import { Brand, ContentPlan, Post } from '../types';

export const MOCK_BRANDS: Brand[] = [
  {
    id: 'brand-1',
    name: 'EcoLife Styles',
    description: 'Sustainable living products and eco-friendly lifestyle tips for modern urbanites.',
    tone: 'Inspirational',
    targetAudience: 'Environmentally conscious millennials',
    website: 'https://ecolife.example.com'
  },
  {
    id: 'brand-2',
    name: 'TechNova',
    description: 'Cutting-edge gadget reviews and tech news for enthusiasts.',
    tone: 'Professional',
    targetAudience: 'Tech enthusiasts and early adopters',
    website: 'https://technova.example.com'
  }
];

const createMockPosts = (year: number, monthIndex: number): Post[] => {
  const posts: Post[] = [];
  const platforms = ['Instagram', 'LinkedIn', 'Twitter', 'Facebook'] as const;
  const topics = [
    'Product Launch Teaser', 'Sustainability Tip', 'Team Spotlight', 
    'Customer Testimonial', 'Industry News', 'Behind the Scenes'
  ];

  const today = new Date();
  
  // Generate 8 random posts for the month
  for (let i = 1; i <= 8; i++) {
    // Distribute days roughly every 3-4 days
    const day = (i * 3) + Math.floor(Math.random() * 2); 
    // Ensure day is valid for month (simple check)
    const validDay = Math.min(day, 28);
    
    // Construct Date object to check if it's past or future
    const postDate = new Date(year, monthIndex, validDay);
    const dateStr = `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(validDay).padStart(2, '0')}`;
    
    const isPast = postDate < today;
    
    const platform = platforms[Math.floor(Math.random() * platforms.length)];
    const hasImage = Math.random() > 0.3;
    
    // Status logic: Past dates must be 'posted', future can be 'approved' or 'draft'
    let status: 'draft' | 'approved' | 'posted';
    if (isPast) {
        status = 'posted';
    } else {
        status = Math.random() > 0.5 ? 'approved' : 'draft';
    }

    posts.push({
      id: `post-${monthIndex}-${i}`,
      dateStr,
      platform,
      topic: topics[Math.floor(Math.random() * topics.length)],
      objective: 'Engagement',
      content: Math.random() > 0.5 
        ? "Exciting things are coming soon! We've been working hard on our new line of eco-friendly containers. They keep your food fresh and the planet happy. 🌿✨ #Sustainability #EcoFriendly #ComingSoon #GreenLiving #ZeroWaste"
        : "Did you know that switching to bamboo toothbrushes can save pounds of plastic waste per person? Small changes make a big impact. Let's do this together! 🌍",
      hashtags: ['EcoFriendly', 'Sustainability', 'GreenLiving'],
      imagePrompt: 'A beautiful minimalist photo of bamboo products on a white background with green leaves',
      imageUrl: hasImage ? `https://picsum.photos/seed/${monthIndex}-${i}/800/800` : undefined,
      imageStatus: hasImage ? 'completed' : 'idle',
      status: status
    });
  }
  return posts.sort((a, b) => a.dateStr.localeCompare(b.dateStr));
};

// Generate a plan that starts from the current year
const today = new Date();
const currentYear = today.getFullYear();

export const MOCK_PLANS: ContentPlan[] = [
  {
    id: 'plan-1',
    brandId: 'brand-1',
    year: currentYear,
    postsPerMonth: 12,
    createdAt: Date.now(),
    status: 'active',
    startDate: new Date(currentYear, 0, 1).toISOString().split('T')[0], // Start of current year
    monthsCount: 12,
    months: Array.from({ length: 12 }, (_, i) => {
        // Determine status of month based on whether it is past or current
        const isPastMonth = i < today.getMonth();
        return {
            monthIndex: i,
            year: currentYear,
            status: isPastMonth ? 'approved' : 'draft',
            posts: createMockPosts(currentYear, i),
            focus: 'Brand Awareness'
        };
    })
  }
];
