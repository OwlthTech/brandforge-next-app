import { MonthPlan } from "../types";

export const exportMonthPlanToCSV = (monthPlan: MonthPlan) => {
  const headers = ['ID', 'Date', 'Platform', 'Topic', 'Content', 'Hashtags', 'Image Prompt', 'Image URL', 'Status'];
  
  const rows = monthPlan.posts.map(post => {
    return [
      post.id,
      post.dateStr,
      post.platform,
      `"${(post.topic || '').replace(/"/g, '""')}"`,
      `"${(post.content || '').replace(/"/g, '""')}"`,
      `"${(post.hashtags || []).join(' ')}"`,
      `"${(post.imagePrompt || '').replace(/"/g, '""')}"`,
      post.imageUrl || '',
      post.status
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `content_plan_${monthPlan.year}_${monthPlan.monthIndex + 1}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};