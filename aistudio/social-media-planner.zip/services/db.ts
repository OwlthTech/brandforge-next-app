
import { Brand, ContentPlan, ChatSession } from '../types';
import { MOCK_BRANDS, MOCK_PLANS } from './mockData';

const DB_NAME = 'WhiskContentDB';
const DB_VERSION = 2; // Incremented for 'chats' store

export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => reject('IndexedDB error: ' + (event.target as any).error);

    request.onsuccess = (event) => resolve((event.target as IDBOpenDBRequest).result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('brands')) {
        const brandStore = db.createObjectStore('brands', { keyPath: 'id' });
        // Seed Mock Data
        MOCK_BRANDS.forEach(b => brandStore.add(b));
      }
      if (!db.objectStoreNames.contains('plans')) {
        const planStore = db.createObjectStore('plans', { keyPath: 'id' });
        planStore.createIndex('brandId', 'brandId', { unique: false });
        // Seed Mock Data
        MOCK_PLANS.forEach(p => planStore.add(p));
      }
      if (!db.objectStoreNames.contains('chats')) {
        db.createObjectStore('chats', { keyPath: 'brandId' });
      }
    };
  });
};

// Generic Helper
const performTransaction = <T>(
  storeName: string,
  mode: IDBTransactionMode,
  callback: (store: IDBObjectStore) => IDBRequest | void
): Promise<T> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await initDB();
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      
      let request: IDBRequest | void;
      try {
        request = callback(store);
      } catch (e) {
        reject(e);
        return;
      }

      if (request) {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      } else {
        // For void returns that rely on tx complete
        tx.oncomplete = () => resolve(undefined as unknown as T);
        tx.onerror = () => reject(tx.error);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const BrandService = {
  getAll: () => performTransaction<Brand[]>('brands', 'readonly', (store) => store.getAll()),
  save: (brand: Brand) => performTransaction<string>('brands', 'readwrite', (store) => store.put(brand)),
  delete: (id: string) => performTransaction<void>('brands', 'readwrite', (store) => store.delete(id)),
};

export const PlanService = {
  getAll: () => performTransaction<ContentPlan[]>('plans', 'readonly', (store) => store.getAll()),
  getByBrand: (brandId: string) => 
    performTransaction<ContentPlan[]>('plans', 'readonly', (store) => {
      const index = store.index('brandId');
      return index.getAll(brandId);
    }),
  getById: (id: string) => performTransaction<ContentPlan>('plans', 'readonly', (store) => store.get(id)),
  save: (plan: ContentPlan) => performTransaction<string>('plans', 'readwrite', (store) => store.put(plan)),
  delete: (id: string) => performTransaction<void>('plans', 'readwrite', (store) => store.delete(id)),
};

export const ChatService = {
  getByBrand: (brandId: string) => performTransaction<ChatSession>('chats', 'readonly', (store) => store.get(brandId)),
  save: (session: ChatSession) => performTransaction<string>('chats', 'readwrite', (store) => store.put(session)),
  delete: (brandId: string) => performTransaction<void>('chats', 'readwrite', (store) => store.delete(brandId)),
};
