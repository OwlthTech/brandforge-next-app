
import { GoogleGenAI, Type } from "@google/genai";
import { Brand, Post, MonthPlan } from "../types";

// Helper to get API Client
const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found in environment variables");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// --- Maps Integration ---

export const fetchBrandDetailsFromMaps = async (
  query: string,
  location?: { lat: number; lng: number }
): Promise<Partial<Brand>> => {
  const ai = getAiClient();
  
  const systemInstruction = `You are a helper that extracts business details from Google Maps data to populate a Brand profile.
  Search for the business specified by the user.
  Analyze the Google Maps result (reviews, category, business info).
  
  Return a valid JSON object with the following fields:
  - name: The exact business name from Maps.
  - description: A concise description of what the business does.
  - website: The website URL if available.
  - tone: A suggested brand voice tone (e.g., "Casual", "Professional", "Energetic") based on the business type.
  - targetAudience: A suggested target audience description.
  
  Only return the JSON object. Do not add conversational text.
  `;

  const toolConfig = location ? {
    retrievalConfig: {
      latLng: {
        latitude: location.lat,
        longitude: location.lng
      }
    }
  } : undefined;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Find details for business: "${query}"`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: toolConfig,
      systemInstruction,
    },
  });

  if (!response.text) throw new Error("No results found on Maps");

  // Attempt to clean JSON
  let jsonStr = response.text.trim();
  // Remove markdown code blocks if present
  if (jsonStr.startsWith("```")) {
     jsonStr = jsonStr.replace(/^```(json)?/, '').replace(/```$/, '');
  }
  
  try {
    const data = JSON.parse(jsonStr);
    return {
      name: data.name,
      description: data.description,
      website: data.website,
      tone: data.tone,
      targetAudience: data.targetAudience
    };
  } catch (e) {
    console.error("Failed to parse Maps response as JSON", response.text);
    // Fallback: If JSON parsing fails, return partial data or throw specific error
    throw new Error("Found the business on Maps but couldn't auto-format the details. Please enter manually.");
  }
};

// --- Strategic Plan Generation ---

export const generateStrategicPlan = async (
  brand: Brand,
  startDate: string, // YYYY-MM-DD
  monthsCount: number,
  postsPerMonth: number,
  focus: string
): Promise<MonthPlan[]> => {
  const ai = getAiClient();
  
  const start = new Date(startDate);
  // Unused variables commented out to fix linter
  // const startYear = start.getFullYear();
  // const startMonth = start.getMonth(); 

  const systemInstruction = `You are an expert Social Media Strategist. 
  Create a high-level content calendar starting from ${startDate} for the next ${monthsCount} months.
  Brand Name: ${brand.name}
  Description: ${brand.description}
  Tone: ${brand.tone}
  Target Audience: ${brand.targetAudience}
  Strategic Focus: ${focus}
  
  Output ONLY JSON. Generate exactly ${monthsCount} months. For each month, generate ${postsPerMonth} high-level post ideas.
  Dates should be distributed evenly throughout the month.
  Platforms should vary between Twitter, LinkedIn, Instagram, Facebook based on brand fit.
  
  IMPORTANT: Ensure dates are correct for the specific year and month.
  `;

  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        monthIndex: { type: Type.INTEGER, description: "0 for Jan, 11 for Dec" },
        year: { type: Type.INTEGER, description: "The year of this specific month plan" },
        focus: { type: Type.STRING, description: "Main theme for this month" },
        posts: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              dateStr: { type: Type.STRING, description: "YYYY-MM-DD" },
              platform: { type: Type.STRING, enum: ["Twitter", "LinkedIn", "Instagram", "Facebook"] },
              topic: { type: Type.STRING },
              objective: { type: Type.STRING, description: "e.g. Engagement, Awareness, Sales" }
            },
            required: ["dateStr", "platform", "topic", "objective"]
          }
        }
      },
      required: ["monthIndex", "year", "focus", "posts"]
    }
  };

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Generate the content plan starting ${startDate}.`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: responseSchema,
      temperature: 0.7,
    },
  });

  if (!response.text) throw new Error("No response from AI");
  
  const rawMonths = JSON.parse(response.text);
  
  // Hydrate with IDs and status
  return rawMonths.map((m: any) => ({
    ...m,
    status: 'draft',
    posts: m.posts.map((p: any) => ({
      ...p,
      id: crypto.randomUUID(),
      status: 'draft',
      imageStatus: 'idle',
      timeStr: '10:00' // Default IST approximate morning slot
    }))
  }));
};

// --- Monthly Detail Generation ---

export const generateMonthlyDetails = async (
  brand: Brand,
  monthPlan: MonthPlan
): Promise<MonthPlan> => {
  const ai = getAiClient();

  const systemInstruction = `You are a Social Media Content Creator.
  Expand the following high-level monthly plan into detailed posts.
  Brand: ${brand.name} (${brand.tone})
  
  For each post, write:
  1. Detailed content (caption/tweet body)
  2. Hashtags (array of strings)
  3. A creative AI Image Prompt (descriptive, visual)
  
  Maintain the original IDs, dates, and platforms.
  `;

  // We send the current month posts to context
  const postsContext = JSON.stringify(monthPlan.posts.map(p => ({
    id: p.id,
    date: p.dateStr,
    topic: p.topic,
    platform: p.platform
  })));

  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        id: { type: Type.STRING },
        content: { type: Type.STRING },
        hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
        imagePrompt: { type: Type.STRING }
      },
      required: ["id", "content", "hashtags", "imagePrompt"]
    }
  };

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Here are the posts to detail: ${postsContext}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: responseSchema,
    },
  });

  if (!response.text) throw new Error("Failed to generate details");

  const detailedData = JSON.parse(response.text);
  
  // Merge details back into the original posts
  const updatedPosts = monthPlan.posts.map(post => {
    const detail = detailedData.find((d: any) => d.id === post.id);
    if (detail) {
      return { ...post, ...detail };
    }
    return post;
  });

  return { ...monthPlan, posts: updatedPosts };
};

// --- Revision ---

export const revisePost = async (
  brand: Brand,
  targetPost: Post,
  context: { prev?: Post, next?: Post },
  instruction: string
): Promise<Post> => {
  const ai = getAiClient();
  
  const systemInstruction = `You are a Social Media Editor.
  Revise the specific post based on user instructions.
  Brand: ${brand.name}
  Tone: ${brand.tone}
  
  Context:
  Previous Post: ${context.prev ? context.prev.topic : 'None'}
  Next Post: ${context.next ? context.next.topic : 'None'}
  
  Current Post: ${JSON.stringify(targetPost)}
  
  User Instruction: ${instruction}
  
  Return the fully updated Post object JSON. Update content, imagePrompt, etc. as needed to match the instruction.
  `;
  
   const responseSchema = {
    type: Type.OBJECT,
    properties: {
        content: { type: Type.STRING },
        topic: { type: Type.STRING },
        hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
        imagePrompt: { type: Type.STRING }
    },
    required: ["content"]
   }

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: "Revise this post.",
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: responseSchema
    }
  });

  if (!response.text) throw new Error("Revision failed");
  const revisions = JSON.parse(response.text);

  return { ...targetPost, ...revisions };
};

// --- Research Lab ---

export const chatWithResearcher = async (
  brand: Brand,
  history: { role: 'user' | 'model', text: string }[],
  creatorMode: boolean
): Promise<string> => {
  const ai = getAiClient();
  
  let systemInstruction = `You are a Social Media Research Assistant for the brand: ${brand.name}.
  Your goal is to help the user find niche opportunities, trending topics, and creative ideas.
  Be concise, insightful, and strategic.
  Use markdown formatting (bold for emphasis, lists for ideas) to make your responses readable.
  Tone: ${brand.tone}
  `;

  if (creatorMode) {
    systemInstruction = `You are a Social Media Content Creator for the brand: ${brand.name}.
    CREATOR MODE IS ACTIVE.
    
    Your goal is to DRAFT ready-to-use social media posts based on the conversation context.
    If the user discusses an idea, a topic, or asks for content, you MUST draft a specific post for it.
    
    IMPORTANT: You must wrap the drafted post JSON in specific markers.
    Mark the start with "[[DRAFT_START]]" and end with "[[DRAFT_END]]".
    Inside the markers, provide ONLY valid JSON with no markdown formatting.
    
    Structure:
    { 
      "topic": "Brief topic title", 
      "platform": "Twitter" | "LinkedIn" | "Instagram" | "Facebook", 
      "content": "Full post text...", 
      "imagePrompt": "Description for AI image generator...", 
      "hashtags": ["tag1", "tag2"] 
    }
    
    After the draft, you can add a brief conversational comment using Markdown.
    Tone: ${brand.tone}
    `;
  }

  // Map history to proper content parts
  const contents = history.map(h => ({
      role: h.role,
      parts: [{ text: h.text }]
  }));

  const result = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: contents,
    config: { systemInstruction }
  });
  
  return result.text || "";
};

// --- Image Generation ---

export const generatePostImage = async (prompt: string): Promise<string> => {
  const ai = getAiClient();
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: {
      parts: [{ text: prompt }]
    },
    config: {}
  });

  const parts = response.candidates?.[0]?.content?.parts;
  if (!parts) throw new Error("No image generated");

  // Find image part
  for (const part of parts) {
    if (part.inlineData && part.inlineData.data) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  
  throw new Error("Model did not return an image.");
};
