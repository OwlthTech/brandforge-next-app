
export interface Brand {
  id: string;
  name: string;
  description: string;
  tone: string;
  targetAudience: string;
  website?: string;
}

export type Platform = 'Twitter' | 'LinkedIn' | 'Instagram' | 'Facebook';

export interface Post {
  id: string;
  dateStr: string; // ISO String or YYYY-MM-DD
  timeStr?: string; // HH:mm (IST preference)
  platform: Platform;
  topic: string;
  objective: string;
  
  // Detailed fields (populated in monthly view)
  content?: string;
  hashtags?: string[];
  imagePrompt?: string;
  imageUrl?: string;
  imageStatus?: 'idle' | 'generating' | 'completed' | 'failed';
  
  status: 'draft' | 'approved' | 'posted';
}

export interface MonthPlan {
  monthIndex: number; // 0-11
  year: number;
  status: 'draft' | 'approved';
  posts: Post[];
  focus?: string;
}

export interface ContentPlan {
  id: string;
  brandId: string;
  year: number;
  postsPerMonth: number;
  createdAt: number;
  status: 'planning' | 'active' | 'archived';
  months: MonthPlan[];
  startDate?: string;
  monthsCount?: number;
}

export interface GenerationConfig {
  year: number;
  postsPerMonth: number;
  focus: string;
}

export interface ResearchNote {
  id: string;
  content: string;
  category: 'idea' | 'resource' | 'trend';
  createdAt: number;
}

export type ViewMode = 'grid' | 'month' | 'week' | 'day';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  draft?: any; // The JSON draft object if present
  timestamp: number;
}

export interface ChatSession {
  brandId: string;
  messages: ChatMessage[];
  notes: ResearchNote[];
  updatedAt: number;
}
