import React, { useEffect } from 'react';
import { Layout } from './components/Layout';
import { BrandManager } from './components/BrandManager';
import { PlanGenerator } from './components/PlanGenerator';
import { YearlyView } from './components/YearlyView';
import { MonthlyView } from './components/MonthlyView';
import { PostDetailView } from './components/PostDetailView';
import { ResearchLab } from './components/ResearchLab';
import { Brand } from './types';
import { Plus } from 'lucide-react';
import { useAppStore } from './store/AppStore';

const App: React.FC = () => {
  const { state, actions } = useAppStore();
  const { 
    view, 
    brands, 
    selectedBrand, 
    plans, 
    selectedPlan, 
    selectedMonth, 
    selectedPost, 
    monthlyViewMode, 
    isGeneratingPlan 
  } = state;

  // Handle Sidebar/Global Brand Selection
  const handleBrandSelect = (brand: Brand) => {
    actions.selectBrand(brand);
    // If we are in Research Lab, stay there (just change context)
    // Otherwise, go to brand plans
    if (view !== 'research_lab') {
        actions.setView('brand_plans');
    }
  };

  // --- Breadcrumb Logic ---
  const getBreadcrumbs = () => {
    const crumbs: { label: string; onClick?: () => void; active?: boolean }[] = [{ label: 'Analytics', onClick: () => { actions.selectBrand(null); actions.setView('dashboard'); } }];
    
    if (view === 'research_lab') {
        crumbs.push({ label: 'Research Lab', active: true });
        return crumbs;
    }

    if (selectedBrand) {
      crumbs.push({ label: selectedBrand.name, onClick: () => actions.setView('brand_plans') });
    }
    
    if (view === 'plan_yearly' && selectedPlan) {
      crumbs.push({ label: `${selectedPlan.year} Strategy`, onClick: () => actions.setView('plan_yearly'), active: true });
    }
    
    if ((view === 'plan_monthly' || view === 'post_detail') && selectedMonth && selectedPlan) {
       crumbs.push({ label: `${selectedPlan.year} Strategy`, onClick: () => actions.setView('plan_yearly') });
       // Using an array for month names since it was defined locally in components
       const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
       crumbs.push({ label: monthNames[selectedMonth.monthIndex], onClick: () => actions.setView('plan_monthly'), active: view === 'plan_monthly' });
    }
    
    if (view === 'post_detail' && selectedPost) {
        crumbs.push({ label: 'Post Detail', active: true });
    }

    return crumbs;
  };

  // --- Render Logic ---

  const renderContent = () => {
    if (view === 'research_lab') {
        return (
            <ResearchLab 
                brand={selectedBrand || undefined} 
                plans={plans}
                selectedPlanId={selectedPlan?.id}
                selectedMonthIndex={selectedMonth?.monthIndex}
                onSchedulePost={actions.schedulePostFromLab}
                brands={brands}
                onSelectBrand={handleBrandSelect}
            />
        );
    }

    if (view === 'dashboard') {
      return <BrandManager onSelectBrand={handleBrandSelect} />;
    }

    if (view === 'brand_plans' && selectedBrand) {
      if (isGeneratingPlan) {
        return (
          <PlanGenerator 
            brand={selectedBrand} 
            onPlanCreated={(newPlan) => {
                actions.addPlan(newPlan);
                actions.selectPlan(newPlan);
                actions.setIsGeneratingPlan(false);
                actions.setView('plan_yearly');
            }} 
            onCancel={() => actions.setIsGeneratingPlan(false)} 
          />
        );
      }

      return (
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="px-6 py-6 border-b border-border sticky top-0 z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-surface/50 backdrop-blur-sm">
             <div>
                <h2 className="text-3xl font-bold text-text-main">{selectedBrand.name}</h2>
                <p className="text-text-muted font-medium text-sm">Content Strategy Overview</p>
             </div>
             <button 
                onClick={() => actions.setIsGeneratingPlan(true)}
                className="bg-primary text-white px-6 py-2.5 rounded-xl flex items-center gap-2 hover:bg-primary-dark transition-all font-bold btn-3d shadow-3d-primary w-full sm:w-auto justify-center"
             >
                <Plus size={18} /> New Strategy
             </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-background">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {plans.map(plan => (
                  <div 
                    key={plan.id}
                    onClick={() => { actions.selectPlan(plan); actions.setView('plan_yearly'); }}
                    className="bg-surface p-6 rounded-3xl border border-border cursor-pointer hover:border-primary/50 hover:shadow-2xl hover:-translate-y-1 transition-all group"
                  >
                    <div className="flex justify-between items-center mb-6">
                      <div className="w-12 h-12 rounded-2xl bg-surface-highlight flex items-center justify-center text-primary font-bold text-xl group-hover:bg-primary group-hover:text-white transition-colors border border-border">
                        {plan.year.toString().slice(-2)}
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${plan.status === 'active' ? 'bg-success/10 text-success border border-success/20' : 'bg-warning/10 text-warning border border-warning/20'}`}>
                        {plan.status}
                      </span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-text-main mb-2">{plan.year} Strategy</h3>
                    <p className="text-sm text-text-muted mb-6">
                        {plan.startDate ? `Starts ${new Date(plan.startDate).toLocaleDateString()}` : 'Full Year'} • {plan.monthsCount || 12} Months
                    </p>
                    
                    <div className="pt-4 border-t border-border flex justify-between items-center">
                        <span className="text-xs font-semibold text-text-muted">Created {new Date(plan.createdAt).toLocaleDateString()}</span>
                        <span className="text-primary font-bold text-sm group-hover:underline">Open</span>
                    </div>
                  </div>
                ))}
                
                {plans.length === 0 && (
                    <div className="col-span-full py-20 text-center border-2 border-dashed border-border rounded-3xl bg-surface-highlight/10">
                        <p className="text-text-muted font-medium">No plans found.</p>
                        <button onClick={() => actions.setIsGeneratingPlan(true)} className="text-primary font-bold hover:underline mt-2">Create one now</button>
                    </div>
                )}
             </div>
          </div>
        </div>
      );
    }

    if (view === 'plan_yearly' && selectedPlan) {
      return (
        <YearlyView 
            plan={selectedPlan} 
            onSelectMonth={(m) => { actions.selectMonth(m); actions.setView('plan_monthly'); }}
            onApprovePlan={async () => {
                const updated = { ...selectedPlan, status: 'active' as const };
                await actions.updatePlan(updated);
            }}
        />
      );
    }

    if (view === 'plan_monthly' && selectedPlan && selectedMonth && selectedBrand) {
      return (
        <MonthlyView 
            brand={selectedBrand}
            plan={selectedPlan}
            month={selectedMonth}
            viewMode={monthlyViewMode}
            onViewModeChange={actions.setMonthlyViewMode}
            onBack={() => actions.setView('plan_yearly')}
            onUpdatePlan={actions.updatePlan}
            onViewPostDetail={(post) => { actions.selectPost(post); actions.setView('post_detail'); }}
        />
      );
    }

    if (view === 'post_detail' && selectedPost && selectedBrand) {
        return (
            <PostDetailView
                post={selectedPost}
                brand={selectedBrand}
                onBack={() => actions.setView('plan_monthly')}
                onEdit={() => {}} // Deprecated
                onUpdate={actions.updatePost}
                onDelete={actions.deletePost}
            />
        )
    }

    return <div>View not found</div>;
  };

  return (
    <Layout 
        currentView={view} 
        onNavigate={(v) => {
            actions.setView(v);
            if(v === 'dashboard') actions.selectBrand(null);
        }}
        brands={brands}
        selectedBrandId={selectedBrand?.id}
        onSelectBrand={handleBrandSelect}
        breadcrumbs={getBreadcrumbs()}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;