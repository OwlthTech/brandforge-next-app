import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
  active?: boolean;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items }) => {
  return (
    <nav className="flex items-center text-sm font-medium mb-4" aria-label="Breadcrumb">
      <div className="flex items-center space-x-2">
        <span className="text-text-muted"><Home size={14} /></span>
        {items.map((item, index) => (
          <React.Fragment key={index}>
            <ChevronRight size={14} className="text-text-muted/50" />
            <button
              onClick={item.onClick}
              disabled={!item.onClick || item.active}
              className={`
                transition-colors duration-200
                ${item.active ? 'text-text-main font-semibold cursor-default' : 'text-text-muted hover:text-primary cursor-pointer'}
                ${!item.onClick ? 'cursor-default' : ''}
              `}
            >
              {item.label}
            </button>
          </React.Fragment>
        ))}
      </div>
    </nav>
  );
};