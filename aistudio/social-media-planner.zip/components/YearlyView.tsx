import React from 'react';
import { ContentPlan, MonthPlan } from '../types';
import { CheckCircle2, ChevronLeft, ChevronRight } from 'lucide-react';

interface YearlyViewProps {
  plan: ContentPlan;
  onSelectMonth: (month: MonthPlan) => void;
  onApprovePlan: () => void;
}

const MONTH_NAMES = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

export const YearlyView: React.FC<YearlyViewProps> = ({ plan, onSelectMonth, onApprovePlan }) => {
  return (
    <div className="h-full flex flex-col bg-surface">
      {/* Header */}
      <div className="px-6 py-6 flex flex-col md:flex-row justify-between items-center sticky top-0 z-10 bg-surface/90 backdrop-blur-sm border-b border-border gap-4">
        <div>
            <h2 className="text-3xl font-bold text-text-main flex items-center gap-3">
              {plan.year} Strategy
              {plan.status === 'planning' && (
                  <span className="bg-warning/20 text-warning border border-warning/20 text-xs px-2 py-1 rounded-full font-bold uppercase tracking-wide">Draft</span>
              )}
            </h2>
            <p className="text-text-muted text-sm mt-1">Select a month to view detailed posts</p>
        </div>
        
        <div className="flex items-center gap-4">
             {/* Navigation visual mimic */}
             <div className="hidden sm:flex items-center bg-background border border-border rounded-xl p-1">
                <button className="p-2 hover:bg-surface-highlight rounded-lg transition-all text-text-muted"><ChevronLeft size={16} /></button>
                <span className="px-4 text-sm font-semibold text-text-main">Today</span>
                <button className="p-2 hover:bg-surface-highlight rounded-lg transition-all text-text-muted"><ChevronRight size={16} /></button>
             </div>

            {plan.status === 'planning' && (
                <button 
                    onClick={onApprovePlan}
                    className="bg-success text-white px-6 py-2.5 rounded-xl flex items-center gap-2 font-bold btn-3d shadow-[0_4px_0_0_#065f46]"
                >
                    <CheckCircle2 size={18} /> Approve Plan
                </button>
            )}
        </div>
      </div>

      {/* Grid Content */}
      <div className="p-6 md:p-8 overflow-y-auto bg-background flex-1">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {plan.months.map((month) => {
                const isApproved = month.status === 'approved';
                const bgClass = isApproved 
                  ? 'bg-success/5 border-success/30 hover:border-success/50' 
                  : 'bg-surface border-border hover:border-primary/50';
                
                return (
                    <div 
                        key={month.monthIndex}
                        onClick={() => onSelectMonth(month)}
                        className={`
                            relative rounded-2xl border-2 p-5 cursor-pointer transition-all duration-300
                            hover:shadow-2xl hover:-translate-y-1
                            ${bgClass}
                        `}
                    >
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-2xl font-bold text-text-main">{MONTH_NAMES[month.monthIndex]}</h3>
                            <div className="w-8 h-8 rounded-full bg-background border border-border flex items-center justify-center text-xs font-bold text-text-muted">
                                {month.posts.length}
                            </div>
                        </div>

                        <div className="space-y-3 mb-6">
                            {month.posts.slice(0, 2).map((post, i) => (
                                <div key={post.id} className="flex items-start gap-3">
                                    <div className={`w-1 h-8 rounded-full mt-1 ${i === 0 ? 'bg-primary' : 'bg-purple-500'}`}></div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-xs font-bold text-text-main mb-0.5 truncate">{post.topic}</p>
                                        <p className="text-[10px] text-text-muted uppercase font-semibold">{post.platform}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        
                        <div className="mt-auto pt-4 border-t border-border flex items-center justify-between">
                             <div className="flex -space-x-2">
                                <div className="w-6 h-6 rounded-full bg-surface-highlight border-2 border-surface"></div>
                                <div className="w-6 h-6 rounded-full bg-surface border-2 border-surface"></div>
                             </div>
                             <span className="text-xs font-bold text-primary group-hover:underline">View Details</span>
                        </div>
                    </div>
                );
            })}
        </div>
      </div>
    </div>
  );
};