import React from 'react';
import { Save, User, Bell, Shield, Cloud } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-8 py-6 border-b border-border bg-surface">
         <h2 className="text-2xl font-bold text-text-main">Settings</h2>
         <p className="text-text-muted text-sm">Manage your preferences and account</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-3xl space-y-8">
            
            {/* Profile Section */}
            <section className="bg-surface p-6 rounded-3xl border border-border">
                <div className="flex items-center gap-4 mb-6">
                    <div className="bg-primary/10 p-3 rounded-xl text-primary"><User size={24} /></div>
                    <div>
                        <h3 className="text-lg font-bold text-text-main">Profile Information</h3>
                        <p className="text-sm text-text-muted">Update your account details</p>
                    </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-1">
                        <label className="block text-xs font-bold text-text-muted uppercase mb-1">First Name</label>
                        <input className="w-full bg-background border border-border rounded-xl px-4 py-2 text-text-main" defaultValue="Antonio" />
                    </div>
                    <div className="col-span-1">
                        <label className="block text-xs font-bold text-text-muted uppercase mb-1">Last Name</label>
                        <input className="w-full bg-background border border-border rounded-xl px-4 py-2 text-text-main" defaultValue="Larentio" />
                    </div>
                    <div className="col-span-2">
                        <label className="block text-xs font-bold text-text-muted uppercase mb-1">Email</label>
                        <input className="w-full bg-background border border-border rounded-xl px-4 py-2 text-text-main" defaultValue="antonio@whiskcontent.com" disabled />
                    </div>
                </div>
            </section>

             {/* Preferences Section */}
             <section className="bg-surface p-6 rounded-3xl border border-border">
                <div className="flex items-center gap-4 mb-6">
                    <div className="bg-amber-500/10 p-3 rounded-xl text-amber-500"><Bell size={24} /></div>
                    <div>
                        <h3 className="text-lg font-bold text-text-main">Notifications</h3>
                        <p className="text-sm text-text-muted">Configure how you receive alerts</p>
                    </div>
                </div>
                
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-background rounded-xl border border-border">
                        <span className="font-medium text-text-main">Email on Plan Approval</span>
                        <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div></div>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-background rounded-xl border border-border">
                        <span className="font-medium text-text-main">Weekly Summary</span>
                        <div className="w-10 h-6 bg-surface-highlight rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-4 h-4 bg-text-muted/50 rounded-full shadow-sm"></div></div>
                    </div>
                </div>
            </section>

            {/* Integration Section */}
             <section className="bg-surface p-6 rounded-3xl border border-border">
                <div className="flex items-center gap-4 mb-6">
                    <div className="bg-blue-500/10 p-3 rounded-xl text-blue-500"><Cloud size={24} /></div>
                    <div>
                        <h3 className="text-lg font-bold text-text-main">Integrations</h3>
                        <p className="text-sm text-text-muted">Manage connected services</p>
                    </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-background rounded-xl border border-border">
                    <div className="flex items-center gap-3">
                        <div className="font-bold text-text-main">n8n Automation</div>
                        <span className="text-[10px] bg-success/10 text-success px-2 py-0.5 rounded-full font-bold">Connected</span>
                    </div>
                    <button className="text-xs text-text-muted hover:text-text-main">Configure</button>
                </div>
            </section>

            <div className="flex justify-end">
                <button className="bg-primary text-white px-8 py-3 rounded-xl font-bold btn-3d shadow-3d-primary flex items-center gap-2">
                    <Save size={18} /> Save Changes
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};