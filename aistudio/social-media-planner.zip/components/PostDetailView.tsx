import React, { useState, useEffect } from 'react';
import { Post, Brand, Platform } from '../types';
import { ArrowLeft, Save, Trash2, Wand2, Check, ExternalLink, Calendar, Clock, RefreshCw } from 'lucide-react';
import { PlatformIcon } from './common/PlatformIcon';
import { revisePost, generatePostImage } from '../services/geminiService';

interface PostDetailViewProps {
  post: Post;
  brand: Brand;
  onBack: () => void;
  onEdit: () => void; // Deprecated but kept for compatibility
  onUpdate?: (post: Post) => void;
  onDelete?: (postId: string) => void;
}

export const PostDetailView: React.FC<PostDetailViewProps> = ({ post, brand, onBack, onUpdate, onDelete }) => {
  const [formData, setFormData] = useState<Post>(post);
  const [hasChanges, setHasChanges] = useState(false);
  const [isRevising, setIsRevising] = useState(false);
  const [revisionPrompt, setRevisionPrompt] = useState('');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);

  useEffect(() => {
    setFormData(post);
    setHasChanges(false);
  }, [post]);

  const handleChange = (field: keyof Post, value: any) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    setHasChanges(true);
  };

  const handleSave = async () => {
    if (onUpdate) {
        onUpdate(formData);
        setHasChanges(false);
    }
  };

  const handleDelete = () => {
      if (confirm("Are you sure you want to delete this post?") && onDelete) {
          onDelete(formData.id);
          onBack();
      }
  };

  const handleAiRevise = async () => {
      if (!revisionPrompt.trim()) return;
      setIsRevising(true);
      try {
        const revised = await revisePost(brand, formData, {}, revisionPrompt);
        const merged = { ...formData, ...revised };
        setFormData(merged);
        setHasChanges(true);
        setRevisionPrompt('');
      } catch (e) {
          alert("Failed to revise post");
      } finally {
          setIsRevising(false);
      }
  };

  const handleGenerateImage = async () => {
      if(!formData.imagePrompt) return;
      setIsGeneratingImage(true);
      try {
          const url = await generatePostImage(formData.imagePrompt);
          handleChange('imageUrl', url);
          handleChange('imageStatus', 'completed');
      } catch(e) {
          handleChange('imageStatus', 'failed');
      } finally {
          setIsGeneratingImage(false);
      }
  };

  const cleanHashtags = (formData.hashtags || []).map(t => '#' + t.replace(/^#+/, '')).join(' ');

  // Platform Preview (Isolated colors allowed here)
  const renderPlatformPreview = () => {
    switch (formData.platform) {
        case 'Twitter':
            return (
                <div className="bg-black text-white p-6 rounded-2xl border border-gray-800 font-sans shadow-lg">
                    <div className="flex gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center font-bold text-sm">
                            {brand.name.charAt(0)}
                        </div>
                        <div>
                            <div className="font-bold text-[15px]">{brand.name} <span className="text-blue-400">✅</span></div>
                            <div className="text-gray-500 text-[14px]">@{brand.name.replace(/\s/g, '')}</div>
                        </div>
                    </div>
                    <div className="text-[15px] leading-normal mb-3 whitespace-pre-wrap">
                        {formData.content || 'Start writing your post...'}
                        <br/><br/>
                        <span className="text-blue-400">{cleanHashtags}</span>
                    </div>
                    {formData.imageUrl && (
                        <div className="rounded-2xl overflow-hidden border border-gray-800 mb-3">
                            <img src={formData.imageUrl} className="w-full h-auto" alt="Post" />
                        </div>
                    )}
                </div>
            );
        case 'LinkedIn':
            return (
                <div className="bg-white text-black rounded-xl border border-gray-300 font-sans overflow-hidden shadow-lg">
                     <div className="p-4 flex gap-3">
                        <div className="w-12 h-12 rounded-full bg-gray-200"></div>
                        <div>
                            <div className="font-bold text-sm">{brand.name}</div>
                            <div className="text-gray-500 text-xs">{brand.description.slice(0,30)}...</div>
                            <div className="text-gray-500 text-xs">1h • 🌐</div>
                        </div>
                     </div>
                     <div className="px-4 pb-2 text-sm text-gray-800 whitespace-pre-wrap">
                        {formData.content || 'Start writing your post...'}
                        <br/><br/>
                        <span className="text-blue-600 font-semibold">{cleanHashtags}</span>
                     </div>
                     {formData.imageUrl && (
                         <img src={formData.imageUrl} className="w-full h-auto object-cover" alt="Post" />
                     )}
                     <div className="px-4 py-3 border-t border-gray-200 flex justify-around text-gray-600 bg-gray-50">
                        <div className="text-xs font-bold">Like</div>
                        <div className="text-xs font-bold">Comment</div>
                        <div className="text-xs font-bold">Repost</div>
                        <div className="text-xs font-bold">Send</div>
                     </div>
                </div>
            );
        default: // Instagram/Facebook
            return (
                <div className="bg-white text-black rounded-xl border border-gray-300 font-sans overflow-hidden shadow-lg">
                    <div className="p-3 flex items-center gap-3">
                         <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 to-purple-600 p-[2px]">
                            <div className="bg-white w-full h-full rounded-full border-2 border-white"></div>
                         </div>
                         <span className="font-bold text-sm">{brand.name.toLowerCase().replace(/\s/g, '_')}</span>
                    </div>
                    {formData.imageUrl ? (
                        <img src={formData.imageUrl} className="w-full h-auto" alt="Post" />
                    ) : (
                        <div className="w-full h-64 bg-gray-100 flex items-center justify-center text-gray-400 font-medium">Image Preview</div>
                    )}
                    <div className="p-3">
                         <div className="text-sm">
                            <span className="font-bold mr-2">{brand.name.toLowerCase().replace(/\s/g, '_')}</span>
                            {formData.content || '...'}
                            <br/>
                            <span className="text-blue-800">{cleanHashtags}</span>
                         </div>
                    </div>
                </div>
            );
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
        case 'posted': return 'bg-success/10 text-success border-success/30';
        case 'approved': return 'bg-primary/10 text-primary border-primary/30';
        default: return 'bg-surface-highlight text-text-muted border-border';
    }
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="bg-surface px-6 py-4 border-b border-border flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-4 min-w-0">
            <button onClick={onBack} className="flex items-center gap-2 text-text-muted hover:text-text-main font-medium transition-colors shrink-0">
                <ArrowLeft size={20} /> Back
            </button>
            <div className="h-6 w-px bg-border shrink-0"></div>
            
            <div className="flex items-center gap-3 overflow-hidden">
                <span className="text-lg font-bold text-text-main truncate">{formData.topic}</span>
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border shrink-0 ${getStatusColor(formData.status)}`}>
                    {formData.status}
                </span>
            </div>
        </div>
        
        <div className="flex gap-3 shrink-0 ml-4">
            <button 
                onClick={handleDelete}
                className="flex items-center gap-2 bg-error/10 hover:bg-error/20 text-error border border-error/20 px-4 py-2 rounded-xl text-sm font-bold transition-colors"
            >
                <Trash2 size={16} /> Delete
            </button>
            <button 
                onClick={handleSave}
                disabled={!hasChanges}
                className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all btn-3d shadow-3d-primary ${hasChanges ? 'bg-primary text-white shadow-lg' : 'bg-surface-highlight text-text-muted opacity-50 cursor-not-allowed shadow-none'}`}
            >
                <Save size={16} /> {hasChanges ? 'Save Changes' : 'Saved'}
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8">
         <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 max-w-7xl mx-auto h-full">
            
            {/* Left: Editor Form */}
            <div className="space-y-6 flex flex-col h-full">
                
                {/* Meta Card */}
                <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm">
                    <div className="flex flex-col md:flex-row gap-4 mb-4">
                        <div className="flex-1">
                             <label className="text-xs text-text-muted uppercase font-bold block mb-1.5">Topic</label>
                             <input 
                                className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-text-main font-bold focus:ring-2 focus:ring-primary outline-none"
                                value={formData.topic}
                                onChange={e => handleChange('topic', e.target.value)}
                             />
                        </div>
                        <div className="w-full md:w-48">
                            <label className="text-xs text-text-muted uppercase font-bold block mb-1.5">Status</label>
                            <select 
                                className={`w-full border rounded-xl px-4 py-2.5 font-bold outline-none appearance-none cursor-pointer
                                    ${formData.status === 'approved' ? 'bg-success/10 text-success border-success/30' : 
                                      formData.status === 'posted' ? 'bg-info/10 text-info border-info/30' : 
                                      'bg-background text-text-muted border-border'}
                                `}
                                value={formData.status}
                                onChange={e => handleChange('status', e.target.value)}
                            >
                                <option value="draft">Draft</option>
                                <option value="approved">Approved</option>
                                <option value="posted">Posted</option>
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                         <div className="col-span-1">
                             <label className="text-xs text-text-muted uppercase font-bold block mb-1.5 flex items-center gap-1"><Calendar size={12}/> Date</label>
                             <input 
                                type="date"
                                className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                value={formData.dateStr}
                                onChange={e => handleChange('dateStr', e.target.value)}
                             />
                         </div>
                         <div className="col-span-1">
                             <label className="text-xs text-text-muted uppercase font-bold block mb-1.5 flex items-center gap-1"><Clock size={12}/> Time (IST)</label>
                             <input 
                                type="time"
                                className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                value={formData.timeStr || '10:00'}
                                onChange={e => handleChange('timeStr', e.target.value)}
                             />
                         </div>
                         <div className="col-span-2">
                             <label className="text-xs text-text-muted uppercase font-bold block mb-1.5">Platform</label>
                             <div className="relative">
                                 <select 
                                    className="w-full bg-background border border-border rounded-xl pl-9 pr-3 py-2 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none appearance-none"
                                    value={formData.platform}
                                    onChange={e => handleChange('platform', e.target.value as Platform)}
                                 >
                                    <option value="Twitter">Twitter</option>
                                    <option value="LinkedIn">LinkedIn</option>
                                    <option value="Instagram">Instagram</option>
                                    <option value="Facebook">Facebook</option>
                                 </select>
                                 <div className="absolute left-3 top-2.5 pointer-events-none text-text-muted">
                                     <PlatformIcon platform={formData.platform} size={14} />
                                 </div>
                             </div>
                         </div>
                    </div>
                </div>

                {/* Content Editor */}
                <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm flex-1 flex flex-col min-h-[300px]">
                    <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-text-muted uppercase font-bold">Content</label>
                        <div className="flex items-center gap-2">
                            <input 
                                className="bg-background border border-border rounded-lg px-3 py-1 text-xs text-text-main w-64 focus:ring-1 focus:ring-primary outline-none"
                                placeholder="Instruction for AI (e.g. 'Make it punchier')"
                                value={revisionPrompt}
                                onChange={e => setRevisionPrompt(e.target.value)}
                                onKeyDown={e => e.key === 'Enter' && handleAiRevise()}
                            />
                            <button 
                                onClick={handleAiRevise}
                                disabled={isRevising || !revisionPrompt}
                                className="bg-primary/10 text-primary p-1.5 rounded-lg hover:bg-primary/20 transition-colors disabled:opacity-50"
                                title="Apply Revision"
                            >
                                <Wand2 size={14} className={isRevising ? 'animate-spin' : ''} />
                            </button>
                        </div>
                    </div>
                    <textarea 
                        className="flex-1 w-full bg-background border border-border rounded-xl p-4 text-base text-text-main focus:ring-2 focus:ring-primary outline-none resize-none leading-relaxed"
                        value={formData.content || ''}
                        onChange={e => handleChange('content', e.target.value)}
                        placeholder="Write your post content here..."
                    />
                    
                    <div className="mt-4">
                        <label className="text-xs text-text-muted uppercase font-bold block mb-1.5">Hashtags</label>
                        <input 
                             className="w-full bg-background border border-border rounded-xl px-4 py-2 text-sm text-primary font-medium focus:ring-2 focus:ring-primary outline-none placeholder-text-muted/50"
                             value={(formData.hashtags || []).join(', ')}
                             onChange={e => handleChange('hashtags', e.target.value.split(',').map(s => s.trim()))}
                             placeholder="e.g. marketing, growth, branding"
                        />
                    </div>
                </div>
                
                {/* Image Config */}
                <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm">
                    <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-text-muted uppercase font-bold">Image Prompt</label>
                        <button 
                            onClick={handleGenerateImage}
                            disabled={isGeneratingImage || !formData.imagePrompt}
                            className="text-xs font-bold text-primary flex items-center gap-1 hover:underline disabled:opacity-50"
                        >
                            <RefreshCw size={12} className={isGeneratingImage ? 'animate-spin' : ''} /> Regenerate Image
                        </button>
                    </div>
                    <textarea 
                         className="w-full bg-background border border-border rounded-xl p-3 text-sm text-text-muted focus:ring-2 focus:ring-primary outline-none resize-none h-20 mb-2"
                         value={formData.imagePrompt || ''}
                         onChange={e => handleChange('imagePrompt', e.target.value)}
                         placeholder="Describe the image..."
                    />
                     <div className="flex items-center gap-2">
                        <span className="text-[10px] text-text-muted uppercase font-bold">URL:</span>
                        <input 
                             className="flex-1 bg-background border border-border rounded-lg px-2 py-1 text-xs text-text-muted truncate focus:ring-1 focus:ring-primary outline-none"
                             value={formData.imageUrl || ''}
                             onChange={e => handleChange('imageUrl', e.target.value)}
                             placeholder="Image URL"
                        />
                        {formData.imageUrl && (
                            <a href={formData.imageUrl} target="_blank" rel="noreferrer" className="text-text-muted hover:text-primary"><ExternalLink size={14} /></a>
                        )}
                    </div>
                </div>

            </div>

            {/* Right: Preview */}
            <div className="flex flex-col h-full sticky top-0">
                <div className="text-center mb-4 text-text-muted text-sm font-bold uppercase tracking-widest">
                    Live Preview
                </div>
                <div className="flex-1 flex items-center justify-center bg-surface-highlight/20 rounded-3xl border-2 border-dashed border-border p-8">
                    <div className="w-full max-w-md transform transition-all duration-300 hover:scale-[1.02]">
                        {renderPlatformPreview()}
                    </div>
                </div>
                <div className="mt-4 text-center">
                    <p className="text-xs text-text-muted">
                        Preview approximates how the post will appear on {formData.platform}. 
                        Actual rendering may vary.
                    </p>
                </div>
            </div>
         </div>
      </div>
    </div>
  );
};