import React from 'react';
import { Layers, ChevronDown, Plus, FlaskConical, BarChart2 } from 'lucide-react';
import { Brand } from '../types';

interface SidebarProps {
  currentView: string;
  brands: Brand[];
  selectedBrandId?: string;
  onNavigate: (view: string) => void;
  onSelectBrand: (brand: Brand) => void;
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  brands,
  selectedBrandId,
  onNavigate,
  onSelectBrand,
  className = ""
}) => {
  return (
    <aside className={`w-[280px] bg-surface m-4 rounded-3xl flex flex-col border border-border ${className}`}>
      {/* Profile Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary p-[2px]">
            <div className="w-full h-full rounded-full bg-surface flex items-center justify-center text-text-main font-bold text-sm">
              AL
            </div>
          </div>
          <div className="overflow-hidden">
            <h3 className="text-text-main text-sm font-semibold leading-tight truncate">Antonio Larentio</h3>
            <p className="text-xs text-text-muted truncate">Product Designer</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 overflow-y-auto space-y-6">
        
        {/* Main Links */}
        <div>
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 btn-3d
              ${currentView === 'dashboard' && !selectedBrandId 
                ? 'border-primary border text-primary bg-primary/5' 
                : 'text-text-muted hover:bg-surface-highlight hover:text-text-main active:bg-surface-highlight'}`}
          >
            <BarChart2 size={18} />
            <span className="font-medium text-sm">Analytics</span>
          </button>
           <button 
            onClick={() => onNavigate('research_lab')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 btn-3d mt-2
              ${currentView === 'research_lab'
                ? 'border-primary border text-primary bg-primary/5' 
                : 'text-text-muted hover:bg-surface-highlight hover:text-text-main active:bg-surface-highlight'}`}
          >
            <FlaskConical size={18} />
            <span className="font-medium text-sm">Research Lab</span>
          </button>
        </div>

        {/* Brand List */}
        <div>
          <div className="flex items-center justify-between mb-3 px-2">
            <h4 className="text-xs font-bold text-text-muted uppercase tracking-wider">My Brands</h4>
            <ChevronDown size={14} className="text-text-muted" />
          </div>
          
          <div className="space-y-1">
            {brands.map((brand, idx) => {
               // Generate a distinct border color or dot color based on index
               const dotColors = ['bg-primary', 'bg-secondary', 'bg-warning', 'bg-success', 'bg-info'];
               const dotClass = dotColors[idx % dotColors.length];
               
               return (
                 <button
                    key={brand.id}
                    onClick={() => onSelectBrand(brand)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group
                       ${selectedBrandId === brand.id 
                         ? 'bg-surface-highlight text-text-main' 
                         : 'text-text-muted hover:text-text-main hover:bg-surface-highlight/50'}
                    `}
                 >
                    <span className={`w-2.5 h-2.5 rounded-full ${dotClass} ring-2 ring-transparent group-hover:ring-white/10 transition-all`}></span>
                    <span className="text-sm truncate flex-1 text-left">{brand.name}</span>
                 </button>
               );
            })}
            
            <button 
              onClick={() => onNavigate('dashboard')}
              className="w-full flex items-center gap-3 px-3 py-2 text-text-muted hover:text-primary mt-3 transition-colors group"
            >
              <div className="w-6 h-6 rounded-md border border-dashed border-text-muted group-hover:border-primary flex items-center justify-center">
                <Plus size={14} />
              </div>
              <span className="text-xs font-medium">Add Brand</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 rounded-xl p-4 relative overflow-hidden group">
          <div className="relative z-10">
            <h5 className="text-text-main text-xs font-bold mb-1">WhiskContent Pro</h5>
            <p className="text-[10px] text-text-muted mb-3">Get AI Revisions & more</p>
            <button className="w-full bg-primary text-white text-[10px] font-bold px-3 py-2 rounded-lg">
              Upgrade Plan
            </button>
          </div>
          <div className="absolute top-0 right-0 w-20 h-20 bg-primary/20 rounded-full blur-2xl -mr-6 -mt-6 group-hover:bg-primary/30 transition-colors"></div>
        </div>
      </div>
    </aside>
  );
};