import React from 'react';
import { MonthPlan, Post } from '../../types';
import { PlatformIcon } from '../common/PlatformIcon';
import { Plus } from 'lucide-react';

interface DayListProps {
  month: MonthPlan;
  posts: Post[];
  onSelectPost: (post: Post) => void;
  onAddPost: (dateStr: string) => void;
  currentDate: Date;
}

export const DayList: React.FC<DayListProps> = ({ month, posts, onSelectPost, onAddPost }) => {
    // Generate all days in month
    const year = month.year;
    const monthIdx = month.monthIndex;
    const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
    
    // Group posts by day
    const postsByDay = new Map<string, Post[]>();
    posts.forEach(p => {
        if(!postsByDay.has(p.dateStr)) postsByDay.set(p.dateStr, []);
        postsByDay.get(p.dateStr)?.push(p);
    });

    const days = [];
    for(let i=1; i<=daysInMonth; i++) {
        const dateStr = `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        days.push({ 
            day: i, 
            dateStr, 
            dateObj: new Date(year, monthIdx, i),
            posts: postsByDay.get(dateStr) || [] 
        });
    }

    // Helper for status colors
    const getStatusColor = (status: string) => {
        switch(status) {
            case 'posted': return 'bg-success text-white border-success';
            case 'approved': return 'bg-primary text-white border-primary';
            default: return 'bg-surface-highlight text-text-muted border-border';
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6 pb-20">
            {days.map(dayItem => (
                <div key={dayItem.dateStr} className="flex gap-4 group/day relative">
                    {/* Date Column */}
                    <div className="w-20 pt-2 flex flex-col items-center shrink-0">
                        <span className="text-xs text-text-muted uppercase font-bold">{dayItem.dateObj.toLocaleString('en-us', {weekday: 'short'})}</span>
                        <div className={`w-10 h-10 mt-1 rounded-full flex items-center justify-center font-bold text-lg border ${
                             dayItem.dateStr === new Date().toISOString().split('T')[0] 
                             ? 'bg-primary text-white border-primary shadow-lg' 
                             : 'bg-surface border-border text-text-main'
                        }`}>
                            {dayItem.day}
                        </div>
                        {/* Add Button shown on hover of the day section */}
                         <button 
                            onClick={() => onAddPost(dayItem.dateStr)}
                            className="mt-3 p-2 rounded-full bg-surface-highlight text-text-muted hover:text-primary hover:bg-surface border border-border opacity-0 group-hover/day:opacity-100 transition-all"
                            title="Add Post to this day"
                        >
                            <Plus size={16} />
                        </button>
                    </div>

                    {/* Posts Column */}
                    <div className="flex-1 space-y-3 pt-2">
                        {dayItem.posts.length === 0 ? (
                            <div className="h-full border-l-2 border-border/50 pl-4 py-2 min-h-[50px] flex items-center">
                                <p className="text-xs text-text-muted/30 italic">No posts scheduled</p>
                            </div>
                        ) : (
                             dayItem.posts.map(post => (
                                <div 
                                    key={post.id} 
                                    onClick={() => onSelectPost(post)}
                                    className="bg-surface rounded-2xl border border-border hover:border-primary transition-colors cursor-pointer group flex overflow-hidden shadow-sm hover:shadow-md"
                                >
                                    {post.imageUrl && (
                                        <div className="w-24 bg-background border-r border-border shrink-0 hidden sm:block">
                                            <img src={post.imageUrl} className="w-full h-full object-cover" alt="" />
                                        </div>
                                    )}
                                    <div className="flex-1 p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex items-center gap-2">
                                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-surface-highlight text-text-muted flex items-center gap-1 uppercase tracking-wider">
                                                    <PlatformIcon platform={post.platform} size={10} />
                                                    {post.platform}
                                                </span>
                                                <span className="text-[10px] text-text-muted font-medium">{post.timeStr || '10:00'}</span>
                                            </div>
                                            <div className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border ${getStatusColor(post.status)}`}>
                                                {post.status}
                                            </div>
                                        </div>
                                        <h4 className="text-base font-bold text-text-main mb-1 group-hover:text-primary transition-colors line-clamp-1">{post.topic}</h4>
                                        <p className="text-xs text-text-muted line-clamp-2">{post.content || <span className="italic opacity-50">Drafting content...</span>}</p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
}