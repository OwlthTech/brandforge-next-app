import React from 'react';
import { MonthPlan, Post } from '../../types';
import { Plus } from 'lucide-react';
import { PlatformIcon } from '../common/PlatformIcon';

interface MonthGridProps {
  month: MonthPlan;
  posts: Post[];
  onSelectPost: (post: Post) => void;
  onAddPost: (dateStr: string) => void;
  currentDate: Date;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const MonthGrid: React.FC<MonthGridProps> = ({ month, posts, onSelectPost, onAddPost, currentDate }) => {
  const year = month.year;
  const monthIdx = month.monthIndex;
  
  const firstDayOfMonth = new Date(year, monthIdx, 1).getDay();
  const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
  
  const days = [];
  // Padding days
  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push({ day: null });
  }
  // Actual days
  for (let i = 1; i <= daysInMonth; i++) {
    days.push({ 
      day: i, 
      dateStr: `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`
    });
  }

  const getStatusColor = (status: string) => {
        switch(status) {
            case 'posted': return 'bg-success';
            case 'approved': return 'bg-primary';
            default: return 'bg-text-muted/50';
        }
  };

  return (
    <div className="h-full flex flex-col bg-background rounded-2xl border border-border overflow-hidden">
      {/* Header */}
      <div className="grid grid-cols-7 border-b border-border bg-surface text-text-muted text-xs font-bold uppercase tracking-wider text-center py-3">
        {DAYS.map(d => <div key={d}>{d}</div>)}
      </div>
      
      {/* Grid */}
      <div className="grid grid-cols-7 flex-1 auto-rows-fr">
        {days.map((d, idx) => {
           const dayPosts = d.dateStr ? posts.filter(p => p.dateStr === d.dateStr) : [];
           return (
             <div key={idx} className={`min-h-[120px] border-b border-r border-border p-2 relative group hover:bg-surface-highlight/10 transition-colors ${!d.day ? 'bg-surface/50' : ''}`}>
                {d.day && (
                    <>
                        <span className={`text-sm font-bold ${d.dateStr === new Date().toISOString().split('T')[0] ? 'bg-primary text-white w-6 h-6 flex items-center justify-center rounded-full shadow-lg' : 'text-text-muted'}`}>
                            {d.day}
                        </span>
                        
                        <div className="mt-2 space-y-1.5">
                            {dayPosts.map(post => (
                                <button 
                                    key={post.id}
                                    onClick={() => onSelectPost(post)}
                                    className={`w-full text-left text-[10px] px-2 py-1.5 rounded-md truncate font-medium border-l-2 transition-all hover:brightness-110 flex items-center gap-1.5 shadow-sm
                                        bg-surface border-border text-text-main hover:border-primary
                                    `}
                                >
                                    <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${getStatusColor(post.status)}`}></div>
                                    <PlatformIcon platform={post.platform} size={10} />
                                    <span className="truncate">{post.topic}</span>
                                </button>
                            ))}
                        </div>
                        
                        <button 
                            onClick={(e) => { e.stopPropagation(); if(d.dateStr) onAddPost(d.dateStr); }}
                            className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 bg-surface rounded-lg border border-border text-text-muted hover:text-primary hover:border-primary transition-all shadow-sm z-10"
                            title="Add Post"
                        >
                            <Plus size={14} />
                        </button>
                    </>
                )}
             </div>
           );
        })}
      </div>
    </div>
  );
};