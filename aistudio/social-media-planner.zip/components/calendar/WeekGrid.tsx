import React from 'react';
import { MonthPlan, Post } from '../../types';
import { Plus } from 'lucide-react';
import { PlatformIcon } from '../common/PlatformIcon';

interface WeekGridProps {
  month: MonthPlan;
  posts: Post[];
  onSelectPost: (post: Post) => void;
  onAddPost: (dateStr: string) => void;
  currentDate: Date;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const WeekGrid: React.FC<WeekGridProps> = ({ month, posts, onSelectPost, onAddPost }) => {
    // Group posts by day
    const daysMap = new Map<string, Post[]>();
    posts.forEach(p => {
        if(!daysMap.has(p.dateStr)) daysMap.set(p.dateStr, []);
        daysMap.get(p.dateStr)?.push(p);
    });

    const year = month.year;
    const monthIdx = month.monthIndex;
    const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();

    const days = [];
    for(let i=1; i<=daysInMonth; i++) {
        const dateStr = `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        days.push({ day: i, dateStr, posts: daysMap.get(dateStr) || [] });
    }

    const getStatusColor = (status: string) => {
        switch(status) {
            case 'posted': return 'bg-success';
            case 'approved': return 'bg-primary';
            default: return 'bg-text-muted/30';
        }
    };

    return (
        <div className="h-full overflow-x-auto">
            <div className="flex h-full min-w-max">
                {days.map((d, i) => (
                    <div key={i} className="w-64 border-r border-border flex flex-col h-full bg-background hover:bg-surface-highlight/5 transition-colors">
                        <div className="p-4 border-b border-border bg-surface/50 text-center sticky top-0 z-10 backdrop-blur-md">
                            <div className="text-xs text-text-muted font-bold uppercase">{DAYS[new Date(d.dateStr).getDay()]}</div>
                            <div className="text-2xl font-bold text-text-main mt-1">{d.day}</div>
                        </div>
                        <div className="p-3 space-y-3 flex-1 overflow-y-auto custom-scrollbar">
                            {d.posts.map(post => (
                                <div 
                                    key={post.id}
                                    onClick={() => onSelectPost(post)}
                                    className="bg-surface p-3 rounded-xl border border-border cursor-pointer hover:border-primary hover:shadow-lg transition-all group relative overflow-hidden"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-text-muted uppercase">
                                             <PlatformIcon platform={post.platform} size={12} />
                                             {post.platform}
                                        </div>
                                        <div className={`w-2 h-2 rounded-full ${getStatusColor(post.status)}`} title={post.status}></div>
                                    </div>
                                    <p className="text-sm font-bold text-text-main line-clamp-2 mb-2 leading-tight">{post.topic}</p>
                                    
                                    {post.imageUrl && (
                                        <div className="h-28 rounded-lg overflow-hidden relative border border-border mt-2">
                                            <img src={post.imageUrl} className="w-full h-full object-cover" alt="" />
                                        </div>
                                    )}
                                    
                                    <div className="mt-2 pt-2 border-t border-border/50 flex justify-between items-center text-[10px] text-text-muted font-medium">
                                        <span>{post.timeStr || '10:00'}</span>
                                        <span className={`px-1.5 py-0.5 rounded capitalize ${post.status === 'posted' ? 'bg-success/10 text-success' : 'bg-surface-highlight'}`}>{post.status}</span>
                                    </div>
                                </div>
                            ))}
                            <button 
                                onClick={() => onAddPost(d.dateStr)}
                                className="w-full py-3 border border-dashed border-border rounded-xl text-text-muted text-xs font-bold hover:text-primary hover:border-primary hover:bg-surface transition-colors flex items-center justify-center gap-1 opacity-50 hover:opacity-100 group"
                            >
                                <div className="bg-surface p-1 rounded-md border border-border group-hover:border-primary"><Plus size={12} /></div> Add Post
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};