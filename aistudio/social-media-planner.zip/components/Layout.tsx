import React, { useState } from 'react';
import { Brand } from '../types';
import { Sidebar } from './Sidebar';
import { Breadcrumbs } from './Breadcrumbs';
import { Menu, X } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  onNavigate: (view: string) => void;
  currentView: string;
  brands?: Brand[];
  selectedBrandId?: string;
  onSelectBrand?: (brand: Brand) => void;
  breadcrumbs?: { label: string; onClick?: () => void; active?: boolean }[];
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  onNavigate, 
  currentView, 
  brands = [],
  selectedBrandId,
  onSelectBrand,
  breadcrumbs = []
}) => {
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background font-sans text-text-main overflow-hidden">
      
      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-full">
        <Sidebar 
          currentView={currentView}
          brands={brands}
          selectedBrandId={selectedBrandId}
          onNavigate={onNavigate}
          onSelectBrand={(b) => onSelectBrand && onSelectBrand(b)}
        />
      </div>

      {/* Mobile Nav Overlay */}
      {isMobileNavOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMobileNavOpen(false)}></div>
          <div className="relative w-[280px] h-full shadow-2xl animate-in slide-in-from-left bg-surface">
            <button 
              onClick={() => setIsMobileNavOpen(false)}
              className="absolute top-4 right-4 z-50 text-text-muted hover:text-text-main"
            >
              <X size={20} />
            </button>
            <Sidebar 
              currentView={currentView}
              brands={brands}
              selectedBrandId={selectedBrandId}
              onNavigate={(v) => { onNavigate(v); setIsMobileNavOpen(false); }}
              onSelectBrand={(b) => { onSelectBrand && onSelectBrand(b); setIsMobileNavOpen(false); }}
              className="h-full w-full m-0 rounded-none border-none"
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full min-w-0 bg-background relative">
        
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-surface/80 backdrop-blur-md sticky top-0 z-30">
          <div className="font-bold text-lg text-text-main">WhiskContent</div>
          <button 
            onClick={() => setIsMobileNavOpen(true)}
            className="p-2 text-text-muted hover:bg-surface-highlight rounded-lg"
          >
            <Menu size={20} />
          </button>
        </div>

        {/* Content Container */}
        <div className="flex-1 overflow-hidden flex flex-col p-4">
           {breadcrumbs.length > 0 && <Breadcrumbs items={breadcrumbs} />}
           <div className="flex-1 bg-surface rounded-3xl border border-border shadow-2xl overflow-hidden flex flex-col relative">
             {children}
           </div>
        </div>

      </main>
    </div>
  );
};