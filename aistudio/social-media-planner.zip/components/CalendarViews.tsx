import React from 'react';
import { MonthPlan, Post } from '../types';
import { Plus } from 'lucide-react';

interface CalendarViewProps {
  month: MonthPlan;
  posts: Post[];
  onSelectPost: (post: Post) => void;
  currentDate: Date;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const MonthGrid: React.FC<CalendarViewProps> = ({ month, posts, onSelectPost, currentDate }) => {
  // Simple calendar logic
  const year = month.year;
  const monthIdx = month.monthIndex;
  
  const firstDayOfMonth = new Date(year, monthIdx, 1).getDay();
  const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
  
  const days = [];
  // Padding days
  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push({ day: null });
  }
  // Actual days
  for (let i = 1; i <= daysInMonth; i++) {
    days.push({ 
      day: i, 
      dateStr: `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`
    });
  }

  return (
    <div className="h-full flex flex-col bg-background rounded-2xl border border-border overflow-hidden">
      {/* Header */}
      <div className="grid grid-cols-7 border-b border-border bg-surface text-text-muted text-xs font-bold uppercase tracking-wider text-center py-3">
        {DAYS.map(d => <div key={d}>{d}</div>)}
      </div>
      
      {/* Grid */}
      <div className="grid grid-cols-7 flex-1 auto-rows-fr">
        {days.map((d, idx) => {
           const dayPosts = d.dateStr ? posts.filter(p => p.dateStr === d.dateStr) : [];
           return (
             <div key={idx} className={`min-h-[100px] border-b border-r border-border p-2 relative group hover:bg-surface-highlight/10 transition-colors ${!d.day ? 'bg-surface/50' : ''}`}>
                {d.day && (
                    <>
                        <span className={`text-sm font-bold ${d.dateStr === new Date().toISOString().split('T')[0] ? 'bg-primary text-white w-6 h-6 flex items-center justify-center rounded-full' : 'text-text-muted'}`}>
                            {d.day}
                        </span>
                        
                        <div className="mt-2 space-y-1">
                            {dayPosts.map(post => (
                                <button 
                                    key={post.id}
                                    onClick={() => onSelectPost(post)}
                                    className={`w-full text-left text-[10px] px-2 py-1 rounded-md truncate font-medium border-l-2 transition-all hover:brightness-110
                                        ${post.platform === 'Instagram' ? 'bg-pink-500/10 text-pink-500 border-pink-500' : 
                                          post.platform === 'LinkedIn' ? 'bg-blue-600/10 text-blue-500 border-blue-600' : 
                                          post.platform === 'Twitter' ? 'bg-sky-500/10 text-sky-500 border-sky-500' :
                                          'bg-indigo-500/10 text-indigo-500 border-indigo-500'}
                                    `}
                                >
                                    {post.topic}
                                </button>
                            ))}
                        </div>
                        
                        <button className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 p-1 text-text-muted hover:text-primary transition-opacity">
                            <Plus size={14} />
                        </button>
                    </>
                )}
             </div>
           );
        })}
      </div>
    </div>
  );
};

export const WeekGrid: React.FC<CalendarViewProps> = ({ month, posts, onSelectPost }) => {
    // Determine week based on "currentDate" or just show first week for mock
    // For simplicity, just showing a generic horizontal scroll of 7 days around the first post or day 1
    
    // Group posts by day
    const daysMap = new Map<string, Post[]>();
    posts.forEach(p => {
        if(!daysMap.has(p.dateStr)) daysMap.set(p.dateStr, []);
        daysMap.get(p.dateStr)?.push(p);
    });

    const year = month.year;
    const monthIdx = month.monthIndex;
    const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();

    const days = [];
    for(let i=1; i<=daysInMonth; i++) {
        const dateStr = `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        days.push({ day: i, dateStr, posts: daysMap.get(dateStr) || [] });
    }

    return (
        <div className="h-full overflow-x-auto">
            <div className="flex h-full min-w-max">
                {days.map((d, i) => (
                    <div key={i} className="w-48 border-r border-border flex flex-col h-full bg-background hover:bg-surface-highlight/5 transition-colors">
                        <div className="p-4 border-b border-border bg-surface/50 text-center sticky top-0 z-10 backdrop-blur-md">
                            <div className="text-xs text-text-muted font-bold uppercase">{DAYS[new Date(d.dateStr).getDay()]}</div>
                            <div className="text-2xl font-bold text-text-main mt-1">{d.day}</div>
                        </div>
                        <div className="p-3 space-y-3 flex-1 overflow-y-auto">
                            {d.posts.map(post => (
                                <div 
                                    key={post.id}
                                    onClick={() => onSelectPost(post)}
                                    className="bg-surface p-3 rounded-xl border border-border cursor-pointer hover:border-primary hover:shadow-lg transition-all group"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="text-[10px] font-bold text-text-muted uppercase">{post.platform}</span>
                                        {post.status === 'posted' && <div className="w-2 h-2 rounded-full bg-success"></div>}
                                    </div>
                                    <p className="text-xs font-bold text-text-main line-clamp-2">{post.topic}</p>
                                    {post.imageUrl && (
                                        <div className="mt-2 h-20 rounded-lg overflow-hidden relative">
                                            <img src={post.imageUrl} className="w-full h-full object-cover" alt="" />
                                        </div>
                                    )}
                                </div>
                            ))}
                            <button className="w-full py-2 border border-dashed border-border rounded-xl text-text-muted text-xs font-bold hover:text-primary hover:border-primary transition-colors flex items-center justify-center gap-1">
                                <Plus size={12} /> Add Post
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const DayList: React.FC<CalendarViewProps> = ({ posts, onSelectPost }) => {
    return (
        <div className="max-w-3xl mx-auto space-y-4">
            {posts.map(post => (
                <div 
                    key={post.id} 
                    onClick={() => onSelectPost(post)}
                    className="flex gap-4 p-4 bg-surface rounded-2xl border border-border hover:border-primary transition-colors cursor-pointer group"
                >
                    <div className="w-16 flex flex-col items-center justify-center border-r border-border pr-4">
                        <span className="text-xs text-text-muted uppercase font-bold">{new Date(post.dateStr).toLocaleString('en-us', {weekday: 'short'})}</span>
                        <span className="text-2xl font-bold text-text-main">{post.dateStr.split('-')[2]}</span>
                    </div>
                    <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-surface-highlight text-text-muted">{post.platform}</span>
                            <span className="text-xs text-text-muted">{post.objective}</span>
                        </div>
                        <h4 className="text-lg font-bold text-text-main mb-1 group-hover:text-primary transition-colors">{post.topic}</h4>
                        <p className="text-sm text-text-muted line-clamp-2">{post.content || "Content pending..."}</p>
                    </div>
                    {post.imageUrl && (
                        <div className="w-24 h-24 rounded-xl overflow-hidden hidden sm:block">
                            <img src={post.imageUrl} className="w-full h-full object-cover" alt="" />
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
}