import React, { useState } from 'react';
import { Brand, ContentPlan } from '../types';
import { generateStrategicPlan } from '../services/geminiService';
import { PlanService } from '../services/db';
import { Loader2, Wand2, CalendarRange, Target, Layers, CalendarClock } from 'lucide-react';

interface PlanGeneratorProps {
  brand: Brand;
  onPlanCreated: (plan: ContentPlan) => void;
  onCancel: () => void;
}

export const PlanGenerator: React.FC<PlanGeneratorProps> = ({ brand, onPlanCreated, onCancel }) => {
  const [config, setConfig] = useState({
    startDate: new Date().toISOString().split('T')[0],
    monthsCount: 12,
    postsPerMonth: 12,
    focus: 'Brand Awareness & Community Growth'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    setLoading(true);
    setError('');
    
    try {
      const months = await generateStrategicPlan(brand, config.startDate, config.monthsCount, config.postsPerMonth, config.focus);
      
      const startYear = new Date(config.startDate).getFullYear();

      const newPlan: ContentPlan = {
        id: crypto.randomUUID(),
        brandId: brand.id,
        year: startYear, // Primary year reference
        startDate: config.startDate,
        monthsCount: config.monthsCount,
        postsPerMonth: config.postsPerMonth,
        createdAt: Date.now(),
        status: 'planning',
        months
      };

      await PlanService.save(newPlan);
      onPlanCreated(newPlan);
    } catch (e: any) {
      setError(e.message || "Failed to generate plan. Please check API Key and try again.");
    } finally {
      setLoading(false);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="h-full flex items-center justify-center p-4 md:p-8 bg-background">
      <div className="max-w-xl w-full bg-surface rounded-3xl shadow-2xl border border-border overflow-hidden relative">
          {/* Decorative background element */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary"></div>
          
          <div className="p-8">
            <div className="w-12 h-12 bg-surface-highlight rounded-2xl flex items-center justify-center text-primary mb-6 border border-border shadow-inner">
                <Wand2 size={24} />
            </div>

            <h2 className="text-2xl font-bold text-text-main mb-2">Generate Content Strategy</h2>
            <p className="text-text-muted mb-8">
                AI will create a content roadmap for <strong className="text-text-main">{brand.name}</strong> based on your goals.
            </p>

            <div className="space-y-6">
                <div className="flex gap-4">
                    <div className="flex-1 bg-background p-4 rounded-2xl border border-border flex items-center gap-4 focus-within:ring-2 focus-within:ring-primary/50 transition-all">
                        <CalendarRange className="text-text-muted" size={20} />
                        <div className="flex-1">
                            <label className="block text-xs font-bold text-text-muted uppercase">Start Date</label>
                            <input 
                                type="date"
                                min={today}
                                value={config.startDate}
                                onChange={e => setConfig({...config, startDate: e.target.value})}
                                className="w-full bg-transparent font-bold text-text-main outline-none text-sm"
                            />
                        </div>
                    </div>
                    
                    <div className="flex-1 bg-background p-4 rounded-2xl border border-border flex items-center gap-4 focus-within:ring-2 focus-within:ring-primary/50 transition-all">
                        <CalendarClock className="text-text-muted" size={20} />
                        <div className="flex-1">
                            <label className="block text-xs font-bold text-text-muted uppercase">Duration (Months)</label>
                            <input 
                                type="number"
                                min={1}
                                max={24}
                                value={config.monthsCount}
                                onChange={e => setConfig({...config, monthsCount: parseInt(e.target.value)})}
                                className="w-full bg-transparent font-bold text-text-main outline-none text-sm"
                            />
                        </div>
                    </div>
                </div>

                <div className="bg-background p-4 rounded-2xl border border-border flex items-center gap-4 focus-within:ring-2 focus-within:ring-primary/50 transition-all">
                    <Layers className="text-text-muted" size={20} />
                    <div className="flex-1">
                        <label className="block text-xs font-bold text-text-muted uppercase">Posts per Month</label>
                        <input 
                            type="number"
                            min={1}
                            max={30}
                            value={config.postsPerMonth}
                            onChange={e => setConfig({...config, postsPerMonth: parseInt(e.target.value)})}
                            className="w-full bg-transparent font-bold text-text-main outline-none placeholder-text-muted/30"
                        />
                    </div>
                </div>

                <div className="bg-background p-4 rounded-2xl border border-border flex items-start gap-4 focus-within:ring-2 focus-within:ring-primary/50 transition-all">
                    <Target className="text-text-muted mt-1" size={20} />
                    <div className="flex-1">
                        <label className="block text-xs font-bold text-text-muted uppercase mb-1">Strategic Goal</label>
                        <textarea 
                            rows={3}
                            value={config.focus}
                            onChange={e => setConfig({...config, focus: e.target.value})}
                            className="w-full bg-transparent text-sm text-text-main outline-none resize-none placeholder-text-muted/30"
                            placeholder="e.g. Launch new product line..."
                        />
                    </div>
                </div>
            </div>

            {error && (
                <div className="mt-4 bg-red-900/20 border border-red-900/50 text-red-400 p-3 rounded-xl text-sm font-medium">
                    {error}
                </div>
            )}

            <div className="mt-8 flex gap-4">
                <button 
                    onClick={onCancel}
                    disabled={loading}
                    className="flex-1 py-3 text-text-muted font-bold hover:bg-surface-highlight rounded-xl transition-colors"
                >
                    Cancel
                </button>
                <button 
                    onClick={handleGenerate}
                    disabled={loading}
                    className="flex-[2] py-3 bg-primary text-white rounded-xl font-bold flex items-center justify-center gap-2 disabled:opacity-70 btn-3d shadow-3d-primary"
                >
                    {loading ? <Loader2 className="animate-spin" /> : 'Generate Strategy'}
                </button>
            </div>
          </div>
      </div>
    </div>
  );
};