
import React, { useState, useEffect, useRef } from 'react';
import { Brand, Post, ResearchNote, ContentPlan, ChatMessage } from '../types';
import { chatWithResearcher } from '../services/geminiService';
import { Send, Pin, Plus, Sparkles, Loader2, Bot, User, Trash2, Calendar, X, ChevronDown, FlaskConical } from 'lucide-react';
import { useAppStore } from '../store/AppStore';
import { MarkdownText } from './common/MarkdownText';

interface ResearchLabProps {
  brand?: Brand;
  plans: ContentPlan[];
  selectedPlanId?: string;
  selectedMonthIndex?: number;
  onSchedulePost: (post: Post, planId: string, monthIndex: number) => void;
  brands: Brand[];
  onSelectBrand: (brand: Brand) => void;
}

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export const ResearchLab: React.FC<ResearchLabProps> = ({ 
  brand, 
  plans, 
  selectedPlanId, 
  selectedMonthIndex,
  onSchedulePost,
  brands,
  onSelectBrand
}) => {
  const { state, actions } = useAppStore();
  const messages = state.chatSession?.messages || [];
  const notes = state.chatSession?.notes || [];
  
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [creatorMode, setCreatorMode] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scheduling State
  const [draftToSchedule, setDraftToSchedule] = useState<any>(null);
  const [scheduleConfig, setScheduleConfig] = useState<{ planId: string, monthIndex: number }>({
      planId: selectedPlanId || (plans.length > 0 ? plans[0].id : ''),
      monthIndex: selectedMonthIndex !== undefined ? selectedMonthIndex : new Date().getMonth()
  });

  // Scroll to bottom on new message
  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || !brand) return;
    
    const userMsgText = input;
    setInput('');
    setIsLoading(true);

    const userMessage: ChatMessage = { role: 'user', text: userMsgText, timestamp: Date.now() };
    await actions.addChatMessage(brand.id, userMessage);

    try {
      // Need to convert chat history to simpler format for API
      const apiHistory = messages.map(m => ({ role: m.role as 'user' | 'model', text: m.text }));
      const fullHistory = [...apiHistory, { role: 'user' as 'user', text: userMsgText }];

      const responseText = await chatWithResearcher(brand, fullHistory, creatorMode);
      
      // Parse for draft posts if Creator Mode is on
      const draftStart = responseText.indexOf('[[DRAFT_START]]');
      const draftEnd = responseText.indexOf('[[DRAFT_END]]');
      
      let finalResponse = responseText;
      let draftObj = null;

      if (draftStart !== -1 && draftEnd !== -1) {
          const jsonStr = responseText.substring(draftStart + 15, draftEnd);
          try {
             // Clean up any potential markdown code blocks inside the marker
             const cleanJson = jsonStr.replace(/```json/g, '').replace(/```/g, '').trim();
             draftObj = JSON.parse(cleanJson);
             // Remove the JSON block from the visible text to keep chat clean
             finalResponse = responseText.substring(0, draftStart) + responseText.substring(draftEnd + 13);
          } catch(e) {
             console.error("Failed to parse draft", e);
             finalResponse += "\n\n(System: A draft was generated but could not be parsed automatically.)";
          }
      }

      const modelMessage: ChatMessage = { 
          role: 'model', 
          text: finalResponse.trim(), 
          draft: draftObj,
          timestamp: Date.now()
      };
      await actions.addChatMessage(brand.id, modelMessage);

    } catch (e) {
      console.error(e);
      const errorMessage: ChatMessage = { role: 'model', text: "Sorry, I encountered an error researching that.", timestamp: Date.now() };
      await actions.addChatMessage(brand.id, errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinNote = (text: string) => {
    if (!brand) return;
    const note: ResearchNote = {
        id: crypto.randomUUID(),
        content: text,
        category: 'idea',
        createdAt: Date.now()
    };
    actions.addNote(brand.id, note);
  };

  const handleDeleteNote = (noteId: string) => {
      if (!brand) return;
      actions.deleteNote(brand.id, noteId);
  };

  const initiateSchedule = (draft: any) => {
      if (!draft) return;
      
      if (selectedPlanId && selectedMonthIndex !== undefined) {
          setScheduleConfig({ planId: selectedPlanId, monthIndex: selectedMonthIndex });
      } else if (plans.length > 0) {
           setScheduleConfig({ planId: plans[0].id, monthIndex: new Date().getMonth() });
      }
      
      setDraftToSchedule(draft);
  };

  const confirmSchedule = () => {
      if (!draftToSchedule || !scheduleConfig.planId) return;

      const newPost: Post = {
        id: crypto.randomUUID(),
        dateStr: new Date().toISOString().split('T')[0], // Default to today
        timeStr: '10:00',
        platform: draftToSchedule.platform || 'Twitter',
        topic: draftToSchedule.topic || 'New Idea',
        objective: 'Engagement',
        content: draftToSchedule.content,
        hashtags: draftToSchedule.hashtags || [],
        imagePrompt: draftToSchedule.imagePrompt,
        status: 'draft',
        imageStatus: 'idle'
      };

      onSchedulePost(newPost, scheduleConfig.planId, scheduleConfig.monthIndex);
      setDraftToSchedule(null); // Close modal
  };

  if (!brand) {
     return (
        <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-background">
            <div className="bg-surface p-8 rounded-full mb-6 border border-border">
                <Sparkles size={48} className="text-text-muted" />
            </div>
            <h2 className="text-2xl font-bold text-text-main mb-2">Research Lab</h2>
            <p className="text-text-muted max-w-md mb-6">Select a brand to start researching ideas, competitors, and trends.</p>
            
            <div className="relative w-full max-w-xs">
                 <select 
                    className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text-main appearance-none focus:ring-2 focus:ring-primary outline-none font-bold cursor-pointer"
                    onChange={(e) => {
                        const b = brands.find(b => b.id === e.target.value);
                        if(b) onSelectBrand(b);
                    }}
                    defaultValue=""
                 >
                    <option value="" disabled>Select a Brand</option>
                    {brands.map(b => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                 </select>
                 <ChevronDown className="absolute right-4 top-3.5 text-text-muted pointer-events-none" size={16} />
            </div>
        </div>
     );
  }

  return (
    <div className="h-full flex bg-background relative">
       {/* Main Chat Area */}
       <div className="flex-1 flex flex-col min-w-0">
          <div className="p-6 border-b border-border bg-surface flex justify-between items-center">
              <div>
                  <h2 className="text-2xl font-bold text-text-main flex items-center gap-2">
                    <FlaskConical size={24} className="text-primary" /> Research Lab
                  </h2>
                  <p className="text-sm text-text-muted">Exploring ideas for <span className="font-bold text-text-main">{brand.name}</span></p>
              </div>
              
              {/* Toggle Mode Switch */}
              <div className="flex bg-surface-highlight/50 p-1 rounded-xl">
                  <button 
                    onClick={() => setCreatorMode(false)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${!creatorMode ? 'bg-primary text-text-main shadow-md' : 'text-text-muted hover:text-text-main hover:bg-surface-highlight'}`}
                  >
                     Research Mode
                  </button>
                  <button 
                    onClick={() => setCreatorMode(true)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${creatorMode ? 'bg-primary text-white shadow-md' : 'text-text-muted hover:text-text-main hover:bg-surface-highlight'}`}
                  >
                     <Sparkles size={12} /> Creator Mode
                  </button>
              </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6" ref={scrollRef}>
              {messages.map((msg, idx) => (
                  <div key={idx} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-surface-highlight border border-border' : 'bg-primary/10 text-primary border border-primary/20'}`}>
                          {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
                      </div>
                      <div className={`max-w-[80%] space-y-3`}>
                          <div className={`p-4 rounded-2xl ${msg.role === 'user' ? 'bg-surface-highlight text-text-main' : 'bg-surface border border-border text-text-main'}`}>
                             {/* Improved Markdown Rendering */}
                             <MarkdownText content={msg.text} />
                          </div>
                          
                          {/* Draft Card */}
                          {msg.draft && (
                              <div className="bg-background border border-primary/30 rounded-2xl p-4 shadow-lg animate-in zoom-in-95">
                                  <div className="flex justify-between items-start mb-3">
                                      <span className="text-xs font-bold text-primary uppercase tracking-wider bg-primary/10 px-2 py-1 rounded">Draft Generated</span>
                                  </div>
                                  <h4 className="font-bold text-text-main mb-2">{msg.draft.topic}</h4>
                                  <p className="text-xs text-text-muted line-clamp-3 mb-3">{msg.draft.content}</p>
                                  <button 
                                    onClick={() => initiateSchedule(msg.draft)}
                                    className="w-full bg-primary text-white py-2 rounded-xl text-xs font-bold btn-3d shadow-3d-primary flex items-center justify-center gap-2"
                                  >
                                      <Plus size={14} /> Schedule Post
                                  </button>
                              </div>
                          )}

                          {msg.role === 'model' && !msg.draft && (
                              <button 
                                onClick={() => handlePinNote(msg.text)} 
                                className="text-xs text-text-muted hover:text-primary flex items-center gap-1 opacity-50 hover:opacity-100 transition-opacity"
                              >
                                  <Pin size={12} /> Pin to Notes
                              </button>
                          )}
                      </div>
                  </div>
              ))}
              {isLoading && (
                  <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 text-primary border border-primary/20 flex items-center justify-center shrink-0">
                          <Bot size={18} />
                      </div>
                      <div className="bg-surface border border-border p-4 rounded-2xl flex items-center gap-2">
                          <Loader2 className="animate-spin text-text-muted" size={16} />
                          <span className="text-xs font-bold text-text-muted">Thinking...</span>
                      </div>
                  </div>
              )}
          </div>

          <div className="p-6 bg-surface border-t border-border">
              <div className="relative">
                  <textarea 
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => {
                        if(e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                    }}
                    placeholder={creatorMode ? "Ask me to create a post about..." : "Ask me about trends, ideas, or competitors..."}
                    className="w-full bg-background border border-border rounded-2xl pl-4 pr-14 py-4 focus:ring-2 focus:ring-primary focus:border-transparent outline-none resize-none text-sm"
                    rows={2}
                  />
                  <button 
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="absolute right-3 bottom-3 p-2 bg-primary text-white rounded-xl disabled:opacity-50 hover:bg-primary-dark transition-colors"
                  >
                      <Send size={18} />
                  </button>
              </div>
          </div>
       </div>

       {/* Right Sidebar - Notes */}
       <div className="w-80 border-l border-border bg-surface hidden lg:flex flex-col">
           <div className="p-6 border-b border-border">
               <h3 className="font-bold text-text-main flex items-center gap-2"><Pin size={18} className="text-secondary" /> Pinned Ideas</h3>
           </div>
           <div className="flex-1 overflow-y-auto p-4 space-y-3">
               {notes.map(note => (
                   <div key={note.id} className="bg-background border border-border p-4 rounded-xl group relative hover:border-primary/30 transition-colors">
                       <MarkdownText content={note.content} className="text-xs text-text-muted line-clamp-6 mb-2" />
                       <div className="flex justify-between items-center mt-2 pt-2 border-t border-border/50">
                           <span className="text-[10px] text-text-muted">{new Date(note.createdAt).toLocaleDateString()}</span>
                           <button 
                              onClick={() => handleDeleteNote(note.id)}
                              className="text-text-muted hover:text-error opacity-0 group-hover:opacity-100 transition-opacity p-1"
                              title="Delete Note"
                           >
                               <Trash2 size={12} />
                           </button>
                       </div>
                   </div>
               ))}
               {notes.length === 0 && (
                   <div className="text-center py-10 text-text-muted text-xs p-4">
                       Pin interesting insights from the chat here to save them for later.
                   </div>
               )}
           </div>
       </div>

       {/* Scheduling Modal */}
       {draftToSchedule && (
           <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
               <div className="bg-surface rounded-3xl shadow-2xl w-full max-w-md animate-in zoom-in-95 border border-border overflow-hidden">
                   <div className="p-6 border-b border-border flex justify-between items-center">
                       <h3 className="text-lg font-bold text-text-main flex items-center gap-2">
                           <Calendar size={18} className="text-primary" /> Schedule to Plan
                       </h3>
                       <button onClick={() => setDraftToSchedule(null)} className="text-text-muted hover:text-text-main">
                           <X size={20} />
                       </button>
                   </div>
                   
                   <div className="p-6 space-y-4">
                       <p className="text-sm text-text-muted mb-2">Select which plan to add this post to:</p>
                       
                       {plans.length > 0 ? (
                           <>
                               <div>
                                   <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Yearly Plan</label>
                                   <select 
                                       className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                       value={scheduleConfig.planId}
                                       onChange={e => setScheduleConfig({...scheduleConfig, planId: e.target.value})}
                                   >
                                       {plans.map(p => (
                                           <option key={p.id} value={p.id}>{p.year} Strategy ({p.status})</option>
                                       ))}
                                   </select>
                               </div>

                               <div>
                                   <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Month</label>
                                   <select 
                                       className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                       value={scheduleConfig.monthIndex}
                                       onChange={e => setScheduleConfig({...scheduleConfig, monthIndex: parseInt(e.target.value)})}
                                   >
                                       {MONTH_NAMES.map((name, idx) => (
                                           <option key={idx} value={idx}>{name}</option>
                                       ))}
                                   </select>
                               </div>
                           </>
                       ) : (
                           <div className="bg-warning/10 text-warning p-4 rounded-xl text-sm font-medium border border-warning/20">
                               No content plans found. Please go to the Dashboard and create a Yearly Strategy first.
                           </div>
                       )}

                   </div>

                   <div className="p-4 bg-surface-highlight/10 border-t border-border flex justify-end gap-3">
                       <button 
                           onClick={() => setDraftToSchedule(null)}
                           className="px-4 py-2 text-sm font-bold text-text-muted hover:text-text-main"
                       >
                           Cancel
                       </button>
                       <button 
                           onClick={confirmSchedule}
                           disabled={!scheduleConfig.planId || plans.length === 0}
                           className="bg-primary text-white px-6 py-2 rounded-xl text-sm font-bold btn-3d shadow-3d-primary disabled:opacity-50 disabled:shadow-none"
                       >
                           Confirm Schedule
                       </button>
                   </div>
               </div>
           </div>
       )}
    </div>
  );
};
