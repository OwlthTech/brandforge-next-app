import React, { useState } from 'react';
import { Post } from '../../types';
import { Send, RefreshCw, MoreHorizontal, Image as ImageIcon, Loader2, ExternalLink, Maximize2, Edit } from 'lucide-react';
import { PlatformIcon } from '../common/PlatformIcon';

interface PostCardProps {
  post: Post;
  onGenerateImage: (post: Post) => void;
  onRevise: (post: Post) => void;
  onSend: (post: Post) => void;
  onViewDetail: (post: Post) => void;
  onEdit: (post: Post) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ 
  post, 
  onGenerateImage, 
  onRevise, 
  onSend,
  onViewDetail,
  onEdit
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const isPosted = post.status === 'posted';
  
  // Hashtag cleanup (remove duplicate #)
  const cleanHashtags = (post.hashtags || []).map(t => t.replace(/^#+/, ''));
  const fullContent = post.content || '';
  const isLongContent = fullContent.length > 150;

  // Function to view image in new tab
  const handleViewImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (post.imageUrl) {
        const newWindow = window.open();
        if (newWindow) {
            newWindow.document.write(`<img src="${post.imageUrl}" style="max-width:100%; height:auto;" />`);
        }
    }
  };

  const getPlatformColor = (p: string) => {
    switch(p) {
        case 'Twitter': return 'text-sky-500 border-sky-500/20 bg-sky-500/10';
        case 'LinkedIn': return 'text-blue-600 border-blue-600/20 bg-blue-600/10';
        case 'Instagram': return 'text-pink-500 border-pink-500/20 bg-pink-500/10';
        case 'Facebook': return 'text-indigo-600 border-indigo-600/20 bg-indigo-600/10';
        default: return 'text-text-muted border-border bg-surface-highlight';
    }
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'posted': return 'bg-success/10 text-success border-success/30';
          case 'approved': return 'bg-primary/10 text-primary border-primary/30';
          default: return 'bg-surface-highlight text-text-muted border-border';
      }
  };

  return (
    <div className={`relative flex flex-col h-full rounded-3xl transition-all duration-300 hover:shadow-2xl bg-surface border-2 border-border group overflow-hidden`}>
      
      {/* Header */}
      <div className="flex justify-between items-start p-5 pb-3">
        <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold bg-background border border-border text-text-main shadow-inner`}>
                {post.dateStr.split('-')[2]}
            </div>
            <div>
                <div className="flex items-center gap-2 mb-1">
                    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-md w-fit ${getPlatformColor(post.platform)}`}>
                        <PlatformIcon platform={post.platform} size={10} />
                        <p className="text-[10px] font-bold uppercase tracking-wider">{post.platform}</p>
                    </div>
                    {/* Status Pill */}
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${getStatusColor(post.status)}`}>
                        {post.status}
                    </span>
                </div>
                <p className="text-sm font-bold text-text-main line-clamp-1 cursor-pointer hover:text-primary" onClick={() => onViewDetail(post)}>
                    {post.topic}
                </p>
            </div>
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button 
                onClick={(e) => { e.stopPropagation(); onEdit(post); }}
                className="text-text-muted hover:text-text-main transition-colors bg-surface-highlight/50 p-2 rounded-lg hover:bg-surface-highlight"
                title="Edit Post"
            >
                <Edit size={16} />
            </button>
            <button 
                onClick={(e) => { e.stopPropagation(); onRevise(post); }}
                className="text-text-muted hover:text-text-main transition-colors bg-surface-highlight/50 p-2 rounded-lg hover:bg-surface-highlight"
                title="AI Revise"
            >
                <MoreHorizontal size={20} />
            </button>
        </div>
      </div>

      {/* Image Area */}
      <div className="px-5">
        <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-background border border-border group/img">
            {post.imageUrl ? (
                <>
                    <img 
                        src={post.imageUrl} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover/img:scale-105" 
                        alt="Post" 
                    />
                    
                    {/* View in New Tab Button - Centered */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
                         <button 
                            onClick={handleViewImage}
                            className="bg-white/90 text-black px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 hover:bg-white shadow-xl transform transition-transform hover:scale-105"
                         >
                            <ExternalLink size={14} /> View Full
                         </button>
                    </div>

                    {/* Regenerate Button - Bottom Right */}
                    <button 
                        onClick={(e) => { e.stopPropagation(); onGenerateImage(post); }} 
                        className="absolute bottom-3 right-3 bg-surface/80 backdrop-blur-md text-text-main p-2 rounded-lg border border-white/10 hover:bg-primary hover:text-white transition-colors shadow-lg opacity-0 group-hover/img:opacity-100"
                        title="Regenerate Image"
                    >
                        <RefreshCw size={16} />
                    </button>
                </>
            ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-text-muted p-4 text-center">
                    {post.imageStatus === 'generating' ? (
                        <>
                            <Loader2 className="animate-spin mb-3 text-primary" size={32} />
                            <span className="text-xs font-medium animate-pulse">Generating Art...</span>
                        </>
                    ) : (
                        <>
                            <ImageIcon size={32} className="mb-3 opacity-30" />
                            <span className="text-xs font-medium opacity-70 mb-3">No Image</span>
                            {post.imagePrompt && (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onGenerateImage(post); }} 
                                    className="text-xs bg-surface-highlight border border-border px-4 py-2 rounded-xl text-text-main hover:border-primary hover:text-primary transition-all font-semibold"
                                >
                                    Generate
                                </button>
                            )}
                        </>
                    )}
                </div>
            )}
        </div>
      </div>

      {/* Content Body */}
      <div className="flex-1 p-5 flex flex-col">
        <div className="bg-background rounded-xl p-4 mb-4 border border-border flex-1 relative">
            <p className={`text-xs text-text-muted leading-relaxed whitespace-pre-wrap ${!isExpanded ? 'line-clamp-3' : ''}`}>
                {fullContent || <span className="italic opacity-50">Content pending...</span>}
            </p>
            {isLongContent && (
                <button 
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="text-[10px] font-bold text-primary mt-2 hover:underline focus:outline-none"
                >
                    {isExpanded ? 'Show Less' : 'Read More'}
                </button>
            )}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
            {cleanHashtags.slice(0, 3).map((t, i) => (
                <span key={i} className="text-[10px] bg-surface-highlight border border-border px-2 py-1 rounded-md text-text-muted font-medium">#{t}</span>
            ))}
            {cleanHashtags.length > 3 && (
                <span className="text-[10px] text-text-muted px-1 py-1">+{cleanHashtags.length - 3}</span>
            )}
        </div>
        
        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-border mt-auto">
            <button 
                onClick={() => onViewDetail(post)}
                className="text-xs font-bold text-text-muted hover:text-primary flex items-center gap-1 transition-colors"
            >
                <Maximize2 size={12} /> Details
            </button>
            
            {isPosted ? (
                <span className="text-xs font-bold text-success flex items-center gap-1">
                     View on {post.platform}
                </span>
            ) : (
                <button 
                    onClick={() => onSend(post)}
                    className="flex items-center gap-2 bg-text-main text-background px-4 py-2 rounded-xl text-xs font-bold hover:bg-white transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                >
                    <Send size={12} /> Post Now
                </button>
            )}
        </div>
      </div>
    </div>
  );
};