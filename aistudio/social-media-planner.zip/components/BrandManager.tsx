import React, { useState, useEffect } from 'react';
import { Brand } from '../types';
import { BrandService } from '../services/db';
import { fetchBrandDetailsFromMaps } from '../services/geminiService';
import { Plus, Trash2, ArrowRight, MapPin, Loader2, Search, TrendingUp, Users, Activity } from 'lucide-react';
import { PlatformIcon } from './common/PlatformIcon';

interface BrandManagerProps {
  onSelectBrand: (brand: Brand) => void;
}

export const BrandManager: React.FC<BrandManagerProps> = ({ onSelectBrand }) => {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newBrand, setNewBrand] = useState<Partial<Brand>>({});
  const [mapQuery, setMapQuery] = useState('');
  const [isSearchingMap, setIsSearchingMap] = useState(false);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | undefined>(undefined);

  useEffect(() => {
    loadBrands();
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => console.log("Geolocation denied or error:", err)
      );
    }
  }, []);

  const loadBrands = async () => {
    const list = await BrandService.getAll();
    setBrands(list);
  };

  const handleSearchMap = async () => {
    if (!mapQuery.trim()) return;
    setIsSearchingMap(true);
    try {
      const details = await fetchBrandDetailsFromMaps(mapQuery, userLocation);
      setNewBrand({ ...newBrand, ...details });
    } catch (e: any) {
      alert(e.message || "Could not fetch details from Maps.");
    } finally {
      setIsSearchingMap(false);
    }
  };

  const handleCreate = async () => {
    if (!newBrand.name || !newBrand.description) return;
    const brand: Brand = {
      id: crypto.randomUUID(),
      name: newBrand.name!,
      description: newBrand.description!,
      tone: newBrand.tone || 'Professional',
      targetAudience: newBrand.targetAudience || 'General',
      website: newBrand.website || ''
    };
    await BrandService.save(brand);
    setNewBrand({});
    setMapQuery('');
    setIsCreating(false);
    loadBrands();
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Delete this brand?')) {
      await BrandService.delete(id);
      loadBrands();
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header Section */}
      <div className="px-6 py-6 md:px-8 md:py-8 flex justify-between items-center bg-surface sticky top-0 z-10 border-b border-border">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-text-main tracking-tight">Analytics</h2>
          <p className="text-text-muted mt-1 font-medium text-sm">Overview of your brand portfolio</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-xl flex items-center gap-2 text-sm font-bold"
        >
          <Plus size={18} /> <span className="hidden sm:inline">Add Brand</span>
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6 md:px-8 md:py-8">
        
        {/* Analytics Summary - Placeholder */}
        {!isCreating && brands.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-surface p-5 rounded-2xl border border-border flex items-center gap-4">
                    <div className="bg-emerald-500/10 p-3 rounded-xl text-emerald-500"><TrendingUp size={24} /></div>
                    <div>
                        <p className="text-xs text-text-muted font-bold uppercase">Total Brands</p>
                        <p className="text-2xl font-bold text-text-main">{brands.length}</p>
                    </div>
                </div>
                <div className="bg-surface p-5 rounded-2xl border border-border flex items-center gap-4">
                    <div className="bg-blue-500/10 p-3 rounded-xl text-blue-500"><Activity size={24} /></div>
                    <div>
                        <p className="text-xs text-text-muted font-bold uppercase">Active Plans</p>
                        <p className="text-2xl font-bold text-text-main">{Math.max(1, Math.floor(brands.length * 0.8))}</p>
                    </div>
                </div>
                <div className="bg-surface p-5 rounded-2xl border border-border flex items-center gap-4">
                    <div className="bg-purple-500/10 p-3 rounded-xl text-purple-500"><Users size={24} /></div>
                    <div>
                        <p className="text-xs text-text-muted font-bold uppercase">Audience Reach</p>
                        <p className="text-2xl font-bold text-text-main">24.5k</p>
                    </div>
                </div>
            </div>
        )}

        {isCreating && (
          <div className="mb-8 bg-background p-6 md:p-8 rounded-3xl border border-border animate-in fade-in slide-in-from-top-4 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-6">
                <button onClick={() => setIsCreating(false)} className="text-text-muted hover:text-text-main bg-surface p-2 rounded-full border border-border">✕</button>
            </div>
            
            <h3 className="text-xl font-bold text-text-main mb-6">Add Your Brand</h3>

            <div className="flex flex-col lg:flex-row gap-6 items-start">
                 {/* Left Col - Map Search */}
                 <div className="w-full lg:w-1/3 bg-surface-highlight/30 p-6 rounded-2xl border border-border">
                     <div className="flex items-center gap-2 text-primary font-semibold mb-4">
                        <div className="bg-background p-2 rounded-lg border border-border text-primary"><MapPin size={20} /></div>
                        Auto-fill with Maps
                     </div>
                     <div className="relative">
                        <input 
                            className="w-full pl-10 pr-4 py-3 bg-background border border-border text-text-main rounded-xl shadow-inner focus:ring-2 focus:ring-primary focus:border-transparent text-sm placeholder-text-muted/50 outline-none"
                            placeholder="Search business..."
                            value={mapQuery}
                            onChange={e => setMapQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSearchMap()}
                        />
                        <Search className="absolute left-3 top-3.5 text-text-muted" size={16} />
                     </div>
                     <button 
                        onClick={handleSearchMap}
                        disabled={isSearchingMap || !mapQuery}
                        className="w-full mt-3 bg-surface border border-border text-text-main py-2.5 rounded-xl font-medium text-sm hover:bg-surface-highlight disabled:opacity-50 flex justify-center items-center gap-2 btn-3d shadow-3d-secondary"
                     >
                        {isSearchingMap ? <Loader2 className="animate-spin" size={16} /> : 'Fetch Details'}
                     </button>
                 </div>

                 {/* Right Col - Form */}
                 <div className="flex-1 grid grid-cols-2 gap-4 w-full">
                     <div className="col-span-2">
                        <label className="text-xs font-bold text-text-muted uppercase tracking-wide mb-1.5 block">Brand Name</label>
                        <input 
                            className="w-full bg-background border border-border text-text-main rounded-xl p-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                            placeholder="Brand Name"
                            value={newBrand.name || ''}
                            onChange={e => setNewBrand({...newBrand, name: e.target.value})}
                        />
                     </div>
                     <div className="col-span-2">
                        <label className="text-xs font-bold text-text-muted uppercase tracking-wide mb-1.5 block">Description</label>
                        <textarea 
                            className="w-full bg-background border border-border text-text-main rounded-xl p-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none" 
                            rows={2}
                            placeholder="Description"
                            value={newBrand.description || ''}
                            onChange={e => setNewBrand({...newBrand, description: e.target.value})}
                        />
                     </div>
                     <div className="col-span-2 sm:col-span-1">
                        <label className="text-xs font-bold text-text-muted uppercase tracking-wide mb-1.5 block">Tone</label>
                        <input 
                            className="w-full bg-background border border-border text-text-main rounded-xl p-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                            placeholder="e.g. Friendly"
                            value={newBrand.tone || ''}
                            onChange={e => setNewBrand({...newBrand, tone: e.target.value})}
                        />
                     </div>
                     <div className="col-span-2 sm:col-span-1">
                        <label className="text-xs font-bold text-text-muted uppercase tracking-wide mb-1.5 block">Audience</label>
                        <input 
                            className="w-full bg-background border border-border text-text-main rounded-xl p-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                            placeholder="e.g. Techies"
                            value={newBrand.targetAudience || ''}
                            onChange={e => setNewBrand({...newBrand, targetAudience: e.target.value})}
                        />
                     </div>
                     
                     <div className="col-span-2 flex justify-end gap-3 mt-4">
                         <button 
                            onClick={handleCreate}
                            disabled={!newBrand.name}
                            className="bg-primary text-white px-8 py-3 rounded-xl font-bold btn-3d shadow-3d-primary disabled:opacity-50 disabled:shadow-none disabled:cursor-not-allowed"
                         >
                            Create Brand
                         </button>
                     </div>
                 </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {brands.map((brand, idx) => {
             // Dark theme "pastel" accents
             const accents = [
                 'border-l-4 border-l-primary hover:shadow-primary/10',
                 'border-l-4 border-l-emerald-500 hover:shadow-emerald-900/10',
                 'border-l-4 border-l-purple-500 hover:shadow-purple-900/10',
                 'border-l-4 border-l-amber-500 hover:shadow-amber-900/10',
             ];
             const accentClass = accents[idx % accents.length];
             
             return (
              <div 
                key={brand.id} 
                onClick={() => onSelectBrand(brand)}
                className={`group relative p-5 rounded-2xl cursor-pointer transition-all duration-300 bg-surface-highlight/50 border border-border hover:-translate-y-1 hover:shadow-lg ${accentClass}`}
              >
                <div className="flex justify-between items-start mb-3">
                    <span className="bg-background border border-border px-2 py-0.5 rounded-md text-[10px] font-bold text-text-muted uppercase tracking-wider group-hover:text-text-main transition-colors">
                       {brand.tone}
                    </span>
                    <button 
                        onClick={(e) => handleDelete(e, brand.id)}
                        className="p-1.5 bg-background rounded-full hover:text-error transition-colors opacity-0 group-hover:opacity-100 border border-border"
                    >
                        <Trash2 size={14} />
                    </button>
                </div>

                <h3 className="text-xl font-bold mb-1.5 text-text-main truncate">{brand.name}</h3>
                <p className="text-xs font-medium text-text-muted line-clamp-2 mb-4 h-8">{brand.description}</p>
                
                <div className="flex items-center justify-between mt-auto pt-3 border-t border-border/50">
                   <div className="flex -space-x-1.5">
                      <div className="w-6 h-6 rounded-full bg-background border border-surface flex items-center justify-center text-text-muted hover:z-10 relative">
                        <PlatformIcon platform="Instagram" size={12} />
                      </div>
                      <div className="w-6 h-6 rounded-full bg-background border border-surface flex items-center justify-center text-text-muted hover:z-10 relative">
                        <PlatformIcon platform="LinkedIn" size={12} />
                      </div>
                      <div className="w-6 h-6 rounded-full bg-background border border-surface flex items-center justify-center text-text-muted hover:z-10 relative">
                        <PlatformIcon platform="Twitter" size={12} />
                      </div>
                   </div>
                   <div className="text-xs font-bold text-primary group-hover:underline">View Strategy</div>
                </div>
              </div>
            );
          })}

          {brands.length === 0 && !isCreating && (
             <div className="col-span-full py-20 flex flex-col items-center justify-center text-text-muted bg-surface-highlight/20 rounded-3xl border-2 border-dashed border-border">
                <div className="bg-surface p-4 rounded-full border border-border mb-4"><Plus size={32} className="text-text-muted" /></div>
                <p className="font-medium">No brands yet.</p>
                <button onClick={() => setIsCreating(true)} className="mt-2 text-primary font-bold hover:underline">Create your first brand</button>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};