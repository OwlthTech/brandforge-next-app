
import React from 'react';

interface MarkdownTextProps {
  content: string;
  className?: string;
}

export const MarkdownText: React.FC<MarkdownTextProps> = ({ content, className = "" }) => {
  // Simple regex-based markdown parser for basic formatting
  // Supports: Bold (**), Italic (*), Lists (-), Headers (#)
  
  const parseMarkdown = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, index) => {
      // Headers
      if (line.startsWith('### ')) return <h4 key={index} className="text-sm font-bold mt-2 mb-1 text-text-main">{parseInline(line.substring(4))}</h4>;
      if (line.startsWith('## ')) return <h3 key={index} className="text-base font-bold mt-3 mb-2 text-text-main">{parseInline(line.substring(3))}</h3>;
      if (line.startsWith('# ')) return <h2 key={index} className="text-lg font-bold mt-4 mb-2 text-text-main">{parseInline(line.substring(2))}</h2>;
      
      // List items
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        return (
          <li key={index} className="ml-4 list-disc pl-1 mb-1">
            {parseInline(line.trim().substring(2))}
          </li>
        );
      }

      // Empty lines
      if (!line.trim()) return <br key={index} />;

      // Paragraphs
      return <p key={index} className="mb-1">{parseInline(line)}</p>;
    });
  };

  const parseInline = (text: string) => {
    // Bold (**text**)
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);
    
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-primary">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="italic">{part.slice(1, -1)}</em>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
          return <code key={i} className="bg-surface-highlight px-1 py-0.5 rounded text-xs font-mono">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  return <div className={`text-sm leading-relaxed text-text-main ${className}`}>{parseMarkdown(content)}</div>;
};
