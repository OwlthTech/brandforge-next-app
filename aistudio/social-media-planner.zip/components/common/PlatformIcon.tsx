import React from 'react';
import { Twitter, Linkedin, Instagram, Facebook, Globe } from 'lucide-react';
import { Platform } from '../../types';

interface PlatformIconProps {
  platform: Platform | string;
  size?: number;
  className?: string;
}

export const PlatformIcon: React.FC<PlatformIconProps> = ({ platform, size = 16, className = "" }) => {
  switch (platform) {
    case 'Twitter':
    case 'X':
      return <Twitter size={size} className={className} />;
    case 'LinkedIn':
      return <Linkedin size={size} className={className} />;
    case 'Instagram':
      return <Instagram size={size} className={className} />;
    case 'Facebook':
      return <Facebook size={size} className={className} />;
    default:
      return <Globe size={size} className={className} />;
  }
};