import React, { useState, useEffect } from 'react';
import { Brand, ContentPlan, MonthPlan, Post } from '../types';
import { generateMonthlyDetails, generatePostImage, revisePost } from '../services/geminiService';
import { PlanService } from '../services/db';
import { sendPostToN8n } from '../services/n8nService';
import { exportMonthPlanToCSV } from '../services/exportService';
import { PostCard } from './post/PostCard';
import { PostEditModal } from './post/PostEditModal';
import { PostRevisionModal } from './post/PostRevisionModal';
import { MonthGrid } from './calendar/MonthGrid';
import { WeekGrid } from './calendar/WeekGrid';
import { DayList } from './calendar/DayList';
import { ArrowLeft, Loader2, LayoutGrid, Download } from 'lucide-react';

type ViewMode = 'grid' | 'month' | 'week' | 'day';

interface MonthlyViewProps {
  brand: Brand;
  plan: ContentPlan;
  month: MonthPlan;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onBack: () => void;
  onUpdatePlan: (updatedPlan: ContentPlan) => void;
  onViewPostDetail: (post: Post) => void;
}

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export const MonthlyView: React.FC<MonthlyViewProps> = ({ 
  brand, 
  plan, 
  month, 
  viewMode, 
  onViewModeChange, 
  onBack, 
  onUpdatePlan, 
  onViewPostDetail 
}) => {
  const [posts, setPosts] = useState<Post[]>(month.posts);
  const [generatingDetails, setGeneratingDetails] = useState(false);
  
  // Revision State
  const [revisingPost, setRevisingPost] = useState<Post | null>(null);
  const [loadingRevision, setLoadingRevision] = useState(false);
  
  // Edit State
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  
  const isDetailed = posts.some(p => p.content);

  useEffect(() => {
    // Sync posts if month prop updates
    setPosts(month.posts);
  }, [month]);

  useEffect(() => {
    const initDetails = async () => {
      if (plan.status !== 'planning' && !isDetailed && !generatingDetails && posts.length > 0) {
        setGeneratingDetails(true);
        try {
          const detailedMonth = await generateMonthlyDetails(brand, month);
          setPosts(detailedMonth.posts);
          await updatePlanWithMonth(detailedMonth);
          // Only generate first image automatically if it's missing
          if (detailedMonth.posts.length > 0) {
             const first = detailedMonth.posts[0];
             if (!first.imageUrl && first.imageStatus === 'idle') {
                handleGenerateImage(first);
             }
          }
        } catch (e) {
          console.error(e);
        } finally {
          setGeneratingDetails(false);
        }
      } else if (plan.status !== 'planning' && isDetailed) {
          // If already detailed, check first post image
          const firstPost = posts[0];
          if (firstPost && !firstPost.imageUrl && firstPost.imageStatus === 'idle') {
              handleGenerateImage(firstPost);
          }
      }
    };
    initDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan.status]);

  const updatePlanWithMonth = async (updatedMonth: MonthPlan) => {
    const updatedMonths = plan.months.map(m => m.monthIndex === updatedMonth.monthIndex ? updatedMonth : m);
    const updatedPlan = { ...plan, months: updatedMonths };
    await PlanService.save(updatedPlan);
    onUpdatePlan(updatedPlan);
    return updatedPlan;
  };

  const handleUpdatePost = async (updatedPost: Post) => {
    // Check if new post or existing
    const exists = posts.find(p => p.id === updatedPost.id);
    let newPosts;
    if (exists) {
        newPosts = posts.map(p => p.id === updatedPost.id ? updatedPost : p);
    } else {
        newPosts = [...posts, updatedPost];
    }
    
    setPosts(newPosts);
    const updatedMonth = { ...month, posts: newPosts };
    await updatePlanWithMonth(updatedMonth);
  };

  const handleSaveEdit = async (postToSave: Post) => {
    await handleUpdatePost(postToSave);
    setEditingPost(null);
  };

  const handleGenerateImage = async (post: Post) => {
    if (!post.imagePrompt) return;
    handleUpdatePost({ ...post, imageStatus: 'generating' });
    try {
      const imageUrl = await generatePostImage(post.imagePrompt);
      handleUpdatePost({ ...post, imageUrl, imageStatus: 'completed' });
    } catch (e) {
      handleUpdatePost({ ...post, imageStatus: 'failed' });
    }
  };

  const handleRevisePost = async (post: Post, instruction: string) => {
    setLoadingRevision(true);
    try {
      const index = posts.findIndex(p => p.id === post.id);
      const prev = index > 0 ? posts[index - 1] : undefined;
      const next = index < posts.length - 1 ? posts[index + 1] : undefined;
      
      const revised = await revisePost(brand, post, { prev, next }, instruction);
      await handleUpdatePost(revised);
      setRevisingPost(null);
    } catch (e) {
      alert("Revision failed");
    } finally {
      setLoadingRevision(false);
    }
  };

  const handleSendToN8N = async (post: Post) => {
    if (confirm(`Send post to ${post.platform}?`)) {
        await sendPostToN8n(brand, post);
        await handleUpdatePost({ ...post, status: 'posted' });
    }
  };

  const handleAddPost = (dateStr?: string) => {
      const newPost: Post = {
          id: crypto.randomUUID(),
          dateStr: dateStr || new Date().toISOString().split('T')[0],
          platform: 'Twitter',
          topic: 'New Post',
          objective: 'Engagement',
          status: 'draft',
          imageStatus: 'idle',
          content: '',
          hashtags: [],
          imagePrompt: ''
      };
      setEditingPost(newPost);
  };

  const handleExport = () => {
    exportMonthPlanToCSV({ ...month, posts });
  };

  if (generatingDetails) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-text-muted gap-4 bg-background">
            <Loader2 className="animate-spin text-primary" size={48} />
            <p className="text-lg font-medium">Generating creative content for {MONTH_NAMES[month.monthIndex]}...</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-background relative">
      {/* Header */}
      <div className="bg-surface border-b border-border px-6 py-5 flex flex-col md:flex-row items-center justify-between sticky top-0 z-20 gap-4">
        <div className="flex items-center gap-6 w-full md:w-auto">
          <button onClick={onBack} className="w-10 h-10 flex items-center justify-center hover:bg-surface-highlight rounded-xl transition-colors text-text-muted">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-text-main">{MONTH_NAMES[month.monthIndex]}, {month.year}</h2>
            <div className="flex gap-2 mt-2 bg-surface-highlight/90 p-1 rounded-lg inline-flex">
               <button onClick={() => onViewModeChange('month')} className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'month' ? 'bg-surface shadow text-primary font-bold' : 'text-text-muted hover:text-text-main'}`}>Month</button>
               <button onClick={() => onViewModeChange('week')} className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'week' ? 'bg-surface shadow text-primary font-bold' : 'text-text-muted hover:text-text-main'}`}>Week</button>
               <button onClick={() => onViewModeChange('day')} className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'day' ? 'bg-surface shadow text-primary font-bold' : 'text-text-muted hover:text-text-main'}`}>Day</button>
               <div className="w-px bg-border mx-1"></div>
               <button onClick={() => onViewModeChange('grid')} className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'grid' ? 'bg-surface shadow text-primary font-bold' : 'text-text-muted hover:text-text-main'}`} title="Card Grid"><LayoutGrid size={14} /></button>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
             <button onClick={handleExport} className="bg-surface hover:bg-surface-highlight text-text-main border border-border px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all">
                <Download size={16} /> Export
             </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8 relative">
        
        {viewMode === 'grid' && (
             <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 pb-20">
                {posts.map((post) => (
                    <div key={post.id} className="h-full">
                        <PostCard 
                            post={post}
                            onGenerateImage={handleGenerateImage}
                            onRevise={(p) => setRevisingPost(p)}
                            onEdit={(p) => setEditingPost(p)}
                            onSend={handleSendToN8N}
                            onViewDetail={onViewPostDetail}
                        />
                    </div>
                ))}
                {posts.length === 0 && (
                    <div className="col-span-full py-20 text-center text-text-muted">No posts scheduled. Switch to calendar view to add one.</div>
                )}
             </div>
        )}

        {viewMode === 'month' && (
            <div className="h-full min-h-[600px]">
                <MonthGrid 
                    month={month} 
                    posts={posts} 
                    onSelectPost={onViewPostDetail} 
                    onAddPost={handleAddPost}
                    currentDate={new Date()}
                />
            </div>
        )}

        {viewMode === 'week' && (
             <div className="h-full min-h-[500px]">
                <WeekGrid 
                    month={month}
                    posts={posts}
                    onSelectPost={onViewPostDetail}
                    onAddPost={handleAddPost}
                    currentDate={new Date()}
                />
            </div>
        )}

        {viewMode === 'day' && (
            <DayList 
                month={month}
                posts={posts}
                onSelectPost={onViewPostDetail}
                onAddPost={handleAddPost}
                currentDate={new Date()}
            />
        )}
      </div>

      {editingPost && (
          <PostEditModal 
            post={editingPost}
            onClose={() => setEditingPost(null)}
            onSave={handleSaveEdit}
            onChange={setEditingPost}
          />
      )}

      {revisingPost && (
          <PostRevisionModal
            post={revisingPost}
            onClose={() => setRevisingPost(null)}
            onRevise={handleRevisePost}
            isLoading={loadingRevision}
          />
      )}

    </div>
  );
};