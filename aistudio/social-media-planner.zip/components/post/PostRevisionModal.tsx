import React, { useState } from 'react';
import { Post } from '../../types';
import { Calendar, Clock, Loader2 } from 'lucide-react';

interface PostRevisionModalProps {
    post: Post;
    onClose: () => void;
    onRevise: (post: Post, instruction: string) => void;
    isLoading: boolean;
}

export const PostRevisionModal: React.FC<PostRevisionModalProps> = ({ post, onClose, onRevise, isLoading }) => {
    const [prompt, setPrompt] = useState("");

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-surface rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200 border border-border">
                <div className="p-6 border-b border-border">
                    <h3 className="text-lg font-bold text-text-main">Revise Post Content</h3>
                    <p className="text-xs text-text-muted">AI will rewrite content based on your instructions.</p>
                </div>
                
                <div className="p-6 space-y-4">
                    <div className="flex gap-4 mb-2">
                        <div className="flex-1 bg-background p-3 rounded-xl border border-border">
                            <div className="flex items-center gap-2 text-xs font-bold text-text-muted mb-1"><Calendar size={12} /> Date</div>
                            <div className="text-sm font-semibold text-text-main">
                                {post.dateStr}
                            </div>
                        </div>
                        <div className="flex-1 bg-background p-3 rounded-xl border border-border">
                             <div className="flex items-center gap-2 text-xs font-bold text-text-muted mb-1"><Clock size={12} /> Platform</div>
                             <div className="text-sm font-semibold text-text-main">
                                {post.platform}
                            </div>
                        </div>
                    </div>
                    
                    <textarea 
                        className="w-full bg-background border border-border rounded-xl p-4 text-sm focus:ring-2 focus:ring-primary min-h-[120px] text-text-main outline-none resize-none"
                        placeholder="Tell AI what to change (e.g. 'Make it funnier', 'Focus on sales', 'Change image to a cat')"
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                    />
                    
                    <div className="flex flex-wrap gap-2">
                        {['Make it shorter', 'More professional', 'Add emojis', 'Focus on engagement'].map(opt => (
                            <button 
                                key={opt}
                                onClick={() => setPrompt(opt)} 
                                className="text-[10px] bg-primary/10 text-primary px-2 py-1 rounded-lg font-medium hover:bg-primary/20 border border-primary/20"
                            >
                                {opt}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="p-4 bg-background border-t border-border flex justify-end gap-3">
                    <button 
                        onClick={onClose}
                        className="px-4 py-2 text-sm font-bold text-text-muted hover:text-text-main"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={() => onRevise(post, prompt)}
                        disabled={isLoading || !prompt}
                        className="bg-primary text-white px-6 py-2 rounded-xl text-sm font-bold btn-3d shadow-3d-primary flex items-center gap-2 disabled:opacity-70 disabled:shadow-none"
                    >
                        {isLoading && <Loader2 className="animate-spin" size={14} />}
                        Apply Changes
                    </button>
                </div>
            </div>
        </div>
    );
};