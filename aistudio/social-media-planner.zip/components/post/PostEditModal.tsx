import React from 'react';
import { Post, Platform } from '../../types';
import { Save, X, Edit2 } from 'lucide-react';

interface PostEditModalProps {
    post: Post;
    onClose: () => void;
    onSave: (post: Post) => void;
    onChange: (post: Post) => void;
}

export const PostEditModal: React.FC<PostEditModalProps> = ({ post, onClose, onSave, onChange }) => {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-surface rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200 border border-border flex flex-col max-h-[90vh]">
                 <div className="p-6 border-b border-border flex justify-between items-center bg-surface-highlight/10">
                    <h3 className="text-xl font-bold text-text-main flex items-center gap-2">
                        <Edit2 size={20} className="text-primary" />
                        {post.status === 'draft' && post.topic === 'New Post' ? 'Create Post' : 'Edit Post'}
                    </h3>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-surface-highlight text-text-muted hover:text-text-main transition-colors">
                        <X size={20} />
                    </button>
                </div>
                
                <div className="p-6 overflow-y-auto space-y-5 custom-scrollbar">
                    {/* Top Row: Platform & Date */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Platform</label>
                            <select 
                                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                value={post.platform}
                                onChange={e => onChange({...post, platform: e.target.value as Platform})}
                            >
                                <option value="Twitter">Twitter</option>
                                <option value="LinkedIn">LinkedIn</option>
                                <option value="Instagram">Instagram</option>
                                <option value="Facebook">Facebook</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Scheduled Date</label>
                            <input 
                                type="date"
                                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                                value={post.dateStr}
                                onChange={e => onChange({...post, dateStr: e.target.value})}
                            />
                        </div>
                    </div>

                    {/* Topic */}
                    <div>
                        <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Topic / Title</label>
                        <input 
                            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                            value={post.topic}
                            onChange={e => onChange({...post, topic: e.target.value})}
                            placeholder="Brief topic..."
                        />
                    </div>

                    {/* Content */}
                    <div>
                        <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Post Content</label>
                        <textarea 
                            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none min-h-[120px] resize-none"
                            value={post.content || ''}
                            onChange={e => onChange({...post, content: e.target.value})}
                            placeholder="Write your caption here..."
                        />
                    </div>

                    {/* Hashtags */}
                    <div>
                        <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">Hashtags (comma separated)</label>
                         <input 
                            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-text-main focus:ring-2 focus:ring-primary outline-none"
                            value={(post.hashtags || []).join(', ')}
                            onChange={e => onChange({...post, hashtags: e.target.value.split(',').map(s => s.trim()).filter(Boolean)})}
                            placeholder="e.g. eco, green, nature"
                        />
                    </div>

                    {/* Image Prompt */}
                    <div>
                        <label className="text-xs font-bold text-text-muted uppercase mb-1.5 block">AI Image Prompt</label>
                        <textarea 
                            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-xs text-text-main focus:ring-2 focus:ring-primary outline-none min-h-[80px] resize-none"
                            value={post.imagePrompt || ''}
                            onChange={e => onChange({...post, imagePrompt: e.target.value})}
                            placeholder="Describe the image..."
                        />
                    </div>
                </div>

                <div className="p-6 border-t border-border bg-surface-highlight/5 flex justify-end gap-3">
                    <button 
                        onClick={onClose}
                        className="px-6 py-2.5 text-sm font-bold text-text-muted hover:text-text-main transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={() => onSave(post)}
                        className="bg-primary text-white px-8 py-2.5 rounded-xl text-sm font-bold btn-3d shadow-3d-primary flex items-center gap-2"
                    >
                        <Save size={16} /> Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
};