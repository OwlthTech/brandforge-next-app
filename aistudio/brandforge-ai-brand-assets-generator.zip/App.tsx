
import React, { useState, useEffect } from 'react';
import { Brand, GeneratedImage, Product } from './types';
import { BrandWizard } from './components/BrandWizard';
import { ImageGenerator } from './components/ImageGenerator';
import { ProductManager } from './components/ProductManager';
import { BrandDashboard } from './components/BrandDashboard';
import { ProductDetail } from './components/ProductDetail';
import { Auth } from './components/Auth';
import { Button } from './components/ui/Button';
import { Breadcrumbs, BreadcrumbItem } from './components/ui/Breadcrumbs';
import { supabase } from './services/supabaseClient';
import { Plus, LayoutGrid, Image as ImageIcon, ChevronRight, Package, Home, Layers, LogOut, Loader2 } from 'lucide-react';
import { Session } from '@supabase/supabase-js';

const App: React.FC = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const [brands, setBrands] = useState<Brand[]>([]);
  const [activeBrandId, setActiveBrandId] = useState<string | null>(null);
  const [activeProductId, setActiveProductId] = useState<string | null>(null); // New state for deep navigation
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  
  // Navigation State
  // Expanded views
  const [view, setView] = useState<'dashboard' | 'product-detail' | 'generator' | 'product-new' | 'brand-new'>('dashboard');

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
      if (session) {
          fetchBrands();
          fetchImages();
      }
  }, [session]);

  const fetchBrands = async () => {
      if (!session) return;
      const { data, error } = await supabase
          .from('brands')
          .select('*, products(*)');
      
      if (error) {
          console.error("Error fetching brands:", error);
      } else if (data) {
          const formattedBrands: Brand[] = data.map((b: any) => ({
              id: b.id,
              name: b.name,
              category: b.category,
              description: b.description,
              guidelines: b.guidelines,
              referenceImages: b.reference_images || [],
              products: (b.products || []).map((p: any) => ({
                  id: p.id,
                  name: p.name,
                  description: p.description,
                  guidelines: p.guidelines,
                  referenceImages: p.reference_images || [],
                  productImages: p.product_images || [],
                  meta: p.meta || {},
                  createdAt: new Date(p.created_at).getTime()
              })),
              meta: b.meta || {},
              createdAt: new Date(b.created_at).getTime()
          }));
          setBrands(formattedBrands);
      }
  };

  const fetchImages = async () => {
      if (!session) return;
      const { data, error } = await supabase.from('generated_images').select('*');
      if (error) {
          console.error("Error fetching images:", error);
      } else if (data) {
           const formattedImages: GeneratedImage[] = data.map((img: any) => ({
               id: img.id,
               url: img.url,
               prompt: img.prompt,
               type: img.type,
               model: img.model,
               productId: img.product_id,
               label: img.label,
               meta: img.meta || {},
               createdAt: new Date(img.created_at).getTime()
           }));
           setGeneratedImages(formattedImages);
      }
  };

  const handleLogout = async () => {
      await supabase.auth.signOut();
      setSession(null);
      setBrands([]);
      setGeneratedImages([]);
  };

  const handleDevLogin = () => {
      const mockSession: any = {
          access_token: 'mock-token',
          token_type: 'bearer',
          expires_in: 3600,
          refresh_token: 'mock-refresh',
          user: {
              id: 'dev-guest-user',
              aud: 'authenticated',
              role: 'authenticated',
              email: 'guest@brandforge.dev',
              email_confirmed_at: new Date().toISOString(),
              app_metadata: { provider: 'email' },
              user_metadata: {},
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
          }
      };
      setSession(mockSession);
  };

  const activeBrand = brands.find(b => b.id === activeBrandId);
  const activeProduct = activeBrand?.products.find(p => p.id === activeProductId);

  const handleBrandComplete = (brand: Brand) => {
    setBrands([...brands, brand]);
    setActiveBrandId(brand.id);
    setView('dashboard');
  };

  const handleProductCreated = (product: Product) => {
      if (!activeBrand) return;
      const updatedBrand = { ...activeBrand, products: [...activeBrand.products, product] };
      setBrands(brands.map(b => b.id === activeBrand.id ? updatedBrand : b));
      setView('dashboard');
  };

  const handleBrandUpdate = (updatedBrand: Brand) => {
      setBrands(brands.map(b => b.id === updatedBrand.id ? updatedBrand : b));
  };
  
  const handleProductUpdate = (updatedProduct: Product) => {
      if (!activeBrand) return;
      const updatedProducts = activeBrand.products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
      const updatedBrand = { ...activeBrand, products: updatedProducts };
      setBrands(brands.map(b => b.id === activeBrand.id ? updatedBrand : b));
  };

  const handleImageGenerated = (img: GeneratedImage) => {
    setGeneratedImages([img, ...generatedImages]);
  };

  const navigateToBrand = (brandId: string) => {
      setActiveBrandId(brandId);
      setActiveProductId(null);
      setView('dashboard');
  };

  const navigateToProduct = (productId: string) => {
      setActiveProductId(productId);
      setView('product-detail');
  };

  // Build Breadcrumbs
  const getBreadcrumbs = (): BreadcrumbItem[] => {
      const items: BreadcrumbItem[] = [];
      if (activeBrand) {
          items.push({ 
              label: activeBrand.name, 
              onClick: () => { setView('dashboard'); setActiveProductId(null); },
              active: view === 'dashboard'
          });
      }
      if (activeProduct) {
          items.push({
              label: activeProduct.name,
              onClick: () => navigateToProduct(activeProduct.id),
              active: view === 'product-detail'
          });
      }
      if (view === 'generator') {
          items.push({ label: 'Asset Generator', active: true });
      }
      if (view === 'product-new') {
          items.push({ label: 'New Product', active: true });
      }
      return items;
  };

  if (loading) {
      return <div className="min-h-screen bg-black flex items-center justify-center text-teal-500"><Loader2 className="animate-spin" size={32}/></div>;
  }

  if (!session) {
      return <Auth onDevLogin={handleDevLogin} />;
  }

  return (
    <div className="flex h-screen bg-black text-zinc-100 font-sans selection:bg-teal-500/30">
      {/* Sidebar */}
      <aside className="w-64 bg-zinc-950 border-r border-zinc-800 flex flex-col shrink-0">
        <div className="p-6 border-b border-zinc-800">
            <h1 className="text-2xl font-bold tracking-tighter text-white">
                Brand<span className="text-teal-400">Forge</span>
            </h1>
            <p className="text-xs text-zinc-500 mt-1">AI-Powered Identity Suite</p>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            <div className="mb-6">
                <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-3 px-2">Your Brands</h2>
                {brands.length === 0 && (
                    <div className="px-2 py-4 text-sm text-zinc-600 italic">No brands yet.</div>
                )}
                <div className="space-y-1">
                    {brands.map(brand => (
                        <button
                            key={brand.id}
                            onClick={() => navigateToBrand(brand.id)}
                            className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors border-l-2 ${
                                activeBrandId === brand.id 
                                ? 'border-teal-400 bg-zinc-900 text-teal-400' 
                                : 'border-transparent text-zinc-400 hover:text-white hover:bg-zinc-900'
                            }`}
                        >
                            <div className={`w-2 h-2 rounded-full ${activeBrandId === brand.id ? 'bg-teal-400' : 'bg-zinc-600'}`} />
                            <span className="truncate">{brand.name}</span>
                        </button>
                    ))}
                </div>
            </div>
            
            <Button 
                variant="outline" 
                className="w-full flex items-center justify-center gap-2"
                onClick={() => { setActiveBrandId(null); setView('brand-new'); }}
            >
                <Plus size={16} /> New Brand
            </Button>
        </nav>

        {activeBrand && (
            <div className="p-4 border-t border-zinc-800 space-y-1">
                <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-2 px-2">Current Workspace</h3>
                <button onClick={() => { setActiveProductId(null); setView('dashboard'); }} className={`w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-900 ${view === 'dashboard' ? 'text-white' : 'text-zinc-400'}`}>
                    <Home size={16} /> Dashboard
                </button>
                <button onClick={() => setView('generator')} className={`w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-900 ${view === 'generator' ? 'text-white' : 'text-zinc-400'}`}>
                    <Layers size={16} /> Asset Generator
                </button>
                <button onClick={() => setView('product-new')} className={`w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-900 ${view === 'product-new' ? 'text-white' : 'text-zinc-400'}`}>
                    <Package size={16} /> Add Product
                </button>
            </div>
        )}

        <div className="p-4 border-t border-zinc-800">
            <button onClick={handleLogout} className="w-full flex items-center gap-2 px-2 py-2 text-xs text-zinc-500 hover:text-white transition-colors">
                <LogOut size={14} /> Sign Out
            </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="h-14 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur flex items-center justify-between px-8 z-10 shrink-0">
            {activeBrand ? (
                <Breadcrumbs items={getBreadcrumbs()} />
            ) : (
                <span className="text-sm text-zinc-400">Welcome</span>
            )}

            <div className="flex items-center gap-4">
                 <span className="text-xs text-zinc-600 hidden md:block">{session.user.email}</span>
                 <div className="w-8 h-8 bg-teal-900 border border-teal-700 flex items-center justify-center text-teal-200 text-xs font-bold">
                    BF
                 </div>
            </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 bg-black">
            {(brands.length === 0 && view !== 'brand-new') ? (
                <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4">
                    <LayoutGrid size={64} className="opacity-20" />
                    <p className="text-lg font-light">No brands found. Create one to get started.</p>
                    <Button onClick={() => setView('brand-new')}>Create New Brand</Button>
                </div>
            ) : (
                <>
                    {view === 'brand-new' && (
                        <BrandWizard 
                            userId={session.user.id} 
                            onComplete={handleBrandComplete} 
                            onCancel={() => { if(activeBrandId) setView('dashboard'); }} 
                        />
                    )}

                    {view === 'dashboard' && activeBrand && (
                        <BrandDashboard 
                            brand={activeBrand} 
                            images={generatedImages}
                            onNavigateToGenerator={() => setView('generator')}
                            onAddProduct={() => setView('product-new')}
                            onSelectProduct={navigateToProduct}
                        />
                    )}

                    {view === 'product-detail' && activeProduct && activeBrand && (
                        <ProductDetail 
                            userId={session.user.id}
                            product={activeProduct}
                            brand={activeBrand}
                            images={generatedImages}
                            onGenerateClick={() => setView('generator')}
                            onProductUpdate={handleProductUpdate}
                        />
                    )}

                    {view === 'generator' && activeBrand && (
                        <div className="h-full flex flex-col">
                            <div className="mb-6">
                                <h2 className="text-2xl font-light text-white">Asset Generator</h2>
                                <p className="text-zinc-500 text-sm">Create marketing materials using Gemini AI.</p>
                            </div>
                            <div className="flex-1 min-h-0">
                                <ImageGenerator 
                                    userId={session.user.id}
                                    brand={activeBrand}
                                    initialProductId={activeProductId || undefined}
                                    onImageGenerated={handleImageGenerated} 
                                    onBrandUpdate={handleBrandUpdate}
                                />
                            </div>
                        </div>
                    )}

                    {view === 'product-new' && activeBrand && (
                        <ProductManager 
                            userId={session.user.id}
                            brand={activeBrand} 
                            onProductCreated={handleProductCreated} 
                            onCancel={() => setView('dashboard')} 
                        />
                    )}

                    {!activeBrand && view !== 'brand-new' && (
                         <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4">
                            <LayoutGrid size={64} className="opacity-20" />
                            <p className="text-lg font-light">Select a brand to continue.</p>
                        </div>
                    )}
                </>
            )}
        </div>
      </main>
    </div>
  );
};

export default App;
