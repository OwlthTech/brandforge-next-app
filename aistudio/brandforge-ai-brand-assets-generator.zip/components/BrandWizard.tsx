
import React, { useState } from 'react';
import { Button } from './ui/Button';
import { Input, TextArea } from './ui/Input';
import { fileToBase64, generateBrandGuidelines, logTokenUsage } from '../services/geminiService';
import { uploadBase64Image } from '../services/storageService';
import { supabase } from '../services/supabaseClient';
import { Brand } from '../types';
import { Upload, X, Wand2, Loader2, ArrowRight } from 'lucide-react';

interface BrandWizardProps {
  userId: string;
  onComplete: (brand: Brand) => void;
  onCancel: () => void;
}

export const BrandWizard: React.FC<BrandWizardProps> = ({ userId, onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    description: '',
    referenceImages: [] as string[], // These are Base64 for the Preview & AI
  });
  const [generatedGuidelines, setGeneratedGuidelines] = useState('');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newImages = await Promise.all(
        Array.from(e.target.files).map(file => fileToBase64(file))
      );
      setFormData(prev => ({
        ...prev,
        referenceImages: [...prev.referenceImages, ...newImages]
      }));
    }
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      referenceImages: prev.referenceImages.filter((_, i) => i !== index)
    }));
  };

  const handleGenerateGuidelines = async () => {
    setLoading(true);
    setLoadingText('Analyzing brand DNA...');
    try {
      const result = await generateBrandGuidelines(
        formData.name,
        formData.category,
        formData.description,
        formData.referenceImages
      );
      
      setGeneratedGuidelines(result.output);
      logTokenUsage(userId, 'gemini-2.5-flash', result.usage);
      
      setStep(3);
    } catch (error) {
      alert("Failed to generate guidelines. Please check your inputs.");
    } finally {
      setLoading(false);
      setLoadingText('');
    }
  };

  const handleFinalize = async () => {
    setLoading(true);
    setLoadingText('Uploading assets & creating workspace...');
    try {
        const brandId = crypto.randomUUID();
        const now = Date.now();
        
        // 1. Upload reference images to Supabase Storage
        const uploadedImageUrls: string[] = [];
        
        // We use the base64 data we already have to upload
        // In a more advanced version, we might keep the original File objects
        for (const base64 of formData.referenceImages) {
            const url = await uploadBase64Image(base64, userId, 'references');
            if (url) uploadedImageUrls.push(url);
        }

        const newBrandData = {
            id: brandId,
            user_id: userId,
            name: formData.name,
            category: formData.category,
            description: formData.description,
            guidelines: generatedGuidelines,
            reference_images: uploadedImageUrls, // Store URLs in DB
            meta: {
                initialRefImageCount: formData.referenceImages.length,
                generatedBy: 'Gemini 2.5 Flash'
            },
            created_at: new Date().toISOString()
        };

        const { error } = await supabase.from('brands').insert(newBrandData);

        if (error) throw error;

        const newBrand: Brand = {
            id: brandId,
            name: formData.name,
            category: formData.category,
            description: formData.description,
            guidelines: generatedGuidelines,
            referenceImages: uploadedImageUrls,
            products: [],
            meta: newBrandData.meta,
            createdAt: now,
        };
        onComplete(newBrand);
    } catch (error) {
        console.error("Error saving brand:", error);
        alert("Failed to save brand. Please try again.");
    } finally {
        setLoading(false);
        setLoadingText('');
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-zinc-900 border border-zinc-800 shadow-2xl animate-fade-in">
      {/* Progress Bar */}
      <div className="flex items-center justify-between mb-8 border-b border-zinc-800 pb-4">
        <h2 className="text-2xl font-bold text-teal-400">New Brand Identity</h2>
        <div className="flex gap-2">
            {[1, 2, 3].map(s => (
                <div key={s} className={`h-2 w-12 rounded-none transition-all ${step >= s ? 'bg-teal-500' : 'bg-zinc-800'}`} />
            ))}
        </div>
      </div>

      {step === 1 && (
        <div className="space-y-6">
          <h3 className="text-xl text-white font-light">Step 1: Brand Essentials</h3>
          <Input 
            label="Brand Name" 
            placeholder="e.g. EcoWare" 
            value={formData.name}
            onChange={e => setFormData({...formData, name: e.target.value})}
          />
          <Input 
            label="Category / Industry" 
            placeholder="e.g. Sustainable Kitchenware" 
            value={formData.category}
            onChange={e => setFormData({...formData, category: e.target.value})}
          />
          <TextArea 
            label="Business Description" 
            placeholder="Describe your products, mission, and unique selling proposition..." 
            value={formData.description}
            onChange={e => setFormData({...formData, description: e.target.value})}
          />
          <div className="flex justify-between pt-4">
            <Button variant="secondary" onClick={onCancel}>Cancel</Button>
            <Button 
                onClick={() => setStep(2)} 
                disabled={!formData.name || !formData.category}
                className="flex items-center gap-2"
            >
                Next <ArrowRight size={16}/>
            </Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <h3 className="text-xl text-white font-light">Step 2: Visual Inspiration</h3>
          <p className="text-zinc-400 text-sm">Upload logos, moodboards, or product shots to help the AI understand your style.</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {formData.referenceImages.map((img, idx) => (
              <div key={idx} className="relative group aspect-square bg-zinc-800 border border-zinc-700">
                <img src={img} alt="ref" className="w-full h-full object-cover" />
                <button 
                  onClick={() => removeImage(idx)}
                  className="absolute top-1 right-1 bg-black/50 hover:bg-red-500 text-white p-1"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
            <label className="aspect-square border-2 border-dashed border-zinc-700 hover:border-teal-500 hover:bg-zinc-800/50 flex flex-col items-center justify-center cursor-pointer transition-colors text-zinc-500 hover:text-teal-400">
              <Upload size={24} className="mb-2" />
              <span className="text-xs">Upload Image</span>
              <input type="file" className="hidden" accept="image/*" multiple onChange={handleFileChange} />
            </label>
          </div>

          <div className="flex justify-between pt-8 border-t border-zinc-800">
            <Button variant="secondary" onClick={() => setStep(1)}>Back</Button>
            <Button 
                onClick={handleGenerateGuidelines} 
                disabled={loading}
                className="flex items-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Wand2 size={16} />}
              Generate Guidelines
            </Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <h3 className="text-xl text-white font-light">Step 3: Review Guidelines</h3>
          <div className="bg-zinc-950 border border-zinc-800 p-6 h-96 overflow-y-auto font-mono text-sm text-zinc-300 whitespace-pre-wrap">
            {generatedGuidelines}
          </div>
          
          <div className="flex justify-between pt-4">
             <Button variant="secondary" onClick={() => setStep(2)}>Revise Inputs</Button>
             <div className="flex gap-2">
                <Button onClick={handleFinalize} className="bg-mint-400 text-black hover:bg-mint-300">
                    {loading ? (
                        <>
                            <Loader2 className="animate-spin mr-2" size={16} />
                            {loadingText || "Saving..."}
                        </>
                    ) : "Create Brand Workspace"}
                </Button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
