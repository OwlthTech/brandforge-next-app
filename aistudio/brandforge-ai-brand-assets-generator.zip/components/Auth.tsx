
import React, { useState } from 'react';
import { supabase } from '../services/supabaseClient';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Loader2, LogIn, ShieldAlert } from 'lucide-react';

interface AuthProps {
    onDevLogin?: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onDevLogin }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [message, setMessage] = useState('');

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            // Dynamically set redirect to current location (fixes localhost issue in previews)
            emailRedirectTo: window.location.href, 
          }
        });
        if (error) throw error;
        setMessage('Confirmation email sent! Check your inbox (and spam).');
        // Note: You might still need to click "Sign In" after confirming if auto-login is disabled.
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
      }
    } catch (error: any) {
      setMessage(error.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-4">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 p-8 shadow-2xl">
        <div className="flex justify-center mb-6">
          <div className="w-12 h-12 bg-teal-900 border border-teal-700 flex items-center justify-center text-teal-200 text-xl font-bold">
            BF
          </div>
        </div>
        <h2 className="text-2xl font-bold text-center text-white mb-2">Welcome to BrandForge</h2>
        <p className="text-zinc-500 text-center text-sm mb-8">
            {isSignUp ? 'Create an account to get started' : 'Sign in to access your brands'}
        </p>

        <form onSubmit={handleAuth} className="space-y-4">
          <Input 
            label="Email" 
            type="email" 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            required 
            placeholder="name@company.com"
          />
          <Input 
            label="Password" 
            type="password" 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            required 
            placeholder="••••••••"
          />
          
          {message && (
            <div className={`text-sm p-2 border ${message.includes('sent') ? 'text-teal-400 bg-teal-900/20 border-teal-800' : 'text-red-400 bg-red-900/20 border-red-800'}`}>
              {message}
            </div>
          )}

          <Button type="submit" className="w-full flex items-center justify-center gap-2" disabled={loading}>
            {loading ? <Loader2 className="animate-spin" size={18} /> : <LogIn size={18} />}
            {isSignUp ? 'Sign Up' : 'Sign In'}
          </Button>
        </form>

        <div className="mt-6 flex flex-col gap-4 text-center text-sm text-zinc-500">
          <div>
            {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
            <button 
                onClick={() => { setIsSignUp(!isSignUp); setMessage(''); }} 
                className="text-teal-400 hover:underline"
            >
                {isSignUp ? 'Sign In' : 'Sign Up'}
            </button>
          </div>

          {onDevLogin && (
            <div className="pt-4 border-t border-zinc-800">
                <p className="mb-2 text-xs text-zinc-600">Development Mode</p>
                <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full text-zinc-400 hover:text-white"
                    onClick={onDevLogin}
                >
                    <ShieldAlert size={14} className="mr-2" />
                    Continue as Guest
                </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
