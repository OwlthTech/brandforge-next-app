import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export const Input: React.FC<InputProps> = ({ label, className = '', ...props }) => {
  return (
    <div className="flex flex-col gap-1 w-full">
      {label && <label className="text-sm font-medium text-zinc-400">{label}</label>}
      <input
        className={`bg-zinc-900 border border-zinc-700 text-white p-2 rounded-none focus:border-teal-500 focus:outline-none transition-colors placeholder-zinc-600 ${className}`}
        {...props}
      />
    </div>
  );
};

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export const TextArea: React.FC<TextAreaProps> = ({ label, className = '', ...props }) => {
  return (
    <div className="flex flex-col gap-1 w-full">
      {label && <label className="text-sm font-medium text-zinc-400">{label}</label>}
      <textarea
        className={`bg-zinc-900 border border-zinc-700 text-white p-2 rounded-none focus:border-teal-500 focus:outline-none transition-colors placeholder-zinc-600 min-h-[100px] ${className}`}
        {...props}
      />
    </div>
  );
};