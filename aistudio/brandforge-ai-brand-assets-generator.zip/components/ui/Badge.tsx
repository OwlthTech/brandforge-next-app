
import React from 'react';

interface BadgeProps {
    children: React.ReactNode;
    color?: 'teal' | 'zinc' | 'purple' | 'red';
    className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, color = 'zinc', className = '' }) => {
    const colors = {
        teal: 'bg-teal-500/10 text-teal-400 border-teal-500/20',
        zinc: 'bg-zinc-800 text-zinc-400 border-zinc-700',
        purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
        red: 'bg-red-500/10 text-red-400 border-red-500/20',
    };

    return (
        <span className={`px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider border rounded-none ${colors[color]} ${className}`}>
            {children}
        </span>
    );
};
