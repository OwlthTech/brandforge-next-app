
import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

export interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
  active?: boolean;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items }) => {
  return (
    <nav className="flex items-center space-x-2 text-sm text-zinc-400">
      <button 
        onClick={items[0]?.onClick} 
        className="hover:text-white transition-colors flex items-center"
      >
        <Home size={14} className="mr-1"/>
      </button>
      
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <ChevronRight size={14} className="text-zinc-600" />
          <button
            onClick={item.onClick}
            disabled={item.active}
            className={`transition-colors font-medium truncate max-w-[150px] ${
              item.active 
                ? 'text-white cursor-default' 
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            {item.label}
          </button>
        </React.Fragment>
      ))}
    </nav>
  );
};
