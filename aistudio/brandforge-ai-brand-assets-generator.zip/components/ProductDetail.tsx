
import React, { useState, useEffect } from 'react';
import { Product, GeneratedImage, Brand, AssetType } from '../types';
import { Button } from './ui/Button';
import { TextArea, Input } from './ui/Input';
import { Download, Wand2, FileText, LayoutGrid, Clock, Pencil, Save, X, Trash2, Plus, Upload, Tag, Package, Filter, SortDesc, Loader2 } from 'lucide-react';
import { Modal } from './ui/Modal';
import { Badge } from './ui/Badge';
import { supabase } from '../services/supabaseClient';
import { uploadFile } from '../services/storageService';
import { AssetDetail } from './AssetDetail';

interface ProductDetailProps {
    userId: string;
    product: Product;
    brand: Brand;
    images: GeneratedImage[];
    onGenerateClick: () => void;
    onProductUpdate: (updatedProduct: Product) => void;
}

const VIEW_TYPES = ['Front', 'Back', 'Side', 'Top', 'Detail', 'Packshot', 'Lifestyle'];

export const ProductDetail: React.FC<ProductDetailProps> = ({ userId, product, brand, images, onGenerateClick, onProductUpdate }) => {
    const [showGuidelines, setShowGuidelines] = useState(false);
    const [isEditingGuidelines, setIsEditingGuidelines] = useState(false);
    const [guidelinesText, setGuidelinesText] = useState(product.guidelines);
    
    const [isUploading, setIsUploading] = useState(false);
    
    const [selectedAsset, setSelectedAsset] = useState<GeneratedImage | null>(null);
    const [filterType, setFilterType] = useState<AssetType | 'All'>('All');
    const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

    useEffect(() => {
        setGuidelinesText(product.guidelines);
    }, [product]);

    // Filter images for this product
    const productAssets = images
        .filter(img => img.productId === product.id)
        .filter(img => filterType === 'All' || img.type === filterType)
        .sort((a, b) => sortOrder === 'newest' ? b.createdAt - a.createdAt : a.createdAt - b.createdAt);

    const handleSaveGuidelines = async () => {
        const { error } = await supabase
            .from('products')
            .update({ guidelines: guidelinesText })
            .eq('id', product.id);
        
        if (!error) {
            onProductUpdate({ ...product, guidelines: guidelinesText });
            setIsEditingGuidelines(false);
        } else {
            alert("Failed to update guidelines");
        }
    };

    const handleUploadImage = async (e: React.ChangeEvent<HTMLInputElement>, type: 'prod' | 'ref') => {
        if (!e.target.files || e.target.files.length === 0) return;
        setIsUploading(true);

        try {
            const file = e.target.files[0];
            const folder = type === 'prod' ? 'products' : 'references';
            
            // Use uploadFile directly for better performance
            const url = await uploadFile(file, userId || 'unknown', folder);
            
            if (url) {
                const column = type === 'prod' ? 'product_images' : 'reference_images';
                const currentList = type === 'prod' ? product.productImages : product.referenceImages;
                const newList = [...(currentList || []), url];

                const { error } = await supabase
                    .from('products')
                    .update({ [column]: newList })
                    .eq('id', product.id);
                
                if (!error) {
                    if (type === 'prod') {
                        onProductUpdate({ ...product, productImages: newList });
                    } else {
                        onProductUpdate({ ...product, referenceImages: newList });
                    }
                }
            }
        } catch (e) {
            console.error(e);
            alert("Failed to upload image");
        } finally {
            setIsUploading(false);
        }
    };

    const handleDeleteImage = async (index: number, type: 'prod' | 'ref') => {
        if (!confirm("Are you sure you want to delete this image?")) return;

        const column = type === 'prod' ? 'product_images' : 'reference_images';
        const currentList = type === 'prod' ? product.productImages : product.referenceImages;
        const newList = currentList.filter((_, i) => i !== index);

        const { error } = await supabase
            .from('products')
            .update({ [column]: newList })
            .eq('id', product.id);
        
        if (!error) {
            if (type === 'prod') {
                onProductUpdate({ ...product, productImages: newList });
            } else {
                onProductUpdate({ ...product, referenceImages: newList });
            }
        }
    };

    const handleTagImage = async (url: string, tag: string) => {
        const currentMeta = product.meta || {};
        const currentTags = currentMeta.imageTags || {};
        
        const newTags = { ...currentTags, [url]: tag };
        const newMeta = { ...currentMeta, imageTags: newTags };

        const { error } = await supabase
            .from('products')
            .update({ meta: newMeta })
            .eq('id', product.id);

        if (!error) {
            onProductUpdate({ ...product, meta: newMeta });
        } else {
            console.error("Error updating tags", error);
        }
    };

    return (
        <div className="space-y-12 animate-fade-in pb-12">
            {selectedAsset && (
                <AssetDetail 
                    isOpen={!!selectedAsset} 
                    onClose={() => setSelectedAsset(null)} 
                    asset={selectedAsset}
                    brand={brand}
                    products={[product]}
                />
            )}

             <Modal 
                isOpen={showGuidelines} 
                onClose={() => { setShowGuidelines(false); setIsEditingGuidelines(false); }} 
                title={`${product.name} Guidelines`}
            >
                <div className="flex justify-between items-center mb-4">
                    <p className="text-xs text-zinc-500">Define how the AI should portray this product.</p>
                    <Button 
                        size="sm" 
                        variant={isEditingGuidelines ? 'secondary' : 'outline'}
                        onClick={() => setIsEditingGuidelines(!isEditingGuidelines)}
                    >
                        {isEditingGuidelines ? <span className="flex items-center"><X size={14} className="mr-1"/> Cancel</span> : <span className="flex items-center"><Pencil size={14} className="mr-1"/> Edit</span>}
                    </Button>
                </div>

                {isEditingGuidelines ? (
                    <div className="space-y-4">
                        <TextArea 
                            value={guidelinesText} 
                            onChange={(e) => setGuidelinesText(e.target.value)} 
                            className="h-[400px] font-mono text-sm"
                        />
                        <Button onClick={handleSaveGuidelines} className="w-full flex justify-center gap-2">
                            <Save size={16}/> Save Changes
                        </Button>
                    </div>
                ) : (
                    <div className="prose prose-invert prose-sm whitespace-pre-wrap max-w-none text-zinc-300">
                        {product.guidelines}
                    </div>
                )}
            </Modal>

            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-zinc-800 pb-6">
                <div>
                    <h2 className="text-3xl font-light text-white mb-2">{product.name}</h2>
                    <p className="text-zinc-500 max-w-xl text-sm">{product.description}</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="secondary" onClick={() => setShowGuidelines(true)}>
                        <FileText size={16} className="mr-2"/> Guidelines
                    </Button>
                    <Button onClick={onGenerateClick}>
                        <Wand2 size={16} className="mr-2"/> Generate Assets
                    </Button>
                </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-zinc-900 border border-zinc-800 p-4">
                    <span className="text-xs text-zinc-500 uppercase">Total Assets</span>
                    <p className="text-2xl text-white">{productAssets.length}</p>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 p-4">
                    <span className="text-xs text-zinc-500 uppercase">Last Generated</span>
                    <p className="text-sm text-white mt-1">
                        {productAssets.length > 0 
                         ? new Date(Math.max(...productAssets.map(i => i.createdAt))).toLocaleDateString()
                         : 'N/A'}
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Source Product Images */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                         <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-2">
                            <Package size={16}/> Source Product Images
                         </h3>
                         <label className={`text-xs text-teal-400 cursor-pointer hover:underline flex items-center gap-1 ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}>
                            {isUploading ? <Loader2 size={14} className="animate-spin"/> : <Plus size={14}/>} Add Image
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleUploadImage(e, 'prod')} disabled={isUploading} />
                         </label>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-3">
                        {product.productImages?.map((img, i) => {
                            const tag = product.meta?.imageTags?.[img];
                            return (
                                <div key={i} className="relative group bg-zinc-900 border border-zinc-800 aspect-square">
                                    <img src={img} alt="Product Source" className="w-full h-full object-contain p-2" />
                                    
                                    {/* Tag Badge */}
                                    {tag && (
                                        <div className="absolute top-1 left-1">
                                            <Badge color="teal">{tag}</Badge>
                                        </div>
                                    )}

                                    {/* Hover Actions */}
                                    <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                                        <select 
                                            className="bg-zinc-800 text-[10px] text-white border border-zinc-600 outline-none p-1"
                                            value={tag || ''}
                                            onChange={(e) => handleTagImage(img, e.target.value)}
                                        >
                                            <option value="">+ Tag View</option>
                                            {VIEW_TYPES.map(v => <option key={v} value={v}>{v}</option>)}
                                        </select>
                                        <button 
                                            onClick={() => handleDeleteImage(i, 'prod')}
                                            className="text-red-400 hover:text-red-300 p-1"
                                        >
                                            <Trash2 size={16}/>
                                        </button>
                                    </div>
                                </div>
                            )
                        })}
                        {(!product.productImages || product.productImages.length === 0) && (
                            <div className="col-span-3 py-8 text-center text-zinc-600 border border-dashed border-zinc-800 bg-zinc-900/50">
                                No product images uploaded.
                            </div>
                        )}
                    </div>
                </div>

                {/* Reference Images */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                         <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-2">
                            <LayoutGrid size={16}/> Style References
                         </h3>
                         <label className={`text-xs text-teal-400 cursor-pointer hover:underline flex items-center gap-1 ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}>
                             {isUploading ? <Loader2 size={14} className="animate-spin"/> : <Plus size={14}/>} Add Reference
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleUploadImage(e, 'ref')} disabled={isUploading} />
                         </label>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                         {product.referenceImages?.map((img, i) => (
                             <div key={i} className="relative group bg-zinc-900 border border-zinc-800 aspect-square overflow-hidden">
                                <img src={img} alt="Ref" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                    <button 
                                        onClick={() => handleDeleteImage(i, 'ref')}
                                        className="text-white hover:text-red-400"
                                    >
                                        <Trash2 size={20}/>
                                    </button>
                                </div>
                             </div>
                         ))}
                          {(!product.referenceImages || product.referenceImages.length === 0) && (
                            <div className="col-span-3 py-8 text-center text-zinc-600 border border-dashed border-zinc-800 bg-zinc-900/50">
                                No reference images.
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Generated Assets Gallery */}
            <div className="space-y-6 pt-8 border-t border-zinc-800">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h3 className="text-xl font-light text-white flex items-center gap-2">
                        Generated Assets
                    </h3>
                    <div className="flex gap-4">
                        <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-3 py-1">
                            <Filter size={14} className="text-zinc-500"/>
                            <select 
                                className="bg-transparent text-sm text-zinc-300 outline-none"
                                value={filterType}
                                onChange={(e) => setFilterType(e.target.value as any)}
                            >
                                <option value="All">All Types</option>
                                {Object.values(AssetType).map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                        <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-3 py-1">
                            <SortDesc size={14} className="text-zinc-500"/>
                             <select 
                                className="bg-transparent text-sm text-zinc-300 outline-none"
                                value={sortOrder}
                                onChange={(e) => setSortOrder(e.target.value as any)}
                            >
                                <option value="newest">Newest First</option>
                                <option value="oldest">Oldest First</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {productAssets.length > 0 ? (
                        productAssets.map(img => (
                            <div key={img.id} onClick={() => setSelectedAsset(img)} className="group cursor-pointer relative bg-zinc-900 border border-zinc-800 hover:border-teal-500/50 transition-colors">
                                <div className="aspect-square overflow-hidden bg-black/50">
                                    <img src={img.url} alt={img.prompt} className="w-full h-full object-cover" />
                                </div>
                                <div className="p-3">
                                    <div className="flex justify-between items-start mb-1">
                                        <Badge color="teal">{img.type}</Badge>
                                        {img.label && <span className="text-[9px] bg-zinc-800 px-1 text-zinc-500">{img.label}</span>}
                                    </div>
                                    <p className="text-xs text-zinc-300 line-clamp-2 mt-2" title={img.prompt}>{img.prompt}</p>
                                    <div className="mt-2 pt-2 border-t border-zinc-800/50 flex justify-between items-center text-[10px] text-zinc-500">
                                        <span>{new Date(img.createdAt).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full py-12 text-center text-zinc-600 border border-dashed border-zinc-800 bg-zinc-900/50">
                            <Wand2 size={48} className="mx-auto mb-4 opacity-20" />
                            <p>No assets generated yet.</p>
                            <Button variant="outline" size="sm" className="mt-4" onClick={onGenerateClick}>
                                Create First Asset
                            </Button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
