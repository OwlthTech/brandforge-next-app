
import React, { useState } from 'react';
import { Brand, GeneratedImage, Product, AssetType } from '../types';
import { Button } from './ui/Button';
import { Filter, Download, Plus, Search, ChevronRight } from 'lucide-react';
import { AssetDetail } from './AssetDetail';

interface BrandDashboardProps {
    brand: Brand;
    images: GeneratedImage[];
    onNavigateToGenerator: () => void;
    onAddProduct: () => void;
    onSelectProduct: (productId: string) => void;
}

export const BrandDashboard: React.FC<BrandDashboardProps> = ({ brand, images, onNavigateToGenerator, onAddProduct, onSelectProduct }) => {
    const [filterType, setFilterType] = useState<AssetType | 'All'>('All');
    const [selectedAsset, setSelectedAsset] = useState<GeneratedImage | null>(null);

    // Filter images that belong to this brand
    const brandImages = images.filter(img => {
        // In a real app we'd filter by brandId, assuming passed images are relevant
        return true; 
    });

    const filteredImages = brandImages.filter(img => {
        if (filterType !== 'All' && img.type !== filterType) return false;
        return true;
    });

    return (
        <div className="space-y-12 animate-fade-in pb-12">
            {selectedAsset && (
                <AssetDetail 
                    isOpen={!!selectedAsset} 
                    onClose={() => setSelectedAsset(null)} 
                    asset={selectedAsset}
                    brand={brand}
                    products={brand.products}
                />
            )}

            {/* Stats / Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-zinc-900 p-6 border border-zinc-800">
                    <h4 className="text-zinc-500 text-xs uppercase tracking-wider mb-2">Total Assets</h4>
                    <p className="text-4xl font-light text-white">{brandImages.length}</p>
                </div>
                <div className="bg-zinc-900 p-6 border border-zinc-800">
                    <h4 className="text-zinc-500 text-xs uppercase tracking-wider mb-2">Active Products</h4>
                    <p className="text-4xl font-light text-white">{brand.products.length}</p>
                </div>
                <div className="bg-zinc-900 p-6 border border-zinc-800 flex items-center justify-between cursor-pointer hover:bg-zinc-800 transition-colors" onClick={onNavigateToGenerator}>
                     <div>
                        <h4 className="text-zinc-500 text-xs uppercase tracking-wider mb-1">Quick Action</h4>
                        <p className="text-teal-400 font-medium flex items-center gap-2">Generate New Asset <ChevronRight size={16}/></p>
                     </div>
                     <div className="h-12 w-12 bg-teal-500/10 rounded-full flex items-center justify-center text-teal-400">
                        <Plus size={24} />
                     </div>
                </div>
            </div>

            {/* Products Grid */}
            <div>
                <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-light text-white">Products</h3>
                    <Button size="sm" variant="outline" onClick={onAddProduct}><Plus size={14} className="mr-1"/> Add Product</Button>
                </div>
                
                {brand.products.length === 0 ? (
                    <div className="w-full text-center p-12 border border-dashed border-zinc-800 text-zinc-600 bg-zinc-900/50">
                        <p className="mb-4">No products added yet.</p>
                        <Button size="sm" onClick={onAddProduct}>Create Your First Product</Button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {brand.products.map(p => (
                            <div 
                                key={p.id} 
                                onClick={() => onSelectProduct(p.id)}
                                className="group cursor-pointer bg-zinc-900 border border-zinc-800 hover:border-teal-500/50 transition-all hover:translate-y-[-2px]"
                            >
                                <div className="aspect-video bg-zinc-800 overflow-hidden relative border-b border-zinc-800">
                                    {p.productImages && p.productImages[0] ? (
                                         <img src={p.productImages[0]} alt={p.name} className="w-full h-full object-contain p-4" />
                                    ) : (
                                        p.referenceImages && p.referenceImages[0] ? (
                                            <img src={p.referenceImages[0]} alt={p.name} className="w-full h-full object-cover" />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center text-zinc-700 bg-zinc-950">No Image</div>
                                        )
                                    )}
                                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                                        <span className="opacity-0 group-hover:opacity-100 bg-teal-500 text-black text-xs font-bold px-3 py-1 transform translate-y-2 group-hover:translate-y-0 transition-all">View Details</span>
                                    </div>
                                </div>
                                <div className="p-4">
                                    <h4 className="font-medium text-white truncate text-lg mb-1">{p.name}</h4>
                                    <p className="text-xs text-zinc-500 line-clamp-2 h-8">{p.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Recent Assets */}
            <div>
                <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-light text-white">Recent Assets</h3>
                    <select 
                        className="bg-zinc-900 border border-zinc-700 text-sm p-1 px-3 text-white outline-none focus:border-teal-500"
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value as any)}
                    >
                        <option value="All">All Types</option>
                        {Object.values(AssetType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {filteredImages.length > 0 ? (
                        filteredImages.slice(0, 10).map(img => (
                            <div key={img.id} onClick={() => setSelectedAsset(img)} className="group cursor-pointer relative bg-zinc-900 border border-zinc-800 hover:border-teal-500/50 transition-colors">
                                <div className="aspect-square overflow-hidden bg-black/50">
                                    <img src={img.url} alt={img.prompt} className="w-full h-full object-cover" />
                                </div>
                                <div className="p-3">
                                    <div className="flex justify-between items-start mb-1">
                                        <span className="text-[10px] uppercase tracking-wider text-teal-500 font-bold">{img.type}</span>
                                        {img.label && <span className="text-[10px] bg-zinc-800 px-1 text-zinc-400">{img.label}</span>}
                                    </div>
                                    <p className="text-xs text-zinc-300 line-clamp-2" title={img.prompt}>{img.prompt}</p>
                                    <div className="mt-2 pt-2 border-t border-zinc-800/50 flex justify-between items-center text-[10px] text-zinc-500">
                                        <span>{new Date(img.createdAt).toLocaleDateString()}</span>
                                        <Download size={14} className="hover:text-white"/>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full py-12 text-center text-zinc-600">
                            <Search size={48} className="mx-auto mb-4 opacity-20" />
                            <p>No assets found.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
