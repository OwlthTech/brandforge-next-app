
import React from 'react';
import { GeneratedImage, Brand, Product } from '../types';
import { Modal } from './ui/Modal';
import { Badge } from './ui/Badge';
import { Button } from './ui/Button';
import { Download, Copy, Calendar, Tag, Coins, Image as ImageIcon, Box } from 'lucide-react';

interface AssetDetailProps {
    isOpen: boolean;
    onClose: () => void;
    asset: GeneratedImage;
    brand: Brand;
    products: Product[];
}

export const AssetDetail: React.FC<AssetDetailProps> = ({ isOpen, onClose, asset, brand, products }) => {
    if (!asset) return null;

    const product = products.find(p => p.id === asset.productId);
    const usage = asset.meta?.usage;
    
    // Approximate cost calculation based on Gemini 2.5 Flash pricing
    // Input: $0.075 / 1M tokens, Output: $0.30 / 1M tokens
    // Image output is roughly $0.0001 per image depending on resolution (simplified)
    const cost = usage ? (
        ((usage.promptTokens / 1_000_000) * 0.075) + 
        ((usage.candidatesTokens / 1_000_000) * 0.30)
    ).toFixed(6) : "0.000000";

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Asset Details">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Left: Image */}
                <div className="space-y-4">
                    <div className="bg-zinc-950 border border-zinc-800 p-2 flex items-center justify-center min-h-[300px]">
                        <img src={asset.url} alt="Asset" className="max-w-full max-h-[500px] object-contain" />
                    </div>
                    <Button className="w-full flex items-center justify-center gap-2" onClick={() => {
                         const link = document.createElement('a');
                         link.href = asset.url;
                         link.download = `asset-${asset.id}.png`;
                         link.click();
                    }}>
                        <Download size={16}/> Download High-Res
                    </Button>
                </div>

                {/* Right: Metadata */}
                <div className="space-y-6">
                    <div>
                        <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Generation Context</h4>
                        <div className="flex flex-wrap gap-2">
                            <Badge color="teal">{asset.type}</Badge>
                            {asset.label && <Badge color="zinc">{asset.label}</Badge>}
                            {product && <Badge color="purple">{product.name}</Badge>}
                            <Badge color="zinc">{asset.model}</Badge>
                        </div>
                    </div>

                    <div>
                        <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Prompt</h4>
                        <div className="bg-zinc-950 p-3 border border-zinc-800 text-sm text-zinc-300 font-mono leading-relaxed max-h-32 overflow-y-auto">
                            {asset.prompt}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         {asset.meta?.sourceImage && (
                             <div>
                                 <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                                    <Box size={12}/> Product Source
                                 </h4>
                                 <div className="w-16 h-16 bg-zinc-900 border border-zinc-800">
                                    <img src={asset.meta.sourceImage} className="w-full h-full object-contain" />
                                 </div>
                             </div>
                         )}
                         {asset.meta?.referenceImage && (
                             <div>
                                 <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                                    <ImageIcon size={12}/> Style Ref
                                 </h4>
                                 <div className="w-16 h-16 bg-zinc-900 border border-zinc-800">
                                    {asset.meta.referenceImage.startsWith('data:') ? (
                                        <div className="w-full h-full bg-zinc-800 flex items-center justify-center text-[10px] text-zinc-500">Base64 Data</div>
                                    ) : (
                                        <img src={asset.meta.referenceImage} className="w-full h-full object-cover" />
                                    )}
                                 </div>
                             </div>
                         )}
                    </div>

                    <div className="pt-4 border-t border-zinc-800">
                        <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                            <Coins size={14} className="text-teal-500"/> Usage & Cost
                        </h4>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                            <div className="flex justify-between text-zinc-400">
                                <span>Total Tokens:</span>
                                <span className="text-white font-mono">{usage?.totalTokens || 0}</span>
                            </div>
                            <div className="flex justify-between text-zinc-400">
                                <span>Est. Cost:</span>
                                <span className="text-white font-mono">${cost}</span>
                            </div>
                        </div>
                    </div>

                    <div className="text-[10px] text-zinc-600 flex items-center gap-1">
                        <Calendar size={10}/> Generated on {new Date(asset.createdAt).toLocaleString()}
                    </div>
                </div>
            </div>
        </Modal>
    );
};
