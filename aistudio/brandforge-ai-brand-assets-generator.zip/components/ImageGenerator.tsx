
import React, { useState, useEffect } from 'react';
import { AssetType, AspectRatio, GeneratedImage, Brand, AIModel } from '../types';
import { Button } from './ui/Button';
import { Input, TextArea } from './ui/Input';
import { generateOrEditImage, fileToBase64, generateMarketplacePrompts, logTokenUsage, refinePrompt } from '../services/geminiService';
import { uploadBase64Image, uploadFile } from '../services/storageService';
import { supabase } from '../services/supabaseClient';
import { Loader2, Download, Wand2, RefreshCw, Upload, Sparkles, AlertCircle, Maximize2, X, Package, LayoutGrid, Pencil, Save } from 'lucide-react';
import { Modal } from './ui/Modal';
import { Badge } from './ui/Badge';

interface ImageGeneratorProps {
  userId: string;
  brand: Brand;
  initialProductId?: string;
  onImageGenerated: (img: GeneratedImage) => void;
  onBrandUpdate: (updatedBrand: Brand) => void; // Sync back to parent
}

const MARKETPLACE_SLOTS = [
    { label: "Main Hero", desc: "Clean white background, high contrast" },
    { label: "Lifestyle", desc: "Product in use, realistic environment" },
    { label: "Ingredients/Details", desc: "Close up, texture focus" },
    { label: "Benefits Infographic", desc: "Space for text, clean layout" },
    { label: "Packaging", desc: "Front facing, clear label" },
    { label: "Comparison", desc: "Side by side style" }
];

const SOCIAL_PLATFORMS = {
    'Instagram': { 'Post': AspectRatio.SQUARE, 'Story': AspectRatio.PORTRAIT },
    'Facebook': { 'Post': AspectRatio.STANDARD_LANDSCAPE, 'Cover': AspectRatio.LANDSCAPE },
    'LinkedIn': { 'Post': AspectRatio.STANDARD_LANDSCAPE },
    'Twitter/X': { 'Post': AspectRatio.LANDSCAPE }
};

export const ImageGenerator: React.FC<ImageGeneratorProps> = ({ userId, brand, initialProductId, onImageGenerated, onBrandUpdate }) => {
  const [activeTab, setActiveTab] = useState<AssetType>(AssetType.MARKETPLACE);
  const [selectedProduct, setSelectedProduct] = useState<string>(initialProductId || 'brand');
  const [selectedModel, setSelectedModel] = useState<AIModel>(AIModel.GEMINI_2_5_FLASH_IMAGE);
  
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(AspectRatio.SQUARE);
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [refiningPrompt, setRefiningPrompt] = useState(false);
  
  const [generatedImageBase64, setGeneratedImageBase64] = useState<string | null>(null);
  
  // Dual Image Inputs
  const [subjectImage, setSubjectImage] = useState<string | null>(null);
  const [styleImage, setStyleImage] = useState<string | null>(null);

  const [marketplaceSlot, setMarketplaceSlot] = useState(MARKETPLACE_SLOTS[0].label);
  const [socialPlatform, setSocialPlatform] = useState('Instagram');
  const [socialFormat, setSocialFormat] = useState('Post');
  const [showGuidelines, setShowGuidelines] = useState(false);
  const [showPromptModal, setShowPromptModal] = useState(false);

  // Auto-Prompt Logic
  useEffect(() => {
    if (activeTab === AssetType.MARKETPLACE) {
        setAspectRatio(AspectRatio.SQUARE);
        // Auto-fill prompt when slot changes
        const product = brand.products.find(p => p.id === selectedProduct);
        const name = product ? product.name : brand.name;
        const autoPrompt = `Professional ${marketplaceSlot} photography of ${name}, centered, high quality, commercial lighting.`;
        setPrompt(autoPrompt);
    } else if (activeTab === AssetType.SOCIAL_MEDIA) {
        updateSocialAspectRatio(socialPlatform, socialFormat);
    }
  }, [activeTab, marketplaceSlot, selectedProduct]);

  useEffect(() => {
      if (initialProductId) setSelectedProduct(initialProductId);
  }, [initialProductId]);

  const updateSocialAspectRatio = (platform: string, format: string) => {
    // @ts-ignore
    const ratio = SOCIAL_PLATFORMS[platform]?.[format] || AspectRatio.SQUARE;
    setAspectRatio(ratio);
  };

  const handleImageSelect = async (url: string, type: 'subject' | 'style') => {
      try {
          // If it's a supabase URL, we can use it directly or fetch blob to preview
          const response = await fetch(url);
          const blob = await response.blob();
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = reader.result as string;
              if (type === 'subject') setSubjectImage(base64);
              else setStyleImage(base64);
          };
          reader.readAsDataURL(blob);
      } catch (e) { console.error(e); }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'subject' | 'style') => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const base64 = await fileToBase64(file);
      
      if (type === 'subject') {
          setSubjectImage(base64);
          // Optional: Upload subject to product instantly if needed, but usually we wait for save.
      } else {
          setStyleImage(base64);
          
          // Persistence for Style Reference
          // Automatically upload and save to the current product/brand reference list
          setLoadingText('Uploading Reference...');
          try {
              // Use uploadFile for robustness
              const url = await uploadFile(file, userId, 'references');
              if (url) {
                  const product = brand.products.find(p => p.id === selectedProduct);
                  if (product) {
                      // Update Product
                      const newRefs = [...(product.referenceImages || []), url];
                      const { error } = await supabase.from('products').update({ reference_images: newRefs }).eq('id', product.id);
                      if (!error) {
                          const updatedProduct = { ...product, referenceImages: newRefs };
                          const updatedBrand = { 
                              ...brand, 
                              products: brand.products.map(p => p.id === product.id ? updatedProduct : p) 
                          };
                          onBrandUpdate(updatedBrand);
                      }
                  } else {
                      // Update Brand
                      const newRefs = [...(brand.referenceImages || []), url];
                      const { error } = await supabase.from('brands').update({ reference_images: newRefs }).eq('id', brand.id);
                      if (!error) {
                          const updatedBrand = { ...brand, referenceImages: newRefs };
                          onBrandUpdate(updatedBrand);
                      }
                  }
              }
          } catch (err) {
              console.error("Failed to persist reference", err);
          } finally {
              setLoadingText('');
          }
      }
    }
  };

  const handleRefinePrompt = async () => {
      if (!prompt) return;
      setRefiningPrompt(true);
      try {
          const result = await refinePrompt(prompt);
          setPrompt(result.output);
          logTokenUsage(userId, 'gemini-2.5-flash', result.usage);
      } catch (e) {
          console.error(e);
      } finally {
          setRefiningPrompt(false);
      }
  };

  const handleGenerate = async () => {
    setLoading(true);
    setLoadingText('Generating Image...');
    try {
      // 1. Generate Image (Returns Base64)
      const result = await generateOrEditImage(
        prompt, 
        aspectRatio, 
        selectedModel,
        subjectImage || undefined,
        styleImage || undefined
      );
      
      setGeneratedImageBase64(result.output);
      logTokenUsage(userId, selectedModel, result.usage);
      
      // 2. Upload to Supabase Storage
      setLoadingText('Saving Asset...');
      const storageUrl = await uploadBase64Image(result.output, userId, 'generated');
      if (!storageUrl) throw new Error("Failed to upload image to storage");

      const product = brand.products.find(p => p.id === selectedProduct);
      const label = activeTab === AssetType.MARKETPLACE ? marketplaceSlot : (activeTab === AssetType.SOCIAL_MEDIA ? `${socialPlatform} ${socialFormat}` : undefined);
      const assetId = crypto.randomUUID();

      const newAsset: GeneratedImage = {
        id: assetId,
        url: storageUrl, 
        prompt: prompt,
        type: activeTab,
        model: selectedModel,
        productId: product ? product.id : undefined,
        label: label,
        meta: {
            aspectRatio,
            sourceImage: subjectImage ? "User Upload" : undefined, 
            referenceImage: styleImage ? "User Upload" : undefined,
            usage: result.usage
        },
        createdAt: Date.now()
      };

      const { error } = await supabase.from('generated_images').insert({
          id: assetId,
          user_id: userId,
          brand_id: brand.id,
          product_id: product ? product.id : null,
          url: storageUrl,
          prompt,
          type: activeTab,
          model: selectedModel,
          label,
          meta: newAsset.meta,
          created_at: new Date().toISOString()
      });

      if (error) console.error(error);
      onImageGenerated(newAsset);

    } catch (error: any) {
      console.error(error);
      if (error.message?.includes('403') || error.message?.includes('permission')) {
          alert("Permission denied. For high-quality models, you may need to select a billing project via the pop-up (if enabled) or check your API key.");
      } else {
          alert("Generation failed. Please try again.");
      }
    } finally {
      setLoading(false);
      setLoadingText('');
    }
  };

  const currentProduct = brand.products.find(p => p.id === selectedProduct);
  const currentGuidelines = currentProduct ? currentProduct.guidelines : brand.guidelines;

  return (
    <div className="flex flex-col xl:flex-row gap-6 h-full animate-fade-in">
        <Modal 
            isOpen={showGuidelines} 
            onClose={() => setShowGuidelines(false)} 
            title={currentProduct ? `${currentProduct.name} Guidelines` : "Brand Guidelines"}
        >
            <div className="prose prose-invert prose-sm whitespace-pre-wrap max-w-none text-zinc-300">
                {currentGuidelines}
            </div>
        </Modal>

        <Modal isOpen={showPromptModal} onClose={() => setShowPromptModal(false)} title="Edit Prompt">
            <div className="space-y-4">
                <TextArea 
                    value={prompt} 
                    onChange={e => setPrompt(e.target.value)} 
                    className="h-64 font-mono text-sm"
                />
                <div className="flex justify-between">
                     <Button variant="secondary" onClick={handleRefinePrompt} disabled={refiningPrompt}>
                        {refiningPrompt ? <Loader2 className="animate-spin mr-2" size={16}/> : <Wand2 size={16} className="mr-2"/>}
                        Refine with AI
                     </Button>
                     <Button onClick={() => setShowPromptModal(false)}>Done</Button>
                </div>
            </div>
        </Modal>

      {/* Controls Panel */}
      <div className="w-full xl:w-1/3 flex flex-col gap-4 overflow-y-auto pr-2 pb-12">
        
        {/* Top Asset Tabs */}
        <div className="flex bg-zinc-900 border border-zinc-800 p-1">
            {Object.values(AssetType).map((type) => (
                <button
                key={type}
                onClick={() => setActiveTab(type)}
                className={`flex-1 py-2 text-xs font-medium transition-all ${
                    activeTab === type 
                    ? 'bg-teal-500 text-black shadow-sm' 
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
                >
                {type}
                </button>
            ))}
        </div>

        {/* Configuration Block */}
        <div className="bg-zinc-900 border border-zinc-800 p-4 space-y-5">
             <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="text-xs text-zinc-500 mb-1 block">AI Model</label>
                    <select 
                        className="w-full bg-zinc-950 border border-zinc-700 p-2 text-xs text-white outline-none focus:border-teal-500"
                        value={selectedModel}
                        onChange={(e) => setSelectedModel(e.target.value as AIModel)}
                    >
                        <option value={AIModel.GEMINI_2_5_FLASH_IMAGE}>Gemini 2.5 Flash</option>
                        <option value={AIModel.GEMINI_3_PRO_IMAGE_PREVIEW}>Gemini 3 Pro (HQ)</option>
                    </select>
                 </div>
                 <div>
                    <label className="text-xs text-zinc-500 mb-1 block">Product Context</label>
                    <select 
                        className="w-full bg-zinc-950 border border-zinc-700 p-2 text-xs text-white outline-none focus:border-teal-500"
                        value={selectedProduct}
                        onChange={(e) => setSelectedProduct(e.target.value)}
                    >
                        <option value="brand">Brand General</option>
                        {brand.products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                 </div>
             </div>

             {activeTab === AssetType.MARKETPLACE && (
                 <div className="space-y-2">
                     <label className="text-xs text-teal-400 font-bold uppercase tracking-wider">Marketplace Image Slot</label>
                     <div className="grid grid-cols-2 gap-2">
                        {MARKETPLACE_SLOTS.map(slot => (
                            <button
                                key={slot.label}
                                onClick={() => setMarketplaceSlot(slot.label)}
                                className={`p-2 text-left border text-xs transition-all ${
                                    marketplaceSlot === slot.label
                                    ? 'border-teal-500 bg-teal-500/10 text-teal-300'
                                    : 'border-zinc-700 text-zinc-400 hover:border-zinc-600'
                                }`}
                            >
                                <div className="font-medium">{slot.label}</div>
                                <div className="text-[10px] opacity-70 truncate">{slot.desc}</div>
                            </button>
                        ))}
                     </div>
                 </div>
             )}

             {activeTab === AssetType.SOCIAL_MEDIA && (
                 <div className="grid grid-cols-2 gap-4">
                     <div>
                        <label className="text-xs text-teal-400 font-bold uppercase tracking-wider mb-1 block">Platform</label>
                        <select 
                            className="w-full bg-zinc-950 border border-zinc-700 p-2 text-white outline-none"
                            value={socialPlatform}
                            onChange={(e) => {
                                setSocialPlatform(e.target.value);
                                setSocialFormat(Object.keys(SOCIAL_PLATFORMS[e.target.value as keyof typeof SOCIAL_PLATFORMS])[0]);
                                updateSocialAspectRatio(e.target.value, Object.keys(SOCIAL_PLATFORMS[e.target.value as keyof typeof SOCIAL_PLATFORMS])[0]);
                            }}
                        >
                            {Object.keys(SOCIAL_PLATFORMS).map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                     </div>
                     <div>
                        <label className="text-xs text-teal-400 font-bold uppercase tracking-wider mb-1 block">Format</label>
                        <select 
                            className="w-full bg-zinc-950 border border-zinc-700 p-2 text-white outline-none"
                            value={socialFormat}
                            onChange={(e) => {
                                setSocialFormat(e.target.value);
                                updateSocialAspectRatio(socialPlatform, e.target.value);
                            }}
                        >
                            {/* @ts-ignore */}
                            {Object.keys(SOCIAL_PLATFORMS[socialPlatform] || {}).map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                     </div>
                 </div>
             )}
        </div>

        {/* Inputs Area */}
        <div className="bg-zinc-900 border border-zinc-800 p-4 space-y-6 flex-1">
             
             {/* 1. Subject Image */}
             <div>
                <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-2">
                        <Package size={14}/> Subject Product
                    </label>
                    {subjectImage && <button onClick={() => setSubjectImage(null)} className="text-xs text-red-400 hover:underline">Remove</button>}
                </div>
                
                {subjectImage ? (
                    <div className="h-24 w-full bg-zinc-950 border border-zinc-700 flex items-center justify-center relative group">
                        <img src={subjectImage} className="h-full object-contain" />
                    </div>
                ) : (
                    currentProduct && currentProduct.productImages?.length > 0 ? (
                        <div className="flex gap-2 overflow-x-auto pb-2">
                            {currentProduct.productImages.map((img, i) => (
                                <button key={i} onClick={() => handleImageSelect(img, 'subject')} className="w-16 h-16 border border-zinc-700 hover:border-teal-500 bg-zinc-950 p-1 flex-shrink-0">
                                    <img src={img} className="w-full h-full object-contain" />
                                </button>
                            ))}
                             <label className="w-16 h-16 border border-dashed border-zinc-700 hover:border-teal-500 flex items-center justify-center cursor-pointer flex-shrink-0 text-zinc-500">
                                <Upload size={14}/>
                                <input type="file" className="hidden" onChange={(e) => handleFileUpload(e, 'subject')} accept="image/*" />
                            </label>
                        </div>
                    ) : (
                         <label className="w-full h-20 border border-dashed border-zinc-700 hover:border-teal-500 flex items-center justify-center gap-2 cursor-pointer text-zinc-500 text-sm">
                            <Upload size={16}/> Upload Product Image
                            <input type="file" className="hidden" onChange={(e) => handleFileUpload(e, 'subject')} accept="image/*" />
                        </label>
                    )
                )}
             </div>

             {/* 2. Style Image */}
             <div>
                <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-2">
                        <LayoutGrid size={14}/> Style / Reference
                    </label>
                     {styleImage && <button onClick={() => setStyleImage(null)} className="text-xs text-red-400 hover:underline">Remove</button>}
                </div>

                {styleImage ? (
                    <div className="h-24 w-full bg-zinc-950 border border-zinc-700 flex items-center justify-center relative">
                        <img src={styleImage} className="h-full object-contain" />
                    </div>
                ) : (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                        {currentProduct && currentProduct.referenceImages?.map((img, i) => (
                            <button key={`prod-${i}`} onClick={() => handleImageSelect(img, 'style')} className="w-16 h-16 border border-zinc-700 hover:border-teal-500 bg-zinc-950 p-0 flex-shrink-0">
                                <img src={img} className="w-full h-full object-cover" />
                            </button>
                        ))}
                        {!currentProduct && brand.referenceImages?.map((img, i) => (
                            <button key={`brand-${i}`} onClick={() => handleImageSelect(img, 'style')} className="w-16 h-16 border border-zinc-700 hover:border-teal-500 bg-zinc-950 p-0 flex-shrink-0">
                                <img src={img} className="w-full h-full object-cover" />
                            </button>
                        ))}
                         <label className="w-16 h-16 border border-dashed border-zinc-700 hover:border-teal-500 flex items-center justify-center cursor-pointer flex-shrink-0 text-zinc-500 bg-zinc-900/50">
                            <Upload size={14}/>
                            <input type="file" className="hidden" onChange={(e) => handleFileUpload(e, 'style')} accept="image/*" />
                        </label>
                    </div>
                )}
             </div>
             
             {/* 3. Prompt */}
             <div className="relative">
                 <div className="flex justify-between items-center mb-1">
                    <h3 className="text-teal-400 font-bold uppercase tracking-wider text-sm flex items-center gap-2">
                        <Sparkles size={14}/> Generation Prompt
                    </h3>
                    <div className="flex gap-1">
                        <Button 
                            size="sm" 
                            variant="secondary" 
                            className="h-6 px-2 text-[10px]"
                            onClick={handleRefinePrompt}
                            disabled={refiningPrompt || !prompt}
                            title="Refine Prompt"
                        >
                            {refiningPrompt ? <Loader2 size={10} className="animate-spin"/> : <Wand2 size={10}/>}
                        </Button>
                        <Button 
                            size="sm" 
                            variant="secondary" 
                            className="h-6 px-2 text-[10px]"
                            onClick={() => setShowPromptModal(true)}
                            title="Expand Editor"
                        >
                            <Pencil size={10}/>
                        </Button>
                    </div>
                 </div>
                 
                 <TextArea 
                    placeholder="Describe the image..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="h-24 text-sm"
                 />
                 <div className="text-[10px] text-zinc-500 mt-1 flex justify-between">
                     <span>Prompt is optional (will use defaults if empty)</span>
                     <button onClick={() => setShowGuidelines(true)} className="text-teal-400 hover:underline">Check Guidelines</button>
                 </div>
             </div>

             <Button 
                onClick={handleGenerate} 
                disabled={loading} 
                className={`w-full flex items-center justify-center gap-2`}
             >
                {loading ? (
                    <>
                        <Loader2 className="animate-spin" size={16} />
                        {loadingText}
                    </>
                ) : (
                    <><Wand2 size={18}/> Generate {activeTab}</>
                )}
             </Button>
        </div>
      </div>

      {/* Preview Area */}
      <div className="flex-1 bg-zinc-950 border border-zinc-800 flex flex-col items-center justify-center p-8 relative min-h-[500px]">
        {generatedImageBase64 ? (
            <div className="relative group max-w-full max-h-full">
                <img src={generatedImageBase64} alt="Generated" className="max-w-full max-h-[75vh] object-contain border border-zinc-700 shadow-2xl" />
                
                <div className="absolute top-4 right-4 flex gap-2">
                     <Badge color="zinc">{aspectRatio}</Badge>
                     <Badge color="teal">{selectedModel}</Badge>
                </div>

                {/* Overlay Actions */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/80 p-2 border border-zinc-700 backdrop-blur">
                    <Button size="sm" variant="outline" onClick={() => {
                        const link = document.createElement('a');
                        link.href = generatedImageBase64;
                        link.download = `${brand.name}-${activeTab}-${Date.now()}.png`;
                        link.click();
                    }}>
                        <Download size={16} />
                    </Button>
                </div>
            </div>
        ) : (
            <div className="text-center text-zinc-600 max-w-md">
                <Wand2 size={48} className="mx-auto mb-4 opacity-20" />
                <h3 className="text-lg font-medium text-zinc-400 mb-2">Ready to Create</h3>
                <p className="text-sm">
                    Configure your context on the left, select your product source and style reference, and click Generate.
                </p>
            </div>
        )}
      </div>
    </div>
  );
};
