
import React, { useState } from 'react';
import { Brand, Product } from '../types';
import { Button } from './ui/Button';
import { Input, TextArea } from './ui/Input';
import { fileToBase64, generateProductGuidelines, logTokenUsage } from '../services/geminiService';
import { uploadBase64Image } from '../services/storageService';
import { supabase } from '../services/supabaseClient';
import { Loader2, Upload, X, Package, Image as ImageIcon } from 'lucide-react';

interface ProductManagerProps {
    userId: string;
    brand: Brand;
    onProductCreated: (product: Product) => void;
    onCancel: () => void;
}

export const ProductManager: React.FC<ProductManagerProps> = ({ userId, brand, onProductCreated, onCancel }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    
    // Separate state for Product Images (Packshots) vs Reference Images (Style)
    const [referenceImages, setReferenceImages] = useState<string[]>([]); 
    const [productImages, setProductImages] = useState<string[]>([]);

    const [loading, setLoading] = useState(false);
    const [statusText, setStatusText] = useState('');

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, type: 'ref' | 'prod') => {
        if (e.target.files && e.target.files.length > 0) {
            const newImages = await Promise.all(
                Array.from(e.target.files).map(file => fileToBase64(file))
            );
            if (type === 'ref') {
                setReferenceImages(prev => [...prev, ...newImages]);
            } else {
                setProductImages(prev => [...prev, ...newImages]);
            }
        }
    };

    const removeImage = (index: number, type: 'ref' | 'prod') => {
        if (type === 'ref') {
            setReferenceImages(prev => prev.filter((_, i) => i !== index));
        } else {
            setProductImages(prev => prev.filter((_, i) => i !== index));
        }
    };

    const handleCreate = async () => {
        if (!name || !description) return;
        setLoading(true);
        setStatusText('Generating Guidelines...');
        try {
            // Use Reference images for style context
            const result = await generateProductGuidelines(
                brand.name,
                brand.description,
                name,
                description,
                referenceImages
            );

            logTokenUsage(userId, 'gemini-2.5-flash', result.usage);

            // Upload Reference Images
            setStatusText('Uploading References...');
            const uploadedRefUrls: string[] = [];
            for (const base64 of referenceImages) {
                const url = await uploadBase64Image(base64, userId, 'references');
                if (url) uploadedRefUrls.push(url);
            }

            // Upload Product Images
            setStatusText('Uploading Product Shots...');
            const uploadedProdUrls: string[] = [];
            for (const base64 of productImages) {
                const url = await uploadBase64Image(base64, userId, 'products');
                if (url) uploadedProdUrls.push(url);
            }

            const productId = crypto.randomUUID();
            const now = Date.now();

            const productData = {
                id: productId,
                brand_id: brand.id,
                name,
                description,
                reference_images: uploadedRefUrls,
                product_images: uploadedProdUrls,
                guidelines: result.output,
                meta: {
                    generatedBy: 'Gemini 2.5 Flash',
                },
                created_at: new Date().toISOString()
            };

            const { error } = await supabase.from('products').insert(productData);
            if (error) throw error;

            const newProduct: Product = {
                id: productId,
                name,
                description,
                referenceImages: uploadedRefUrls,
                productImages: uploadedProdUrls,
                guidelines: result.output,
                meta: productData.meta,
                createdAt: now
            };

            onProductCreated(newProduct);
        } catch (error) {
            console.error(error);
            alert('Failed to create product. Try again.');
        } finally {
            setLoading(false);
            setStatusText('');
        }
    };

    return (
        <div className="max-w-3xl mx-auto p-6 bg-zinc-900 border border-zinc-800 animate-fade-in mb-12">
            <h2 className="text-2xl font-bold text-teal-400 mb-6">Add New Product</h2>
            
            <div className="space-y-8">
                <div className="space-y-4">
                    <Input 
                        label="Product Name" 
                        placeholder="e.g. Organic Amla Powder" 
                        value={name} 
                        onChange={e => setName(e.target.value)} 
                    />
                    
                    <TextArea 
                        label="Product Description" 
                        placeholder="Describe the product, its key benefits, and packaging..." 
                        value={description}
                        onChange={e => setDescription(e.target.value)}
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Actual Product Images */}
                    <div>
                        <div className="flex items-center gap-2 mb-2">
                             <Package size={16} className="text-teal-400"/>
                             <label className="text-sm font-medium text-zinc-300">Product Images</label>
                        </div>
                        <p className="text-xs text-zinc-500 mb-3">Upload clear shots of your product/packaging. These will be used as the subject in generations.</p>
                        
                        <div className="grid grid-cols-3 gap-2">
                            {productImages.map((img, idx) => (
                                <div key={idx} className="relative aspect-square bg-zinc-800 border border-zinc-700 group">
                                    <img src={img} alt="prod" className="w-full h-full object-cover" />
                                    <button 
                                        onClick={() => removeImage(idx, 'prod')}
                                        className="absolute top-0 right-0 bg-black/50 text-white p-1 hover:bg-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        <X size={12} />
                                    </button>
                                </div>
                            ))}
                            <label className="aspect-square border-2 border-dashed border-zinc-700 hover:border-teal-500 flex flex-col items-center justify-center cursor-pointer text-zinc-500 hover:text-teal-400 transition-colors bg-zinc-900/50">
                                <Upload size={20} />
                                <span className="text-[10px] mt-1">Upload</span>
                                <input type="file" className="hidden" accept="image/*" multiple onChange={(e) => handleFileChange(e, 'prod')} />
                            </label>
                        </div>
                    </div>

                    {/* Style References */}
                    <div>
                        <div className="flex items-center gap-2 mb-2">
                             <ImageIcon size={16} className="text-zinc-400"/>
                             <label className="text-sm font-medium text-zinc-300">Style References</label>
                        </div>
                        <p className="text-xs text-zinc-500 mb-3">Upload moodboards or style shots to help AI understand the vibe/backgrounds.</p>

                        <div className="grid grid-cols-3 gap-2">
                            {referenceImages.map((img, idx) => (
                                <div key={idx} className="relative aspect-square bg-zinc-800 border border-zinc-700 group">
                                    <img src={img} alt="ref" className="w-full h-full object-cover" />
                                    <button 
                                        onClick={() => removeImage(idx, 'ref')}
                                        className="absolute top-0 right-0 bg-black/50 text-white p-1 hover:bg-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        <X size={12} />
                                    </button>
                                </div>
                            ))}
                            <label className="aspect-square border-2 border-dashed border-zinc-700 hover:border-zinc-500 flex flex-col items-center justify-center cursor-pointer text-zinc-500 hover:text-zinc-300 transition-colors bg-zinc-900/50">
                                <Upload size={20} />
                                <span className="text-[10px] mt-1">Upload</span>
                                <input type="file" className="hidden" accept="image/*" multiple onChange={(e) => handleFileChange(e, 'ref')} />
                            </label>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                    <Button variant="secondary" onClick={onCancel}>Cancel</Button>
                    <Button onClick={handleCreate} disabled={loading || !name} className="flex items-center gap-2">
                        {loading && <Loader2 className="animate-spin" size={16} />}
                        {loading ? statusText : "Create Product"}
                    </Button>
                </div>
            </div>
        </div>
    );
};
