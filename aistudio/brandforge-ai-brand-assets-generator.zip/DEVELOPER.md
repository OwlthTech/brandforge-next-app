
# BrandForge AI - Developer Guide

## Overview
BrandForge AI is a React application powered by Google Gemini 2.5 and Supabase. It allows users to manage brand identities, product guidelines, and generate marketing assets using generative AI.

## Architecture

### Tech Stack
- **Frontend**: React 19 (via CDN), Tailwind CSS
- **AI**: Google GenAI SDK (`@google/genai`)
- **Backend/DB**: Supabase (PostgreSQL + Auth + Storage)
- **Icons**: Lucide React

### Key Components
- `App.tsx`: Main router and state manager. Handles Auth sessions and high-level navigation.
- `BrandWizard.tsx`: Multi-step form for creating new brands.
- `ProductManager.tsx`: Form for adding products to a brand.
- `ImageGenerator.tsx`: The core logic for AI image generation. Handles Subject/Style inputs and Prompt engineering.
- `ProductDetail.tsx`: Detailed view of a product, including asset galleries and CRUD for source images.

### Services
- `geminiService.ts`: Wraps `@google/genai` calls. Handles Image-to-Image and Text-to-Image logic.
- `storageService.ts`: Handles file uploads to Supabase Storage buckets.
- `supabaseClient.ts`: Initializes the Supabase connection.

## Database Schema (Supabase)

### Tables
1. **brands**: Stores brand identity (name, description, generated guidelines).
2. **products**: Links to brands. Stores specific product guidelines and image references.
   - `product_images`: Array of URLs (Source of truth for the product).
   - `reference_images`: Array of URLs (Style references).
   - `meta`: JSONB column for flexible data (e.g. image tags).
3. **generated_images**: Stores logs of created assets.
   - `url`: Public URL from Supabase Storage.
   - `meta`: JSONB column storing `sourceImage`, `referenceImage` used, and `usage` (tokens).
4. **token_usage**: Logs AI usage for cost tracking.

## Development Workflow

1. **Authentication**: 
   - Uses Supabase Auth.
   - For local dev, use the "Continue as Guest" button in `Auth.tsx` to simulate a session without email confirmation.

2. **Adding New Asset Types**:
   - Update `AssetType` enum in `types.ts`.
   - Update `ImageGenerator.tsx` to handle specific logic (aspect ratios, prompts) for the new type.

3. **Modifying AI Logic**:
   - `geminiService.ts` contains the prompt templates.
   - `generateOrEditImage` currently handles logic for merging Subject and Style images into a single request.

## Best Practices
- **Styles**: Use Tailwind utility classes.
- **State**: Keep global state in `App.tsx` (brands, images) and pass down via props.
- **Async/Await**: Always handle AI and DB calls asynchronously with try/catch blocks for loading states.
