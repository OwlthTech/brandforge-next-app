
export interface Product {
  id: string;
  name: string;
  description: string;
  guidelines: string;
  referenceImages: string[]; // Style/Vibe references
  productImages: string[];   // Actual product shots (Packshots, etc.)
  meta?: {
    imageTags?: Record<string, string>; // Map URL -> "Front View", "Top View", etc.
    [key: string]: any;
  }; 
  createdAt: number;
}

export interface Brand {
  id: string;
  name: string;
  category: string;
  description: string;
  guidelines: string;
  referenceImages: string[]; // URLs
  products: Product[];
  meta?: Record<string, any>; // Flexible metadata
  createdAt: number;
}

export interface GeneratedImage {
  id: string;
  url: string; // Storage URL
  prompt: string;
  type: AssetType;
  model: string;
  productId?: string;
  label?: string; // e.g. "Instagram Story" or "Marketplace - Hero"
  meta?: {
    aspectRatio?: string;
    isEdit?: boolean;
    sourceImage?: string; // URL of the product image used
    referenceImage?: string; // URL of the style reference used
    usage?: {
        promptTokens: number;
        candidatesTokens: number;
        totalTokens: number;
    };
    [key: string]: any;
  };
  createdAt: number;
}

export interface UsageLog {
  id: string;
  userId: string;
  model: string;
  promptTokens: number;
  candidatesTokens: number;
  totalTokens: number;
  createdAt: string;
}

export enum AssetType {
  MARKETPLACE = 'Marketplace',
  SOCIAL_MEDIA = 'Social Media',
  WEBSITE_BANNER = 'Website Banner',
  ICON = 'Icon',
}

export enum AspectRatio {
  SQUARE = '1:1',
  LANDSCAPE = '16:9',
  PORTRAIT = '9:16',
  STANDARD_LANDSCAPE = '4:3',
  STANDARD_PORTRAIT = '3:4',
}

export enum AIModel {
  GEMINI_2_5_FLASH_IMAGE = 'gemini-2.5-flash-image',
  GEMINI_3_PRO_IMAGE_PREVIEW = 'gemini-3-pro-image-preview',
}

export interface ImageGenerationConfig {
  prompt: string;
  aspectRatio: AspectRatio;
  referenceImage?: string; // For editing or style transfer
}
