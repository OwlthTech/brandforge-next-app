import { createClient } from '@supabase/supabase-js';

// Configuration provided in the prompt
// Note: In a real production environment, ensure these are environment variables.
// The prompt supplied "sb_publishable_..." which we use as the anon key.

const SUPABASE_URL = 'https://izaxotqeqlvhylffnljq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_N4GEsuGa7klZusBPxm9bwg_g9DsaspW';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
