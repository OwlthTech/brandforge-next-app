
import { supabase } from './supabaseClient';

const BUCKET_NAME = 'brand-assets';

// Convert Base64 Data URL to Blob
const base64ToBlob = (base64: string): Blob => {
  const parts = base64.split(';base64,');
  const contentType = parts[0].split(':')[1];
  const raw = window.atob(parts[1]);
  const rawLength = raw.length;
  const uInt8Array = new Uint8Array(rawLength);

  for (let i = 0; i < rawLength; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }

  return new Blob([uInt8Array], { type: contentType });
};

export const uploadBase64Image = async (
  base64Data: string, 
  userId: string, 
  folder: 'generated' | 'references' | 'products'
): Promise<string | null> => {
  try {
    const blob = base64ToBlob(base64Data);
    const fileName = `${userId}/${folder}/${Date.now()}-${Math.random().toString(36).substring(7)}.png`;
    
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(fileName, blob, {
        contentType: 'image/png',
        upsert: false
      });

    if (error) {
      console.error('Upload error:', error);
      return null;
    }

    const { data: publicUrlData } = supabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(fileName);

    return publicUrlData.publicUrl;
  } catch (error) {
    console.error('Storage service error:', error);
    return null;
  }
};

export const uploadFile = async (
    file: File,
    userId: string,
    folder: 'references' | 'products' | 'generated'
): Promise<string | null> => {
    try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/${folder}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

        const { error } = await supabase.storage
            .from(BUCKET_NAME)
            .upload(fileName, file);

        if (error) {
            console.error('Upload error:', error);
            return null;
        }

        const { data: publicUrlData } = supabase.storage
            .from(BUCKET_NAME)
            .getPublicUrl(fileName);

        return publicUrlData.publicUrl;
    } catch (error) {
        console.error('File upload error:', error);
        return null;
    }
}
