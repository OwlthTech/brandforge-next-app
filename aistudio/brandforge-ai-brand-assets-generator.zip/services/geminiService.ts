
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AspectRatio, AIModel } from "../types";
import { supabase } from "./supabaseClient";

export interface ServiceResponse<T> {
  output: T;
  usage?: any;
}

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const retryOperation = async <T>(
  operation: () => Promise<T>,
  retries: number = 3,
  defaultBackoff: number = 2000
): Promise<T> => {
  try {
    return await operation();
  } catch (error: any) {
    const isRateLimit =
      error.status === 429 ||
      error.code === 429 ||
      error.status === "RESOURCE_EXHAUSTED" ||
      (error.message && error.message.includes("429")) ||
      (error.message && error.message.includes("quota"));

    if (isRateLimit && retries > 0) {
      let waitTime = defaultBackoff;
      let match: RegExpMatchArray | null = null;
      
      // Try to parse explicit retry delay from error message (e.g. "Please retry in 29.714s")
      if (error.message) {
        match = error.message.match(/retry in ([\d.]+)s/);
        if (match && match[1]) {
          waitTime = Math.ceil(parseFloat(match[1]) * 1000) + 1000; // Add 1s buffer
        }
      }

      console.warn(`Gemini API Rate Limit hit. Retrying in ${waitTime}ms... (${retries} attempts left)`);
      await delay(waitTime);
      // Exponential backoff if we are using the default, otherwise use the parsed time + buffer
      const nextBackoff = match ? waitTime : defaultBackoff * 2;
      return retryOperation(operation, retries - 1, nextBackoff);
    }
    
    // Pass through other errors (like 403 Permission Denied)
    throw error;
  }
};

const getAiClient = async (model: string) => {
  // Special handling for Gemini 3 Pro / Veo models requiring paid keys
  if (model === AIModel.GEMINI_3_PRO_IMAGE_PREVIEW) {
    // Cast to any to handle external type definitions for aistudio
    const win = window as any;
    if (win.aistudio) {
      const hasKey = await win.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        try {
          await win.aistudio.openSelectKey();
          // We must wait a bit or assume it's set. 
          // The instruction says "assume the key selection was successful".
        } catch (e) {
          console.error("Key selection failed", e);
        }
      }
    }
  }

  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY environment variable is not set.");
  }
  return new GoogleGenAI({ apiKey });
};

// Helper to convert File to Base64
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};

// Extract raw base64 from data URL
const extractBase64Data = (dataUrl: string): string => {
  if (dataUrl.includes('base64,')) {
      return dataUrl.split(',')[1];
  }
  return dataUrl;
};

const getMimeType = (dataUrl: string): string => {
  if (dataUrl.includes(';') && dataUrl.includes(':')) {
      return dataUrl.substring(dataUrl.indexOf(':') + 1, dataUrl.indexOf(';'));
  }
  return 'image/png'; // Default
}

// Log token usage to Supabase
export const logTokenUsage = async (userId: string, model: string, usage: any) => {
  if (!userId || !usage) return;
  
  try {
    const { error } = await supabase.from('token_usage').insert({
      user_id: userId,
      model: model,
      prompt_tokens: usage.promptTokenCount || 0,
      candidates_tokens: usage.candidatesTokenCount || 0,
      total_tokens: usage.totalTokenCount || 0,
      created_at: new Date().toISOString()
    });
    
    if (error) {
      console.warn("Failed to log token usage:", error);
    }
  } catch (err) {
    console.warn("Error logging usage:", err);
  }
};

export const refinePrompt = async (originalPrompt: string): Promise<ServiceResponse<string>> => {
    const ai = await getAiClient('gemini-2.5-flash');
    
    const prompt = `You are an expert AI image prompt engineer. 
    Refine and expand the following user prompt to be more descriptive, focusing on lighting, composition, texture, and mood for a high-quality photorealistic generation.
    
    User Prompt: "${originalPrompt}"
    
    Output ONLY the refined prompt text. Do not add explanations.`;

    try {
        const response = await retryOperation(() => ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        }));
        return {
          output: response.text?.trim() || originalPrompt,
          usage: response.usageMetadata
        };
    } catch (error) {
        console.error("Error refining prompt:", error);
        return { output: originalPrompt };
    }
};

export const generateBrandGuidelines = async (
  name: string,
  category: string,
  description: string,
  refImages: string[]
): Promise<ServiceResponse<string>> => {
  const ai = await getAiClient('gemini-2.5-flash');
  
  let promptText = `Create comprehensive brand identity guidelines for a brand named "${name}" in the "${category}" industry. 
  
  Business Description: ${description}
  
  Please provide:
  1. Brand Voice & Tone
  2. Color Palette suggestions (Hex codes)
  3. Typography recommendations
  4. Key visual motifs
  5. Target Audience Persona
  
  Keep the format clean and structured with Markdown headers.`;

  const parts: any[] = [{ text: promptText }];

  refImages.forEach((img) => {
    parts.push({
      inlineData: {
        mimeType: getMimeType(img),
        data: extractBase64Data(img),
      },
    });
  });

  try {
    const response: GenerateContentResponse = await retryOperation(() => ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts },
    }));
    return {
      output: response.text || "Failed to generate guidelines.",
      usage: response.usageMetadata
    };
  } catch (error) {
    console.error("Error generating guidelines:", error);
    throw error;
  }
};

export const generateProductGuidelines = async (
    brandName: string,
    brandContext: string,
    productName: string,
    productDescription: string,
    refImages: string[]
  ): Promise<ServiceResponse<string>> => {
    const ai = await getAiClient('gemini-2.5-flash');
    
    let promptText = `Create specific visual guidelines and marketing angles for a product named "${productName}" belonging to the brand "${brandName}".
    
    Brand Context: ${brandContext}
    Product Description: ${productDescription}
    
    Based on the attached images (if any) and description, provide:
    1. Key Product Features to Highlight
    2. Visual Composition Rules for this product
    3. Suggested Backgrounds & Props
    4. Lighting Mood
    5. A short list of marketing hook keywords
    
    Keep it concise and formatted in Markdown.`;
  
    const parts: any[] = [{ text: promptText }];
  
    refImages.forEach((img) => {
      parts.push({
        inlineData: {
          mimeType: getMimeType(img),
          data: extractBase64Data(img),
        },
      });
    });
  
    try {
      const response: GenerateContentResponse = await retryOperation(() => ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts },
      }));
      return {
        output: response.text || "Failed to generate product guidelines.",
        usage: response.usageMetadata
      };
    } catch (error) {
      console.error("Error generating product guidelines:", error);
      throw error;
    }
  };

export const generateMarketplacePrompts = async (
    brandName: string,
    productName: string,
    guidelines: string,
    imageType: string
): Promise<ServiceResponse<string>> => {
    const ai = await getAiClient('gemini-2.5-flash');
    
    const prompt = `Write a detailed image generation prompt for a "${imageType}" image for the product "${productName}" by brand "${brandName}".
    
    Use the following guidelines to inform the style and content:
    ${guidelines}
    
    The prompt should be descriptive, specifying lighting, composition, and subjects. Output ONLY the prompt text.`;

    try {
        const response = await retryOperation(() => ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        }));
        return {
          output: response.text?.trim() || "",
          usage: response.usageMetadata
        };
    } catch (error) {
        console.error("Error generating prompt:", error);
        return { output: "" };
    }
}

export const generateOrEditImage = async (
  prompt: string,
  aspectRatio: AspectRatio,
  model: string = 'gemini-2.5-flash-image',
  subjectImage?: string,
  styleImage?: string,
  isEditing: boolean = false
): Promise<ServiceResponse<string>> => {
  const ai = await getAiClient(model);
  
  const parts: any[] = [];
  
  // 1. Add Subject Image (The Product) - Referred to as [Image 1] or first image
  if (subjectImage) {
    parts.push({
      inlineData: {
        mimeType: getMimeType(subjectImage),
        data: extractBase64Data(subjectImage),
      },
    });
  }

  // 2. Add Style/Reference Image - Referred to as [Image 2] or second image
  if (styleImage) {
      parts.push({
          inlineData: {
              mimeType: getMimeType(styleImage),
              data: extractBase64Data(styleImage),
          }
      });
  }

  // 3. Construct Prompt with explicit references to image slots
  let finalPrompt = prompt;
  
  if (isEditing && subjectImage) {
    finalPrompt = `Edit this image: ${prompt}`;
  } else {
    // Generation Mode
    if (subjectImage && styleImage) {
        // Explicit instruction for Subject + Style
        finalPrompt = `[Image 1] is the SUBJECT PRODUCT. [Image 2] is the STYLE REFERENCE.
        
        Task: Generate a high-quality photorealistic image of the product shown in [Image 1].
        1. PRESERVE the exact shape, packaging, logo, and text of the product in [Image 1].
        2. APPLY the background, lighting, and aesthetic style from [Image 2].
        
        Additional Instructions: ${prompt}`;
    } else if (subjectImage) {
        // Subject only
        finalPrompt = `[Image 1] is the SUBJECT. Generate a new image featuring this product.
        Maintain product details accurately.
        Context: ${prompt}`;
    } else if (styleImage) {
        // Style only
        finalPrompt = `[Image 1] is a STYLE REFERENCE. Create a new image following this aesthetic.
        Context: ${prompt}`;
    }
  }

  parts.push({ text: finalPrompt });

  try {
    const response = await retryOperation(() => ai.models.generateContent({
      model: model, 
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
        }
      }
    }));

    let imageData = "";
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageData = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
    }
    
    if (!imageData) throw new Error("No image data found in response");

    return {
      output: imageData,
      usage: response.usageMetadata
    };

  } catch (error) {
    console.error("Error generating image:", error);
    throw error;
  }
};
